/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/scripts/background.js":
/*!***********************************!*\
  !*** ./src/scripts/background.js ***!
  \***********************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _library_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./library.js */ "./src/scripts/library.js");
// in order to use import/export (ES6 modules) we are using this technique
// https://medium.com/front-end-weekly/es6-modules-in-chrome-extensions-an-introduction-313b3fce955b

'use strict';

Object(_library_js__WEBPACK_IMPORTED_MODULE_0__["addOnInstalledListener"])(function () {
  handleOnPageChanged();
  Object(_library_js__WEBPACK_IMPORTED_MODULE_0__["setStoredValue"])("color", "#123456", function (value) {
    console.log("The color is ".concat(value, " when it was saved"));
  });
  Object(_library_js__WEBPACK_IMPORTED_MODULE_0__["getStoredValue"])("color", function (value) {
    console.log("Stored value ".concat(value), value);
  });
});
/**
 * Setup handler that runs when the page changes
 * e.g. to enable/disable the page action
 */

function handleOnPageChanged() {
  // Add handler that makes this work only on yucata
  chrome.declarativeContent.onPageChanged.removeRules(undefined, function () {
    chrome.declarativeContent.onPageChanged.addRules([{
      conditions: [new chrome.declarativeContent.PageStateMatcher({
        pageUrl: {
          hostEquals: 'yucata.de'
        }
      })],
      actions: [new chrome.declarativeContent.ShowPageAction()]
    }]);
  });
}

/***/ }),

/***/ "./src/scripts/library.js":
/*!********************************!*\
  !*** ./src/scripts/library.js ***!
  \********************************/
/*! exports provided: setStoredValue, getStoredValue, addOnInstalledListener */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setStoredValue", function() { return setStoredValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getStoredValue", function() { return getStoredValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addOnInstalledListener", function() { return addOnInstalledListener; });
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/**
 * Set a value in Chrome storage
 * See https://developer.chrome.com/apps/storage
 * @param key
 * @param value
 * @param {function} callback
 */
var setStoredValue = function setStoredValue(key, value, callback) {
  chrome.storage.sync.set(_defineProperty({}, key, value), function () {
    callback(value);
  });
};
/**
 * Set a value in Chrome storage
 * See https://developer.chrome.com/apps/storage
 * @param key
 * @param {function} callback
 */

var getStoredValue = function getStoredValue(key, callback) {
  chrome.storage.sync.get([key], function (value) {
    callback(value[key]);
  });
};
/**
 * Add an on Installed handler
 * @param {function} method
 */

var addOnInstalledListener = function addOnInstalledListener(method) {
  chrome.runtime.onInstalled.addListener(function () {
    method();
  });
};

/***/ }),

/***/ 0:
/*!**************************************!*\
  !*** multi ./src/scripts/background ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/pano/code/yucatahotkeys/build/src/scripts/background */"./src/scripts/background.js");


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NjcmlwdHMvYmFja2dyb3VuZC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2NyaXB0cy9saWJyYXJ5LmpzIl0sIm5hbWVzIjpbImFkZE9uSW5zdGFsbGVkTGlzdGVuZXIiLCJoYW5kbGVPblBhZ2VDaGFuZ2VkIiwic2V0U3RvcmVkVmFsdWUiLCJ2YWx1ZSIsImNvbnNvbGUiLCJsb2ciLCJnZXRTdG9yZWRWYWx1ZSIsImNocm9tZSIsImRlY2xhcmF0aXZlQ29udGVudCIsIm9uUGFnZUNoYW5nZWQiLCJyZW1vdmVSdWxlcyIsInVuZGVmaW5lZCIsImFkZFJ1bGVzIiwiY29uZGl0aW9ucyIsIlBhZ2VTdGF0ZU1hdGNoZXIiLCJwYWdlVXJsIiwiaG9zdEVxdWFscyIsImFjdGlvbnMiLCJTaG93UGFnZUFjdGlvbiIsImtleSIsImNhbGxiYWNrIiwic3RvcmFnZSIsInN5bmMiLCJzZXQiLCJnZXQiLCJtZXRob2QiLCJydW50aW1lIiwib25JbnN0YWxsZWQiLCJhZGRMaXN0ZW5lciJdLCJtYXBwaW5ncyI6IjtRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBOzs7UUFHQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMENBQTBDLGdDQUFnQztRQUMxRTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLHdEQUF3RCxrQkFBa0I7UUFDMUU7UUFDQSxpREFBaUQsY0FBYztRQUMvRDs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EseUNBQXlDLGlDQUFpQztRQUMxRSxnSEFBZ0gsbUJBQW1CLEVBQUU7UUFDckk7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwyQkFBMkIsMEJBQTBCLEVBQUU7UUFDdkQsaUNBQWlDLGVBQWU7UUFDaEQ7UUFDQTtRQUNBOztRQUVBO1FBQ0Esc0RBQXNELCtEQUErRDs7UUFFckg7UUFDQTs7O1FBR0E7UUFDQTs7Ozs7Ozs7Ozs7OztBQ2xGQTtBQUFBO0FBQUE7QUFDQTtBQUVBO0FBRUE7O0FBRUFBLDBFQUFzQixDQUFDLFlBQU07QUFDekJDLHFCQUFtQjtBQUVuQkMsb0VBQWMsQ0FBQyxPQUFELEVBQVUsU0FBVixFQUFxQixVQUFDQyxLQUFELEVBQVc7QUFDMUNDLFdBQU8sQ0FBQ0MsR0FBUix3QkFBNEJGLEtBQTVCO0FBQ0gsR0FGYSxDQUFkO0FBSUFHLG9FQUFjLENBQUMsT0FBRCxFQUFVLFVBQUNILEtBQUQsRUFBVztBQUMvQkMsV0FBTyxDQUFDQyxHQUFSLHdCQUE0QkYsS0FBNUIsR0FBcUNBLEtBQXJDO0FBQ0gsR0FGYSxDQUFkO0FBR0gsQ0FWcUIsQ0FBdEI7QUFZQTs7Ozs7QUFJQSxTQUFTRixtQkFBVCxHQUE4QjtBQUMxQjtBQUNBTSxRQUFNLENBQUNDLGtCQUFQLENBQTBCQyxhQUExQixDQUF3Q0MsV0FBeEMsQ0FBb0RDLFNBQXBELEVBQStELFlBQVc7QUFDdEVKLFVBQU0sQ0FBQ0Msa0JBQVAsQ0FBMEJDLGFBQTFCLENBQXdDRyxRQUF4QyxDQUFpRCxDQUFDO0FBQzlDQyxnQkFBVSxFQUFFLENBQ1IsSUFBSU4sTUFBTSxDQUFDQyxrQkFBUCxDQUEwQk0sZ0JBQTlCLENBQStDO0FBQzNDQyxlQUFPLEVBQUU7QUFBQ0Msb0JBQVUsRUFBRTtBQUFiO0FBRGtDLE9BQS9DLENBRFEsQ0FEa0M7QUFNOUNDLGFBQU8sRUFBRSxDQUFDLElBQUlWLE1BQU0sQ0FBQ0Msa0JBQVAsQ0FBMEJVLGNBQTlCLEVBQUQ7QUFOcUMsS0FBRCxDQUFqRDtBQVFILEdBVEQ7QUFVSCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQ0Q7Ozs7Ozs7QUFPTyxJQUFNaEIsY0FBYyxHQUFHLFNBQWpCQSxjQUFpQixDQUFDaUIsR0FBRCxFQUFNaEIsS0FBTixFQUFhaUIsUUFBYixFQUEwQjtBQUNwRGIsUUFBTSxDQUFDYyxPQUFQLENBQWVDLElBQWYsQ0FBb0JDLEdBQXBCLHFCQUEwQkosR0FBMUIsRUFBZ0NoQixLQUFoQyxHQUF3QyxZQUFXO0FBQy9DaUIsWUFBUSxDQUFDakIsS0FBRCxDQUFSO0FBQ0gsR0FGRDtBQUdILENBSk07QUFPUDs7Ozs7OztBQU1PLElBQU1HLGNBQWMsR0FBRyxTQUFqQkEsY0FBaUIsQ0FBQ2EsR0FBRCxFQUFNQyxRQUFOLEVBQW1CO0FBQzdDYixRQUFNLENBQUNjLE9BQVAsQ0FBZUMsSUFBZixDQUFvQkUsR0FBcEIsQ0FBd0IsQ0FBQ0wsR0FBRCxDQUF4QixFQUErQixVQUFTaEIsS0FBVCxFQUFnQjtBQUMzQ2lCLFlBQVEsQ0FBQ2pCLEtBQUssQ0FBQ2dCLEdBQUQsQ0FBTixDQUFSO0FBQ0gsR0FGRDtBQUdILENBSk07QUFPUDs7Ozs7QUFJTyxJQUFNbkIsc0JBQXNCLEdBQUcsU0FBekJBLHNCQUF5QixDQUFDeUIsTUFBRCxFQUFZO0FBQzlDbEIsUUFBTSxDQUFDbUIsT0FBUCxDQUFlQyxXQUFmLENBQTJCQyxXQUEzQixDQUF1QyxZQUFNO0FBQ3pDSCxVQUFNO0FBQ1QsR0FGRDtBQUdILENBSk0sQyIsImZpbGUiOiJzY3JpcHRzL2JhY2tncm91bmQuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIi9cIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IDApO1xuIiwiLy8gaW4gb3JkZXIgdG8gdXNlIGltcG9ydC9leHBvcnQgKEVTNiBtb2R1bGVzKSB3ZSBhcmUgdXNpbmcgdGhpcyB0ZWNobmlxdWVcbi8vIGh0dHBzOi8vbWVkaXVtLmNvbS9mcm9udC1lbmQtd2Vla2x5L2VzNi1tb2R1bGVzLWluLWNocm9tZS1leHRlbnNpb25zLWFuLWludHJvZHVjdGlvbi0zMTNiM2ZjZTk1NWJcblxuaW1wb3J0IHthZGRPbkluc3RhbGxlZExpc3RlbmVyLCBnZXRTdG9yZWRWYWx1ZSwgc2V0U3RvcmVkVmFsdWV9IGZyb20gJy4vbGlicmFyeS5qcyc7XG5cbid1c2Ugc3RyaWN0JztcblxuYWRkT25JbnN0YWxsZWRMaXN0ZW5lcigoKSA9PiB7XG4gICAgaGFuZGxlT25QYWdlQ2hhbmdlZCgpO1xuXG4gICAgc2V0U3RvcmVkVmFsdWUoXCJjb2xvclwiLCBcIiMxMjM0NTZcIiwgKHZhbHVlKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBUaGUgY29sb3IgaXMgJHt2YWx1ZX0gd2hlbiBpdCB3YXMgc2F2ZWRgKTtcbiAgICB9KTtcblxuICAgIGdldFN0b3JlZFZhbHVlKFwiY29sb3JcIiwgKHZhbHVlKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBTdG9yZWQgdmFsdWUgJHt2YWx1ZX1gLCB2YWx1ZSk7XG4gICAgfSk7XG59KTtcblxuLyoqXG4gKiBTZXR1cCBoYW5kbGVyIHRoYXQgcnVucyB3aGVuIHRoZSBwYWdlIGNoYW5nZXNcbiAqIGUuZy4gdG8gZW5hYmxlL2Rpc2FibGUgdGhlIHBhZ2UgYWN0aW9uXG4gKi9cbmZ1bmN0aW9uIGhhbmRsZU9uUGFnZUNoYW5nZWQoKXtcbiAgICAvLyBBZGQgaGFuZGxlciB0aGF0IG1ha2VzIHRoaXMgd29yayBvbmx5IG9uIHl1Y2F0YVxuICAgIGNocm9tZS5kZWNsYXJhdGl2ZUNvbnRlbnQub25QYWdlQ2hhbmdlZC5yZW1vdmVSdWxlcyh1bmRlZmluZWQsIGZ1bmN0aW9uKCkge1xuICAgICAgICBjaHJvbWUuZGVjbGFyYXRpdmVDb250ZW50Lm9uUGFnZUNoYW5nZWQuYWRkUnVsZXMoW3tcbiAgICAgICAgICAgIGNvbmRpdGlvbnM6IFtcbiAgICAgICAgICAgICAgICBuZXcgY2hyb21lLmRlY2xhcmF0aXZlQ29udGVudC5QYWdlU3RhdGVNYXRjaGVyKHtcbiAgICAgICAgICAgICAgICAgICAgcGFnZVVybDoge2hvc3RFcXVhbHM6ICd5dWNhdGEuZGUnfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIGFjdGlvbnM6IFtuZXcgY2hyb21lLmRlY2xhcmF0aXZlQ29udGVudC5TaG93UGFnZUFjdGlvbigpXVxuICAgICAgICB9XSk7XG4gICAgfSk7XG59XG5cblxuIiwiLyoqXG4gKiBTZXQgYSB2YWx1ZSBpbiBDaHJvbWUgc3RvcmFnZVxuICogU2VlIGh0dHBzOi8vZGV2ZWxvcGVyLmNocm9tZS5jb20vYXBwcy9zdG9yYWdlXG4gKiBAcGFyYW0ga2V5XG4gKiBAcGFyYW0gdmFsdWVcbiAqIEBwYXJhbSB7ZnVuY3Rpb259IGNhbGxiYWNrXG4gKi9cbmV4cG9ydCBjb25zdCBzZXRTdG9yZWRWYWx1ZSA9IChrZXksIHZhbHVlLCBjYWxsYmFjaykgPT4ge1xuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuc2V0KHtba2V5XTogdmFsdWV9LCBmdW5jdGlvbigpIHtcbiAgICAgICAgY2FsbGJhY2sodmFsdWUpO1xuICAgIH0pO1xufTtcblxuXG4vKipcbiAqIFNldCBhIHZhbHVlIGluIENocm9tZSBzdG9yYWdlXG4gKiBTZWUgaHR0cHM6Ly9kZXZlbG9wZXIuY2hyb21lLmNvbS9hcHBzL3N0b3JhZ2VcbiAqIEBwYXJhbSBrZXlcbiAqIEBwYXJhbSB7ZnVuY3Rpb259IGNhbGxiYWNrXG4gKi9cbmV4cG9ydCBjb25zdCBnZXRTdG9yZWRWYWx1ZSA9IChrZXksIGNhbGxiYWNrKSA9PiB7XG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoW2tleV0sIGZ1bmN0aW9uKHZhbHVlKSB7XG4gICAgICAgIGNhbGxiYWNrKHZhbHVlW2tleV0pO1xuICAgIH0pO1xufTtcblxuXG4vKipcbiAqIEFkZCBhbiBvbiBJbnN0YWxsZWQgaGFuZGxlclxuICogQHBhcmFtIHtmdW5jdGlvbn0gbWV0aG9kXG4gKi9cbmV4cG9ydCBjb25zdCBhZGRPbkluc3RhbGxlZExpc3RlbmVyID0gKG1ldGhvZCkgPT4ge1xuICAgIGNocm9tZS5ydW50aW1lLm9uSW5zdGFsbGVkLmFkZExpc3RlbmVyKCgpID0+IHtcbiAgICAgICAgbWV0aG9kKCk7XG4gICAgfSk7XG59OyJdLCJzb3VyY2VSb290IjoiIn0=