/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/scripts/dom.js":
/*!****************************!*\
  !*** ./src/scripts/dom.js ***!
  \****************************/
/*! exports provided: getPopupButton, clickBySelector, waitForBoardToExistAndThen */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPopupButton", function() { return getPopupButton; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clickBySelector", function() { return clickBySelector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "waitForBoardToExistAndThen", function() { return waitForBoardToExistAndThen; });
/**
 * Return the dom node of the button in the popup
 * @returns {HTMLElement}
 */
var getPopupButton = function getPopupButton() {
  return document.getElementById("popupButton");
};
/**
 * Click the element in the selector if it is found
 * @param {string} selector
 */

function clickBySelector(selector) {
  var element = document.querySelector(selector);

  if (element) {
    element.click();
  } else {
    console.log("Element ".concat(selector, " not found"));
  }
}
/**
 * Wait for the board DOM element to exist, and then execute the method passed
 * @param {function} method
 */

function waitForBoardToExistAndThen(method) {
  var board = document.getElementById("board");

  if (board) {
    console.log("Board is ready.");
    method();
  } else {
    console.log("No board yet, waiting.");
    setTimeout(waitForBoardToExistAndThen.bind(this, method), 500);
  }
}

/***/ }),

/***/ "./src/scripts/hotkeys/machi_koro.js":
/*!*******************************************!*\
  !*** ./src/scripts/hotkeys/machi_koro.js ***!
  \*******************************************/
/*! exports provided: main, machiKoroHotkeysMap, selectCardBySelector, getSelectedCard, selectCardByNumber, getCardNumber, selectCardLeft, selectCardRight, selectCardUp, selectCardDown, buySelectedCard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "main", function() { return main; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "machiKoroHotkeysMap", function() { return machiKoroHotkeysMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardBySelector", function() { return selectCardBySelector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSelectedCard", function() { return getSelectedCard; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardByNumber", function() { return selectCardByNumber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCardNumber", function() { return getCardNumber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardLeft", function() { return selectCardLeft; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardRight", function() { return selectCardRight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardUp", function() { return selectCardUp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardDown", function() { return selectCardDown; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "buySelectedCard", function() { return buySelectedCard; });
/* harmony import */ var _scss_machi_koro_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../scss/machi_koro.scss */ "./src/scss/machi_koro.scss");
/* harmony import */ var _scss_machi_koro_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_scss_machi_koro_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../dom */ "./src/scripts/dom.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }



/**
 * Main method to be executed (by content.js)
 */

function main() {
  Object(_dom__WEBPACK_IMPORTED_MODULE_1__["waitForBoardToExistAndThen"])(function () {
    return selectCardBySelector("#card1");
  });
  Object(_dom__WEBPACK_IMPORTED_MODULE_1__["waitForBoardToExistAndThen"])(addCardTooltips);
}
/**
 * Hotkey map for machi koro only
 */

var machiKoroHotkeysMap = {
  "machi_koro_buy_slot_1": {
    keyCombos: ["1"],
    description: "Buy Card in Slot 1 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card1");
    }
  },
  "machi_koro_buy_slot_2": {
    keyCombos: ["2"],
    description: "Buy Card in Slot 2 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card2");
    }
  },
  "machi_koro_buy_slot_3": {
    keyCombos: ["3"],
    description: "Buy Card in Slot 3 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card3");
    }
  },
  "machi_koro_buy_slot_4": {
    keyCombos: ["4"],
    description: "Buy Card in Slot 4 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card4");
    }
  },
  "machi_koro_buy_slot_5": {
    keyCombos: ["5"],
    description: "Buy Card in Slot 5 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card5");
    }
  },
  "machi_koro_buy_slot_6": {
    keyCombos: ["6"],
    description: "Buy Card in Slot 6 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card6");
    }
  },
  "machi_koro_buy_slot_7": {
    keyCombos: ["7"],
    description: "Buy Card in Slot 7 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card7");
    }
  },
  "machi_koro_buy_slot_8": {
    keyCombos: ["8"],
    description: "Buy Card in Slot 8 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card8");
    }
  },
  "machi_koro_buy_slot_9": {
    keyCombos: ["9"],
    description: "Buy Card in Slot 9 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card9");
    }
  },
  "machi_koro_toggle_dice": {
    keyCombos: ["d"],
    description: "Toggle Dice",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#die2");
    }
  },
  "machi_koro_roll_dice": {
    keyCombos: ["r"],
    description: "Hit 'Roll dice' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#btn_Würfeln");
    }
  },
  "machi_koro_reroll_dice": {
    keyCombos: ["q"],
    description: "Hit 'Reroll dice' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#btn_BtnRollAgain");
    }
  },
  "machi_koro_do_not_reroll_dice": {
    keyCombos: ["w"],
    description: "Hit 'Do Not Reroll' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#btn_BtnRollNotAgain");
    }
  },
  "machi_koro_select_card_left": {
    keyCombos: ["ArrowLeft"],
    description: "Select Left Card",
    method: function method() {
      return selectCardLeft();
    }
  },
  "machi_koro_select_card_right": {
    keyCombos: ["ArrowRight"],
    description: "Select Right Card",
    method: function method() {
      return selectCardRight();
    }
  },
  "machi_koro_select_card_up": {
    keyCombos: ["ArrowUp"],
    description: "Select Top Card",
    method: function method() {
      return selectCardUp();
    }
  },
  "machi_koro_select_card_down": {
    keyCombos: ["ArrowDown"],
    description: "Select Bottom Card",
    method: function method() {
      return selectCardDown();
    }
  },
  "machi_koro_buy_selected_card": {
    keyCombos: ["b"],
    description: "Buy Selected Card",
    method: function method() {
      return buySelectedCard();
    }
  }
};
/**
 * Add the "selectedCard" class to the element matched by the selector (if any)
 * @param {string} selector
 */

function selectCardBySelector(selector) {
  var activeElement = getSelectedCard();
  var cardElement = document.querySelector(selector);

  if (cardElement) {
    cardElement.classList.add("selectedCard");

    if (activeElement) {
      activeElement.classList.remove("selectedCard");
    }
  }
}
/**
 * Adds card tooltips on hover (zoomed in cards)
 */

function addCardTooltips() {
  var cards = getCardsDom();
  cards.forEach(function (card) {
    var clone = card.querySelector(".card img").cloneNode();
    clone.classList.add("cardZoomed");
    card.parentElement.insertBefore(clone, card.nextSibling);
  });
}
/**
 *
 * @returns {NodeListOf<Element>}
 */


function getCardsDom() {
  return _toConsumableArray(document.querySelectorAll(".cardContainer"));
}
/**
 * Return the card that is currently selected (has the class selectedCard)
 * @returns {Element}
 */


function getSelectedCard() {
  return document.querySelector(".selectedCard");
}
/**
 * Select a card based on the number provided
 * @param {number} cardNumber
 */

function selectCardByNumber(cardNumber) {
  var nextCardSelector = "#card".concat(cardNumber);
  selectCardBySelector(nextCardSelector);
}
/**
 * Return the card number for the provided element
 * @param {Element} element
 * @returns {number}
 */

function getCardNumber(element) {
  var regex = /\d+$/;

  if (element) {
    var cardNumber = element.id.match(regex)[0];

    try {
      return parseInt(cardNumber);
    } catch (error) {
      console.log("".concat(element.id, " did not have a number at the end of its ID"));
      return null;
    }
  }

  return null;
}
/**
 * Select the card to the left of the active card
 */

function selectCardLeft() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) - 1;
  selectCardByNumber(nextCardNumber);
}
/**
 * Select the card to the right of the active card
 */

function selectCardRight() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) + 1;
  selectCardByNumber(nextCardNumber);
}
/**
 * Select the card to the up of the active card
 */

function selectCardUp() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) - 5;
  selectCardByNumber(nextCardNumber);
}
/**
 * Select the card to the down of the active card
 */

function selectCardDown() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) + 5;
  selectCardByNumber(nextCardNumber);
}
/**
 * Buy the card that is currently selected
 */

function buySelectedCard() {
  var activeElement = document.querySelector(".selectedCard");
  console.log("Ok I want to buy " + activeElement.id);

  if (activeElement) {
    if (activeElement.classList.contains("active")) {
      console.log("It's active, sure, I'll buy it");
      activeElement.click();
      console.log("Click");
    } else {
      // auto bvgainei an
      // 1. den einai available auth
      // 2. exeis agorasei hdh  ** αν υπαρχει κουμπί αντού "#btn_undo"
      // 3. den einai h seira sou -- auto isws to lynoyme me to na tsekaroume seira apo prin
      console.log("Doesn't seem to be available though.");
      var undoButton = document.querySelector("#btn_undo");

      if (undoButton) {
        alert("You've already chosen a card."); // an vgaloume to ble otan den einai h seira sou de xreiazetai auto
        // alla prepei na xanaginetai ble otan einai h seira sou
      } else {
        alert("You can't buy this one :( \nChose an available card.");
      }
    }
  } else {
    console.log("Element ".concat(activeElement.id, " not found"));
  }
}

/***/ }),

/***/ "./src/scss/machi_koro.scss":
/*!**********************************!*\
  !*** ./src/scss/machi_koro.scss ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 5:
/*!**********************************************!*\
  !*** multi ./src/scripts/hotkeys/machi_koro ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/pano/code/yucatahotkeys/build/src/scripts/hotkeys/machi_koro */"./src/scripts/hotkeys/machi_koro.js");


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NjcmlwdHMvZG9tLmpzIiwid2VicGFjazovLy8uL3NyYy9zY3JpcHRzL2hvdGtleXMvbWFjaGlfa29yby5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2Nzcy9tYWNoaV9rb3JvLnNjc3MiXSwibmFtZXMiOlsiZ2V0UG9wdXBCdXR0b24iLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiY2xpY2tCeVNlbGVjdG9yIiwic2VsZWN0b3IiLCJlbGVtZW50IiwicXVlcnlTZWxlY3RvciIsImNsaWNrIiwiY29uc29sZSIsImxvZyIsIndhaXRGb3JCb2FyZFRvRXhpc3RBbmRUaGVuIiwibWV0aG9kIiwiYm9hcmQiLCJzZXRUaW1lb3V0IiwiYmluZCIsIm1haW4iLCJzZWxlY3RDYXJkQnlTZWxlY3RvciIsImFkZENhcmRUb29sdGlwcyIsIm1hY2hpS29yb0hvdGtleXNNYXAiLCJrZXlDb21ib3MiLCJkZXNjcmlwdGlvbiIsInNlbGVjdENhcmRMZWZ0Iiwic2VsZWN0Q2FyZFJpZ2h0Iiwic2VsZWN0Q2FyZFVwIiwic2VsZWN0Q2FyZERvd24iLCJidXlTZWxlY3RlZENhcmQiLCJhY3RpdmVFbGVtZW50IiwiZ2V0U2VsZWN0ZWRDYXJkIiwiY2FyZEVsZW1lbnQiLCJjbGFzc0xpc3QiLCJhZGQiLCJyZW1vdmUiLCJjYXJkcyIsImdldENhcmRzRG9tIiwiZm9yRWFjaCIsImNhcmQiLCJjbG9uZSIsImNsb25lTm9kZSIsInBhcmVudEVsZW1lbnQiLCJpbnNlcnRCZWZvcmUiLCJuZXh0U2libGluZyIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJzZWxlY3RDYXJkQnlOdW1iZXIiLCJjYXJkTnVtYmVyIiwibmV4dENhcmRTZWxlY3RvciIsImdldENhcmROdW1iZXIiLCJyZWdleCIsImlkIiwibWF0Y2giLCJwYXJzZUludCIsImVycm9yIiwibmV4dENhcmROdW1iZXIiLCJjb250YWlucyIsInVuZG9CdXR0b24iLCJhbGVydCJdLCJtYXBwaW5ncyI6IjtRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBOzs7UUFHQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMENBQTBDLGdDQUFnQztRQUMxRTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLHdEQUF3RCxrQkFBa0I7UUFDMUU7UUFDQSxpREFBaUQsY0FBYztRQUMvRDs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EseUNBQXlDLGlDQUFpQztRQUMxRSxnSEFBZ0gsbUJBQW1CLEVBQUU7UUFDckk7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwyQkFBMkIsMEJBQTBCLEVBQUU7UUFDdkQsaUNBQWlDLGVBQWU7UUFDaEQ7UUFDQTtRQUNBOztRQUVBO1FBQ0Esc0RBQXNELCtEQUErRDs7UUFFckg7UUFDQTs7O1FBR0E7UUFDQTs7Ozs7Ozs7Ozs7OztBQ2xGQTtBQUFBO0FBQUE7QUFBQTtBQUFBOzs7O0FBSU8sSUFBTUEsY0FBYyxHQUFHLFNBQWpCQSxjQUFpQixHQUFLO0FBQy9CLFNBQU9DLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixhQUF4QixDQUFQO0FBQ0gsQ0FGTTtBQUlQOzs7OztBQUlPLFNBQVNDLGVBQVQsQ0FBeUJDLFFBQXpCLEVBQWtDO0FBQ3JDLE1BQU1DLE9BQU8sR0FBR0osUUFBUSxDQUFDSyxhQUFULENBQXVCRixRQUF2QixDQUFoQjs7QUFDQSxNQUFHQyxPQUFILEVBQVc7QUFDUEEsV0FBTyxDQUFDRSxLQUFSO0FBQ0gsR0FGRCxNQUVPO0FBQ0hDLFdBQU8sQ0FBQ0MsR0FBUixtQkFBdUJMLFFBQXZCO0FBQ0g7QUFDSjtBQUVEOzs7OztBQUlPLFNBQVNNLDBCQUFULENBQW9DQyxNQUFwQyxFQUEyQztBQUM5QyxNQUFNQyxLQUFLLEdBQUdYLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixPQUF4QixDQUFkOztBQUNBLE1BQUdVLEtBQUgsRUFBUztBQUNMSixXQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWjtBQUNBRSxVQUFNO0FBQ1QsR0FIRCxNQUdPO0FBQ0hILFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHdCQUFaO0FBQ0FJLGNBQVUsQ0FBQ0gsMEJBQTBCLENBQUNJLElBQTNCLENBQWdDLElBQWhDLEVBQXNDSCxNQUF0QyxDQUFELEVBQWdELEdBQWhELENBQVY7QUFDSDtBQUNKLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbENEO0FBQ0E7QUFFQTs7OztBQUdPLFNBQVNJLElBQVQsR0FBZTtBQUNsQkwseUVBQTBCLENBQUM7QUFBQSxXQUFLTSxvQkFBb0IsQ0FBQyxRQUFELENBQXpCO0FBQUEsR0FBRCxDQUExQjtBQUNBTix5RUFBMEIsQ0FBQ08sZUFBRCxDQUExQjtBQUNIO0FBRUQ7Ozs7QUFHTyxJQUFNQyxtQkFBbUIsR0FBRztBQUMvQiwyQkFBeUI7QUFDckJDLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FEVTtBQUVyQkMsZUFBVyxFQUFFLGlDQUZRO0FBR3JCVCxVQUFNLEVBQUU7QUFBQSxhQUFNUiw0REFBZSxDQUFDLFFBQUQsQ0FBckI7QUFBQTtBQUhhLEdBRE07QUFNL0IsMkJBQXlCO0FBQ3JCZ0IsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURVO0FBRXJCQyxlQUFXLEVBQUUsaUNBRlE7QUFHckJULFVBQU0sRUFBRTtBQUFBLGFBQU1SLDREQUFlLENBQUMsUUFBRCxDQUFyQjtBQUFBO0FBSGEsR0FOTTtBQVcvQiwyQkFBeUI7QUFDckJnQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlQsVUFBTSxFQUFFO0FBQUEsYUFBTVIsNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQVhNO0FBZ0IvQiwyQkFBeUI7QUFDckJnQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlQsVUFBTSxFQUFFO0FBQUEsYUFBTVIsNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQWhCTTtBQXFCL0IsMkJBQXlCO0FBQ3JCZ0IsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURVO0FBRXJCQyxlQUFXLEVBQUUsaUNBRlE7QUFHckJULFVBQU0sRUFBRTtBQUFBLGFBQU1SLDREQUFlLENBQUMsUUFBRCxDQUFyQjtBQUFBO0FBSGEsR0FyQk07QUEwQi9CLDJCQUF5QjtBQUNyQmdCLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FEVTtBQUVyQkMsZUFBVyxFQUFFLGlDQUZRO0FBR3JCVCxVQUFNLEVBQUU7QUFBQSxhQUFNUiw0REFBZSxDQUFDLFFBQUQsQ0FBckI7QUFBQTtBQUhhLEdBMUJNO0FBK0IvQiwyQkFBeUI7QUFDckJnQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlQsVUFBTSxFQUFFO0FBQUEsYUFBTVIsNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQS9CTTtBQW9DL0IsMkJBQXlCO0FBQ3JCZ0IsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURVO0FBRXJCQyxlQUFXLEVBQUUsaUNBRlE7QUFHckJULFVBQU0sRUFBRTtBQUFBLGFBQU1SLDREQUFlLENBQUMsUUFBRCxDQUFyQjtBQUFBO0FBSGEsR0FwQ007QUF5Qy9CLDJCQUF5QjtBQUNyQmdCLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FEVTtBQUVyQkMsZUFBVyxFQUFFLGlDQUZRO0FBR3JCVCxVQUFNLEVBQUU7QUFBQSxhQUFNUiw0REFBZSxDQUFDLFFBQUQsQ0FBckI7QUFBQTtBQUhhLEdBekNNO0FBOEMvQiw0QkFBMEI7QUFDdEJnQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFc7QUFFdEJDLGVBQVcsRUFBRSxhQUZTO0FBR3RCVCxVQUFNLEVBQUU7QUFBQSxhQUFNUiw0REFBZSxDQUFDLE9BQUQsQ0FBckI7QUFBQTtBQUhjLEdBOUNLO0FBbUQvQiwwQkFBd0I7QUFDcEJnQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFM7QUFFcEJDLGVBQVcsRUFBRSx3QkFGTztBQUdwQlQsVUFBTSxFQUFFO0FBQUEsYUFBTVIsNERBQWUsQ0FBQyxjQUFELENBQXJCO0FBQUE7QUFIWSxHQW5ETztBQXdEL0IsNEJBQTBCO0FBQ3RCZ0IsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURXO0FBRXRCQyxlQUFXLEVBQUUsMEJBRlM7QUFHdEJULFVBQU0sRUFBRTtBQUFBLGFBQU1SLDREQUFlLENBQUMsbUJBQUQsQ0FBckI7QUFBQTtBQUhjLEdBeERLO0FBNkQvQixtQ0FBaUM7QUFDN0JnQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRGtCO0FBRTdCQyxlQUFXLEVBQUUsNEJBRmdCO0FBRzdCVCxVQUFNLEVBQUU7QUFBQSxhQUFNUiw0REFBZSxDQUFDLHNCQUFELENBQXJCO0FBQUE7QUFIcUIsR0E3REY7QUFrRS9CLGlDQUErQjtBQUMzQmdCLGFBQVMsRUFBRSxDQUFDLFdBQUQsQ0FEZ0I7QUFFM0JDLGVBQVcsRUFBRSxrQkFGYztBQUczQlQsVUFBTSxFQUFFO0FBQUEsYUFBTVUsY0FBYyxFQUFwQjtBQUFBO0FBSG1CLEdBbEVBO0FBdUUvQixrQ0FBZ0M7QUFDNUJGLGFBQVMsRUFBRSxDQUFDLFlBQUQsQ0FEaUI7QUFFNUJDLGVBQVcsRUFBRSxtQkFGZTtBQUc1QlQsVUFBTSxFQUFFO0FBQUEsYUFBTVcsZUFBZSxFQUFyQjtBQUFBO0FBSG9CLEdBdkVEO0FBNEUvQiwrQkFBNkI7QUFDekJILGFBQVMsRUFBRSxDQUFDLFNBQUQsQ0FEYztBQUV6QkMsZUFBVyxFQUFFLGlCQUZZO0FBR3pCVCxVQUFNLEVBQUU7QUFBQSxhQUFNWSxZQUFZLEVBQWxCO0FBQUE7QUFIaUIsR0E1RUU7QUFpRi9CLGlDQUErQjtBQUMzQkosYUFBUyxFQUFFLENBQUMsV0FBRCxDQURnQjtBQUUzQkMsZUFBVyxFQUFFLG9CQUZjO0FBRzNCVCxVQUFNLEVBQUU7QUFBQSxhQUFNYSxjQUFjLEVBQXBCO0FBQUE7QUFIbUIsR0FqRkE7QUFzRi9CLGtDQUFnQztBQUM1QkwsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURpQjtBQUU1QkMsZUFBVyxFQUFFLG1CQUZlO0FBRzVCVCxVQUFNLEVBQUU7QUFBQSxhQUFNYyxlQUFlLEVBQXJCO0FBQUE7QUFIb0I7QUF0RkQsQ0FBNUI7QUE2RlA7Ozs7O0FBSU8sU0FBU1Qsb0JBQVQsQ0FBOEJaLFFBQTlCLEVBQXVDO0FBQzFDLE1BQU1zQixhQUFhLEdBQUdDLGVBQWUsRUFBckM7QUFDQSxNQUFNQyxXQUFXLEdBQUczQixRQUFRLENBQUNLLGFBQVQsQ0FBdUJGLFFBQXZCLENBQXBCOztBQUNBLE1BQUd3QixXQUFILEVBQWU7QUFDWEEsZUFBVyxDQUFDQyxTQUFaLENBQXNCQyxHQUF0QixDQUEwQixjQUExQjs7QUFDQSxRQUFHSixhQUFILEVBQWlCO0FBQ2JBLG1CQUFhLENBQUNHLFNBQWQsQ0FBd0JFLE1BQXhCLENBQWdDLGNBQWhDO0FBQ0g7QUFDSjtBQUNKO0FBRUQ7Ozs7QUFHQSxTQUFTZCxlQUFULEdBQTJCO0FBQ3ZCLE1BQU1lLEtBQUssR0FBR0MsV0FBVyxFQUF6QjtBQUNBRCxPQUFLLENBQUNFLE9BQU4sQ0FBYyxVQUFBQyxJQUFJLEVBQUk7QUFDbEIsUUFBTUMsS0FBSyxHQUFHRCxJQUFJLENBQUM3QixhQUFMLENBQW1CLFdBQW5CLEVBQWdDK0IsU0FBaEMsRUFBZDtBQUNBRCxTQUFLLENBQUNQLFNBQU4sQ0FBZ0JDLEdBQWhCLENBQW9CLFlBQXBCO0FBQ0FLLFFBQUksQ0FBQ0csYUFBTCxDQUFtQkMsWUFBbkIsQ0FBZ0NILEtBQWhDLEVBQXVDRCxJQUFJLENBQUNLLFdBQTVDO0FBQ0gsR0FKRDtBQUtIO0FBRUQ7Ozs7OztBQUlBLFNBQVNQLFdBQVQsR0FBdUI7QUFDbkIsNEJBQVdoQyxRQUFRLENBQUN3QyxnQkFBVCxDQUEwQixnQkFBMUIsQ0FBWDtBQUNIO0FBRUQ7Ozs7OztBQUlPLFNBQVNkLGVBQVQsR0FBMEI7QUFDN0IsU0FBTzFCLFFBQVEsQ0FBQ0ssYUFBVCxDQUF3QixlQUF4QixDQUFQO0FBQ0g7QUFFRDs7Ozs7QUFJTyxTQUFTb0Msa0JBQVQsQ0FBNEJDLFVBQTVCLEVBQXVDO0FBQzFDLE1BQU1DLGdCQUFnQixrQkFBV0QsVUFBWCxDQUF0QjtBQUNBM0Isc0JBQW9CLENBQUM0QixnQkFBRCxDQUFwQjtBQUNIO0FBRUQ7Ozs7OztBQUtPLFNBQVNDLGFBQVQsQ0FBdUJ4QyxPQUF2QixFQUErQjtBQUNsQyxNQUFNeUMsS0FBSyxHQUFHLE1BQWQ7O0FBQ0EsTUFBR3pDLE9BQUgsRUFBVztBQUNQLFFBQU1zQyxVQUFVLEdBQUd0QyxPQUFPLENBQUMwQyxFQUFSLENBQVdDLEtBQVgsQ0FBaUJGLEtBQWpCLEVBQXdCLENBQXhCLENBQW5COztBQUNBLFFBQUc7QUFDQyxhQUFPRyxRQUFRLENBQUNOLFVBQUQsQ0FBZjtBQUNILEtBRkQsQ0FFRSxPQUFNTyxLQUFOLEVBQVk7QUFDVjFDLGFBQU8sQ0FBQ0MsR0FBUixXQUFlSixPQUFPLENBQUMwQyxFQUF2QjtBQUNBLGFBQU8sSUFBUDtBQUNIO0FBQ0o7O0FBQ0QsU0FBTyxJQUFQO0FBQ0g7QUFFRDs7OztBQUdPLFNBQVMxQixjQUFULEdBQXlCO0FBQzVCLE1BQU1LLGFBQWEsR0FBR0MsZUFBZSxFQUFyQztBQUNBLE1BQU13QixjQUFjLEdBQUdOLGFBQWEsQ0FBQ25CLGFBQUQsQ0FBYixHQUErQixDQUF0RDtBQUVBZ0Isb0JBQWtCLENBQUNTLGNBQUQsQ0FBbEI7QUFDSDtBQUVEOzs7O0FBR08sU0FBUzdCLGVBQVQsR0FBMEI7QUFDN0IsTUFBTUksYUFBYSxHQUFHQyxlQUFlLEVBQXJDO0FBQ0EsTUFBTXdCLGNBQWMsR0FBR04sYUFBYSxDQUFDbkIsYUFBRCxDQUFiLEdBQStCLENBQXREO0FBRUFnQixvQkFBa0IsQ0FBQ1MsY0FBRCxDQUFsQjtBQUNIO0FBRUQ7Ozs7QUFHTyxTQUFTNUIsWUFBVCxHQUF1QjtBQUMxQixNQUFNRyxhQUFhLEdBQUdDLGVBQWUsRUFBckM7QUFDQSxNQUFNd0IsY0FBYyxHQUFHTixhQUFhLENBQUNuQixhQUFELENBQWIsR0FBK0IsQ0FBdEQ7QUFFQWdCLG9CQUFrQixDQUFDUyxjQUFELENBQWxCO0FBQ0g7QUFFRDs7OztBQUdPLFNBQVMzQixjQUFULEdBQXlCO0FBQzVCLE1BQU1FLGFBQWEsR0FBR0MsZUFBZSxFQUFyQztBQUNBLE1BQU13QixjQUFjLEdBQUdOLGFBQWEsQ0FBQ25CLGFBQUQsQ0FBYixHQUErQixDQUF0RDtBQUVBZ0Isb0JBQWtCLENBQUNTLGNBQUQsQ0FBbEI7QUFDSDtBQUVEOzs7O0FBR08sU0FBUzFCLGVBQVQsR0FBMEI7QUFDN0IsTUFBTUMsYUFBYSxHQUFHekIsUUFBUSxDQUFDSyxhQUFULENBQXdCLGVBQXhCLENBQXRCO0FBQ0FFLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFzQmlCLGFBQWEsQ0FBQ3FCLEVBQWhEOztBQUNBLE1BQUdyQixhQUFILEVBQWlCO0FBQ2IsUUFBSUEsYUFBYSxDQUFDRyxTQUFkLENBQXdCdUIsUUFBeEIsQ0FBaUMsUUFBakMsQ0FBSixFQUNBO0FBQ0k1QyxhQUFPLENBQUNDLEdBQVIsQ0FBWSxnQ0FBWjtBQUNBaUIsbUJBQWEsQ0FBQ25CLEtBQWQ7QUFDQUMsYUFBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUNILEtBTEQsTUFNSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FELGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHNDQUFaO0FBQ0EsVUFBTTRDLFVBQVUsR0FBR3BELFFBQVEsQ0FBQ0ssYUFBVCxDQUF1QixXQUF2QixDQUFuQjs7QUFDQSxVQUFJK0MsVUFBSixFQUFlO0FBQ1hDLGFBQUssQ0FBQywrQkFBRCxDQUFMLENBRFcsQ0FFWDtBQUNBO0FBQ0gsT0FKRCxNQUtJO0FBQ0FBLGFBQUssQ0FBQyxzREFBRCxDQUFMO0FBQ0g7QUFDSjtBQUNKLEdBdkJELE1BdUJPO0FBQ0g5QyxXQUFPLENBQUNDLEdBQVIsbUJBQXVCaUIsYUFBYSxDQUFDcUIsRUFBckM7QUFDSDtBQUNKLEM7Ozs7Ozs7Ozs7O0FDMVBELHVDIiwiZmlsZSI6InNjcmlwdHMvbWFjaGlfa29yby5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0ge307XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiL1wiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gNSk7XG4iLCIvKipcbiAqIFJldHVybiB0aGUgZG9tIG5vZGUgb2YgdGhlIGJ1dHRvbiBpbiB0aGUgcG9wdXBcbiAqIEByZXR1cm5zIHtIVE1MRWxlbWVudH1cbiAqL1xuZXhwb3J0IGNvbnN0IGdldFBvcHVwQnV0dG9uID0gKCkgPT57XG4gICAgcmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicG9wdXBCdXR0b25cIik7XG59O1xuXG4vKipcbiAqIENsaWNrIHRoZSBlbGVtZW50IGluIHRoZSBzZWxlY3RvciBpZiBpdCBpcyBmb3VuZFxuICogQHBhcmFtIHtzdHJpbmd9IHNlbGVjdG9yXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjbGlja0J5U2VsZWN0b3Ioc2VsZWN0b3Ipe1xuICAgIGNvbnN0IGVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHNlbGVjdG9yKTtcbiAgICBpZihlbGVtZW50KXtcbiAgICAgICAgZWxlbWVudC5jbGljaygpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBFbGVtZW50ICR7c2VsZWN0b3J9IG5vdCBmb3VuZGApO1xuICAgIH1cbn1cblxuLyoqXG4gKiBXYWl0IGZvciB0aGUgYm9hcmQgRE9NIGVsZW1lbnQgdG8gZXhpc3QsIGFuZCB0aGVuIGV4ZWN1dGUgdGhlIG1ldGhvZCBwYXNzZWRcbiAqIEBwYXJhbSB7ZnVuY3Rpb259IG1ldGhvZFxuICovXG5leHBvcnQgZnVuY3Rpb24gd2FpdEZvckJvYXJkVG9FeGlzdEFuZFRoZW4obWV0aG9kKXtcbiAgICBjb25zdCBib2FyZCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYm9hcmRcIik7XG4gICAgaWYoYm9hcmQpe1xuICAgICAgICBjb25zb2xlLmxvZyhcIkJvYXJkIGlzIHJlYWR5LlwiKTtcbiAgICAgICAgbWV0aG9kKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJObyBib2FyZCB5ZXQsIHdhaXRpbmcuXCIpO1xuICAgICAgICBzZXRUaW1lb3V0KHdhaXRGb3JCb2FyZFRvRXhpc3RBbmRUaGVuLmJpbmQodGhpcywgbWV0aG9kKSwgNTAwKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgJy4uLy4uL3Njc3MvbWFjaGlfa29yby5zY3NzJztcbmltcG9ydCB7Y2xpY2tCeVNlbGVjdG9yLCB3YWl0Rm9yQm9hcmRUb0V4aXN0QW5kVGhlbn0gZnJvbSBcIi4uL2RvbVwiO1xuXG4vKipcbiAqIE1haW4gbWV0aG9kIHRvIGJlIGV4ZWN1dGVkIChieSBjb250ZW50LmpzKVxuICovXG5leHBvcnQgZnVuY3Rpb24gbWFpbigpe1xuICAgIHdhaXRGb3JCb2FyZFRvRXhpc3RBbmRUaGVuKCgpPT4gc2VsZWN0Q2FyZEJ5U2VsZWN0b3IoXCIjY2FyZDFcIikpO1xuICAgIHdhaXRGb3JCb2FyZFRvRXhpc3RBbmRUaGVuKGFkZENhcmRUb29sdGlwcyk7XG59XG5cbi8qKlxuICogSG90a2V5IG1hcCBmb3IgbWFjaGkga29ybyBvbmx5XG4gKi9cbmV4cG9ydCBjb25zdCBtYWNoaUtvcm9Ib3RrZXlzTWFwID0ge1xuICAgIFwibWFjaGlfa29yb19idXlfc2xvdF8xXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCIxXCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJCdXkgQ2FyZCBpbiBTbG90IDEgKE1hY2hpIEtvcm8pXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2NhcmQxXCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fYnV5X3Nsb3RfMlwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiMlwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQnV5IENhcmQgaW4gU2xvdCAyIChNYWNoaSBLb3JvKVwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNjYXJkMlwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX2J1eV9zbG90XzNcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIjNcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkJ1eSBDYXJkIGluIFNsb3QgMyAoTWFjaGkgS29ybylcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjY2FyZDNcIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19idXlfc2xvdF80XCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCI0XCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJCdXkgQ2FyZCBpbiBTbG90IDQgKE1hY2hpIEtvcm8pXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2NhcmQ0XCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fYnV5X3Nsb3RfNVwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiNVwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQnV5IENhcmQgaW4gU2xvdCA1IChNYWNoaSBLb3JvKVwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNjYXJkNVwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX2J1eV9zbG90XzZcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIjZcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkJ1eSBDYXJkIGluIFNsb3QgNiAoTWFjaGkgS29ybylcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjY2FyZDZcIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19idXlfc2xvdF83XCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCI3XCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJCdXkgQ2FyZCBpbiBTbG90IDcgKE1hY2hpIEtvcm8pXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2NhcmQ3XCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fYnV5X3Nsb3RfOFwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiOFwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQnV5IENhcmQgaW4gU2xvdCA4IChNYWNoaSBLb3JvKVwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNjYXJkOFwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX2J1eV9zbG90XzlcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIjlcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkJ1eSBDYXJkIGluIFNsb3QgOSAoTWFjaGkgS29ybylcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjY2FyZDlcIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb190b2dnbGVfZGljZVwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiZFwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiVG9nZ2xlIERpY2VcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjZGllMlwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX3JvbGxfZGljZVwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiclwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiSGl0ICdSb2xsIGRpY2UnIGJ1dHRvblwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNidG5fV8O8cmZlbG5cIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19yZXJvbGxfZGljZVwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wicVwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiSGl0ICdSZXJvbGwgZGljZScgYnV0dG9uXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2J0bl9CdG5Sb2xsQWdhaW5cIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19kb19ub3RfcmVyb2xsX2RpY2VcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIndcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkhpdCAnRG8gTm90IFJlcm9sbCcgYnV0dG9uXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2J0bl9CdG5Sb2xsTm90QWdhaW5cIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19zZWxlY3RfY2FyZF9sZWZ0XCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCJBcnJvd0xlZnRcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlNlbGVjdCBMZWZ0IENhcmRcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBzZWxlY3RDYXJkTGVmdCgpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fc2VsZWN0X2NhcmRfcmlnaHRcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIkFycm93UmlnaHRcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlNlbGVjdCBSaWdodCBDYXJkXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gc2VsZWN0Q2FyZFJpZ2h0KClcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19zZWxlY3RfY2FyZF91cFwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiQXJyb3dVcFwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiU2VsZWN0IFRvcCBDYXJkXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gc2VsZWN0Q2FyZFVwKClcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19zZWxlY3RfY2FyZF9kb3duXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCJBcnJvd0Rvd25cIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlNlbGVjdCBCb3R0b20gQ2FyZFwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IHNlbGVjdENhcmREb3duKClcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19idXlfc2VsZWN0ZWRfY2FyZFwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiYlwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQnV5IFNlbGVjdGVkIENhcmRcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBidXlTZWxlY3RlZENhcmQoKVxuICAgIH1cbn07XG5cbi8qKlxuICogQWRkIHRoZSBcInNlbGVjdGVkQ2FyZFwiIGNsYXNzIHRvIHRoZSBlbGVtZW50IG1hdGNoZWQgYnkgdGhlIHNlbGVjdG9yIChpZiBhbnkpXG4gKiBAcGFyYW0ge3N0cmluZ30gc2VsZWN0b3JcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNlbGVjdENhcmRCeVNlbGVjdG9yKHNlbGVjdG9yKXtcbiAgICBjb25zdCBhY3RpdmVFbGVtZW50ID0gZ2V0U2VsZWN0ZWRDYXJkKCk7XG4gICAgY29uc3QgY2FyZEVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHNlbGVjdG9yKTtcbiAgICBpZihjYXJkRWxlbWVudCl7XG4gICAgICAgIGNhcmRFbGVtZW50LmNsYXNzTGlzdC5hZGQoXCJzZWxlY3RlZENhcmRcIik7XG4gICAgICAgIGlmKGFjdGl2ZUVsZW1lbnQpe1xuICAgICAgICAgICAgYWN0aXZlRWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCBcInNlbGVjdGVkQ2FyZFwiICk7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi8qKlxuICogQWRkcyBjYXJkIHRvb2x0aXBzIG9uIGhvdmVyICh6b29tZWQgaW4gY2FyZHMpXG4gKi9cbmZ1bmN0aW9uIGFkZENhcmRUb29sdGlwcygpIHtcbiAgICBjb25zdCBjYXJkcyA9IGdldENhcmRzRG9tKCk7XG4gICAgY2FyZHMuZm9yRWFjaChjYXJkID0+IHtcbiAgICAgICAgY29uc3QgY2xvbmUgPSBjYXJkLnF1ZXJ5U2VsZWN0b3IoXCIuY2FyZCBpbWdcIikuY2xvbmVOb2RlKCk7XG4gICAgICAgIGNsb25lLmNsYXNzTGlzdC5hZGQoXCJjYXJkWm9vbWVkXCIpO1xuICAgICAgICBjYXJkLnBhcmVudEVsZW1lbnQuaW5zZXJ0QmVmb3JlKGNsb25lLCBjYXJkLm5leHRTaWJsaW5nKTtcbiAgICB9KVxufVxuXG4vKipcbiAqXG4gKiBAcmV0dXJucyB7Tm9kZUxpc3RPZjxFbGVtZW50Pn1cbiAqL1xuZnVuY3Rpb24gZ2V0Q2FyZHNEb20oKSB7XG4gICAgcmV0dXJuIFsuLi5kb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLmNhcmRDb250YWluZXJcIildO1xufVxuXG4vKipcbiAqIFJldHVybiB0aGUgY2FyZCB0aGF0IGlzIGN1cnJlbnRseSBzZWxlY3RlZCAoaGFzIHRoZSBjbGFzcyBzZWxlY3RlZENhcmQpXG4gKiBAcmV0dXJucyB7RWxlbWVudH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFNlbGVjdGVkQ2FyZCgpe1xuICAgIHJldHVybiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCBcIi5zZWxlY3RlZENhcmRcIik7XG59XG5cbi8qKlxuICogU2VsZWN0IGEgY2FyZCBiYXNlZCBvbiB0aGUgbnVtYmVyIHByb3ZpZGVkXG4gKiBAcGFyYW0ge251bWJlcn0gY2FyZE51bWJlclxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0Q2FyZEJ5TnVtYmVyKGNhcmROdW1iZXIpe1xuICAgIGNvbnN0IG5leHRDYXJkU2VsZWN0b3IgPSBgI2NhcmQke2NhcmROdW1iZXJ9YDtcbiAgICBzZWxlY3RDYXJkQnlTZWxlY3RvcihuZXh0Q2FyZFNlbGVjdG9yKTtcbn1cblxuLyoqXG4gKiBSZXR1cm4gdGhlIGNhcmQgbnVtYmVyIGZvciB0aGUgcHJvdmlkZWQgZWxlbWVudFxuICogQHBhcmFtIHtFbGVtZW50fSBlbGVtZW50XG4gKiBAcmV0dXJucyB7bnVtYmVyfVxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q2FyZE51bWJlcihlbGVtZW50KXtcbiAgICBjb25zdCByZWdleCA9IC9cXGQrJC87XG4gICAgaWYoZWxlbWVudCl7XG4gICAgICAgIGNvbnN0IGNhcmROdW1iZXIgPSBlbGVtZW50LmlkLm1hdGNoKHJlZ2V4KVswXTtcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgcmV0dXJuIHBhcnNlSW50KGNhcmROdW1iZXIpO1xuICAgICAgICB9IGNhdGNoKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGAke2VsZW1lbnQuaWR9IGRpZCBub3QgaGF2ZSBhIG51bWJlciBhdCB0aGUgZW5kIG9mIGl0cyBJRGApO1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59XG5cbi8qKlxuICogU2VsZWN0IHRoZSBjYXJkIHRvIHRoZSBsZWZ0IG9mIHRoZSBhY3RpdmUgY2FyZFxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0Q2FyZExlZnQoKXtcbiAgICBjb25zdCBhY3RpdmVFbGVtZW50ID0gZ2V0U2VsZWN0ZWRDYXJkKCk7XG4gICAgY29uc3QgbmV4dENhcmROdW1iZXIgPSBnZXRDYXJkTnVtYmVyKGFjdGl2ZUVsZW1lbnQpIC0gMTtcblxuICAgIHNlbGVjdENhcmRCeU51bWJlcihuZXh0Q2FyZE51bWJlcik7XG59XG5cbi8qKlxuICogU2VsZWN0IHRoZSBjYXJkIHRvIHRoZSByaWdodCBvZiB0aGUgYWN0aXZlIGNhcmRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNlbGVjdENhcmRSaWdodCgpe1xuICAgIGNvbnN0IGFjdGl2ZUVsZW1lbnQgPSBnZXRTZWxlY3RlZENhcmQoKTtcbiAgICBjb25zdCBuZXh0Q2FyZE51bWJlciA9IGdldENhcmROdW1iZXIoYWN0aXZlRWxlbWVudCkgKyAxO1xuXG4gICAgc2VsZWN0Q2FyZEJ5TnVtYmVyKG5leHRDYXJkTnVtYmVyKTtcbn1cblxuLyoqXG4gKiBTZWxlY3QgdGhlIGNhcmQgdG8gdGhlIHVwIG9mIHRoZSBhY3RpdmUgY2FyZFxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0Q2FyZFVwKCl7XG4gICAgY29uc3QgYWN0aXZlRWxlbWVudCA9IGdldFNlbGVjdGVkQ2FyZCgpO1xuICAgIGNvbnN0IG5leHRDYXJkTnVtYmVyID0gZ2V0Q2FyZE51bWJlcihhY3RpdmVFbGVtZW50KSAtIDU7XG5cbiAgICBzZWxlY3RDYXJkQnlOdW1iZXIobmV4dENhcmROdW1iZXIpO1xufVxuXG4vKipcbiAqIFNlbGVjdCB0aGUgY2FyZCB0byB0aGUgZG93biBvZiB0aGUgYWN0aXZlIGNhcmRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNlbGVjdENhcmREb3duKCl7XG4gICAgY29uc3QgYWN0aXZlRWxlbWVudCA9IGdldFNlbGVjdGVkQ2FyZCgpO1xuICAgIGNvbnN0IG5leHRDYXJkTnVtYmVyID0gZ2V0Q2FyZE51bWJlcihhY3RpdmVFbGVtZW50KSArIDU7XG5cbiAgICBzZWxlY3RDYXJkQnlOdW1iZXIobmV4dENhcmROdW1iZXIpO1xufVxuXG4vKipcbiAqIEJ1eSB0aGUgY2FyZCB0aGF0IGlzIGN1cnJlbnRseSBzZWxlY3RlZFxuICovXG5leHBvcnQgZnVuY3Rpb24gYnV5U2VsZWN0ZWRDYXJkKCl7XG4gICAgY29uc3QgYWN0aXZlRWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoIFwiLnNlbGVjdGVkQ2FyZFwiKTtcbiAgICBjb25zb2xlLmxvZyhcIk9rIEkgd2FudCB0byBidXkgXCIgKyBhY3RpdmVFbGVtZW50LmlkKTtcbiAgICBpZihhY3RpdmVFbGVtZW50KXtcbiAgICAgICAgaWYgKGFjdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKFwiYWN0aXZlXCIpKVxuICAgICAgICB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkl0J3MgYWN0aXZlLCBzdXJlLCBJJ2xsIGJ1eSBpdFwiKTtcbiAgICAgICAgICAgIGFjdGl2ZUVsZW1lbnQuY2xpY2soKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2xpY2tcIik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIC8vIGF1dG8gYnZnYWluZWkgYW5cbiAgICAgICAgICAgIC8vIDEuIGRlbiBlaW5haSBhdmFpbGFibGUgYXV0aFxuICAgICAgICAgICAgLy8gMi4gZXhlaXMgYWdvcmFzZWkgaGRoICAqKiDOsc69IM+Fz4DOsc+Bz4fOtc65IM66zr/Phc68z4DOryDOsc69z4TOv8+NIFwiI2J0bl91bmRvXCJcbiAgICAgICAgICAgIC8vIDMuIGRlbiBlaW5haSBoIHNlaXJhIHNvdSAtLSBhdXRvIGlzd3MgdG8gbHlub3ltZSBtZSB0byBuYSB0c2VrYXJvdW1lIHNlaXJhIGFwbyBwcmluXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkRvZXNuJ3Qgc2VlbSB0byBiZSBhdmFpbGFibGUgdGhvdWdoLlwiKTtcbiAgICAgICAgICAgIGNvbnN0IHVuZG9CdXR0b24gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2J0bl91bmRvXCIpO1xuICAgICAgICAgICAgaWYgKHVuZG9CdXR0b24pe1xuICAgICAgICAgICAgICAgIGFsZXJ0KFwiWW91J3ZlIGFscmVhZHkgY2hvc2VuIGEgY2FyZC5cIik7XG4gICAgICAgICAgICAgICAgLy8gYW4gdmdhbG91bWUgdG8gYmxlIG90YW4gZGVuIGVpbmFpIGggc2VpcmEgc291IGRlIHhyZWlhemV0YWkgYXV0b1xuICAgICAgICAgICAgICAgIC8vIGFsbGEgcHJlcGVpIG5hIHhhbmFnaW5ldGFpIGJsZSBvdGFuIGVpbmFpIGggc2VpcmEgc291XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNle1xuICAgICAgICAgICAgICAgIGFsZXJ0KFwiWW91IGNhbid0IGJ1eSB0aGlzIG9uZSA6KCBcXG5DaG9zZSBhbiBhdmFpbGFibGUgY2FyZC5cIik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZyhgRWxlbWVudCAke2FjdGl2ZUVsZW1lbnQuaWR9IG5vdCBmb3VuZGApO1xuICAgIH1cbn1cbiIsIi8vIGV4dHJhY3RlZCBieSBtaW5pLWNzcy1leHRyYWN0LXBsdWdpbiJdLCJzb3VyY2VSb290IjoiIn0=