/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/scripts/dom.js":
/*!****************************!*\
  !*** ./src/scripts/dom.js ***!
  \****************************/
/*! exports provided: getPopupButton, clickBySelector, waitForBoardToExistAndThen */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPopupButton", function() { return getPopupButton; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clickBySelector", function() { return clickBySelector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "waitForBoardToExistAndThen", function() { return waitForBoardToExistAndThen; });
/**
 * Return the dom node of the button in the popup
 * @returns {HTMLElement}
 */
var getPopupButton = function getPopupButton() {
  return document.getElementById("popupButton");
};
/**
 * Click the element in the selector if it is found
 * @param {string} selector
 */

function clickBySelector(selector) {
  var element = document.querySelector(selector);

  if (element) {
    element.click();
  } else {
    console.log("Element ".concat(selector, " not found"));
  }
}
/**
 * Wait for the board DOM element to exist, and then execute the method passed
 * @param {function} method
 */

function waitForBoardToExistAndThen(method) {
  var board = document.getElementById("board");

  if (board) {
    console.log("Board is ready.");
    method();
  } else {
    console.log("No board yet, waiting.");
    setTimeout(waitForBoardToExistAndThen.bind(this, method), 500);
  }
}

/***/ }),

/***/ "./src/scripts/hotkeys/machi_koro.js":
/*!*******************************************!*\
  !*** ./src/scripts/hotkeys/machi_koro.js ***!
  \*******************************************/
/*! exports provided: main, machiKoroHotkeysMap, selectCardBySelector, getSelectedCard, selectCardByNumber, getCardNumber, selectCardLeft, selectCardRight, selectCardUp, selectCardDown, buySelectedCard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "main", function() { return main; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "machiKoroHotkeysMap", function() { return machiKoroHotkeysMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardBySelector", function() { return selectCardBySelector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSelectedCard", function() { return getSelectedCard; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardByNumber", function() { return selectCardByNumber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCardNumber", function() { return getCardNumber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardLeft", function() { return selectCardLeft; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardRight", function() { return selectCardRight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardUp", function() { return selectCardUp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardDown", function() { return selectCardDown; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "buySelectedCard", function() { return buySelectedCard; });
/* harmony import */ var _scss_machi_koro_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../scss/machi_koro.scss */ "./src/scss/machi_koro.scss");
/* harmony import */ var _scss_machi_koro_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_scss_machi_koro_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../dom */ "./src/scripts/dom.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }



/**
 * Main method to be executed (by content.js)
 */

function main() {
  Object(_dom__WEBPACK_IMPORTED_MODULE_1__["waitForBoardToExistAndThen"])(function () {
    return selectCardBySelector("#card1");
  });
  Object(_dom__WEBPACK_IMPORTED_MODULE_1__["waitForBoardToExistAndThen"])(addCardTooltips);
}
/**
 * Hotkey map for machi koro only
 */

var machiKoroHotkeysMap = {
  "machi_koro_buy_slot_1": {
    keyCombos: ["1"],
    description: "Buy Card in Slot 1 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card1");
    }
  },
  "machi_koro_buy_slot_2": {
    keyCombos: ["2"],
    description: "Buy Card in Slot 2 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card2");
    }
  },
  "machi_koro_buy_slot_3": {
    keyCombos: ["3"],
    description: "Buy Card in Slot 3 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card3");
    }
  },
  "machi_koro_buy_slot_4": {
    keyCombos: ["4"],
    description: "Buy Card in Slot 4 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card4");
    }
  },
  "machi_koro_buy_slot_5": {
    keyCombos: ["5"],
    description: "Buy Card in Slot 5 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card5");
    }
  },
  "machi_koro_buy_slot_6": {
    keyCombos: ["6"],
    description: "Buy Card in Slot 6 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card6");
    }
  },
  "machi_koro_buy_slot_7": {
    keyCombos: ["7"],
    description: "Buy Card in Slot 7 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card7");
    }
  },
  "machi_koro_buy_slot_8": {
    keyCombos: ["8"],
    description: "Buy Card in Slot 8 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card8");
    }
  },
  "machi_koro_buy_slot_9": {
    keyCombos: ["9"],
    description: "Buy Card in Slot 9 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card9");
    }
  },
  "machi_koro_toggle_dice": {
    keyCombos: ["d"],
    description: "Toggle Dice",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#die2");
    }
  },
  "machi_koro_roll_dice": {
    keyCombos: ["r"],
    description: "Hit 'Roll dice' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#btn_Würfeln");
    }
  },
  "machi_koro_reroll_dice": {
    keyCombos: ["q"],
    description: "Hit 'Reroll dice' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#btn_BtnRollAgain");
    }
  },
  "machi_koro_do_not_reroll_dice": {
    keyCombos: ["w"],
    description: "Hit 'Do Not Reroll' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#btn_BtnRollNotAgain");
    }
  },
  "machi_koro_select_card_left": {
    keyCombos: ["left"],
    description: "Select Left Card",
    method: function method() {
      return selectCardLeft();
    }
  },
  "machi_koro_select_card_right": {
    keyCombos: ["right"],
    description: "Select Right Card",
    method: function method() {
      return selectCardRight();
    }
  },
  "machi_koro_select_card_up": {
    keyCombos: ["up"],
    description: "Select Top Card",
    method: function method() {
      return selectCardUp();
    }
  },
  "machi_koro_select_card_down": {
    keyCombos: ["down"],
    description: "Select Bottom Card",
    method: function method() {
      return selectCardDown();
    }
  },
  "machi_koro_buy_selected_card": {
    keyCombos: ["b"],
    description: "Buy Selected Card",
    method: function method() {
      return buySelectedCard();
    }
  }
};
/**
 * Add the "selectedCard" class to the element matched by the selector (if any)
 * @param {string} selector
 */

function selectCardBySelector(selector) {
  var activeElement = getSelectedCard();
  var cardElement = document.querySelector(selector);

  if (cardElement) {
    cardElement.classList.add("selectedCard");

    if (activeElement) {
      activeElement.classList.remove("selectedCard");
    }
  }
}
/**
 * Adds card tooltips on hover (zoomed in cards)
 */

function addCardTooltips() {
  var cards = getCardsDom();
  cards.forEach(function (card) {
    var clone = card.querySelector(".card img").cloneNode();
    clone.classList.add("cardZoomed");
    card.parentElement.insertBefore(clone, card.nextSibling);
  });
}
/**
 *
 * @returns {NodeListOf<Element>}
 */


function getCardsDom() {
  return _toConsumableArray(document.querySelectorAll(".cardContainer"));
}
/**
 * Return the card that is currently selected (has the class selectedCard)
 * @returns {Element}
 */


function getSelectedCard() {
  return document.querySelector(".selectedCard");
}
/**
 * Select a card based on the number provided
 * @param {number} cardNumber
 */

function selectCardByNumber(cardNumber) {
  var nextCardSelector = "#card".concat(cardNumber);
  selectCardBySelector(nextCardSelector);
}
/**
 * Return the card number for the provided element
 * @param {Element} element
 * @returns {number}
 */

function getCardNumber(element) {
  var regex = /\d+$/;

  if (element) {
    var cardNumber = element.id.match(regex)[0];

    try {
      return parseInt(cardNumber);
    } catch (error) {
      console.log("".concat(element.id, " did not have a number at the end of its ID"));
      return null;
    }
  }

  return null;
}
/**
 * Select the card to the left of the active card
 */

function selectCardLeft() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) - 1;
  selectCardByNumber(nextCardNumber);
}
/**
 * Select the card to the right of the active card
 */

function selectCardRight() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) + 1;
  selectCardByNumber(nextCardNumber);
}
/**
 * Select the card to the up of the active card
 */

function selectCardUp() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) - 5;
  selectCardByNumber(nextCardNumber);
}
/**
 * Select the card to the down of the active card
 */

function selectCardDown() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) + 5;
  selectCardByNumber(nextCardNumber);
}
/**
 * Buy the card that is currently selected
 */

function buySelectedCard() {
  var activeElement = document.querySelector(".selectedCard");
  console.log("Ok I want to buy " + activeElement.id);

  if (activeElement) {
    if (activeElement.classList.contains("active")) {
      console.log("It's active, sure, I'll buy it");
      activeElement.click();
      console.log("Click");
    } else {
      // An den einai available auth
      // An den einai h seira sou -- auto isws to lynoyme me to na tsekaroume seira apo prin
      console.log("Doesn't seem to be available though.");
      var undoButton = document.querySelector("#btn_undo");

      if (undoButton) {
        // An exeis agorasei hdh
        alert("You've already chosen a card."); // an vgaloume to ble otan den einai h seira sou de xreiazetai auto
        // alla prepei na xanaginetai ble otan einai h seira sou
      } else {
        alert("You can't buy this one :( \nChose an available card.");
      }
    }
  } else {
    console.log("Element ".concat(activeElement.id, " not found"));
  }
}

/***/ }),

/***/ "./src/scss/machi_koro.scss":
/*!**********************************!*\
  !*** ./src/scss/machi_koro.scss ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 5:
/*!**********************************************!*\
  !*** multi ./src/scripts/hotkeys/machi_koro ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/pano/code/yucatahotkeys/build/src/scripts/hotkeys/machi_koro */"./src/scripts/hotkeys/machi_koro.js");


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NjcmlwdHMvZG9tLmpzIiwid2VicGFjazovLy8uL3NyYy9zY3JpcHRzL2hvdGtleXMvbWFjaGlfa29yby5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2Nzcy9tYWNoaV9rb3JvLnNjc3MiXSwibmFtZXMiOlsiZ2V0UG9wdXBCdXR0b24iLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiY2xpY2tCeVNlbGVjdG9yIiwic2VsZWN0b3IiLCJlbGVtZW50IiwicXVlcnlTZWxlY3RvciIsImNsaWNrIiwiY29uc29sZSIsImxvZyIsIndhaXRGb3JCb2FyZFRvRXhpc3RBbmRUaGVuIiwibWV0aG9kIiwiYm9hcmQiLCJzZXRUaW1lb3V0IiwiYmluZCIsIm1haW4iLCJzZWxlY3RDYXJkQnlTZWxlY3RvciIsImFkZENhcmRUb29sdGlwcyIsIm1hY2hpS29yb0hvdGtleXNNYXAiLCJrZXlDb21ib3MiLCJkZXNjcmlwdGlvbiIsInNlbGVjdENhcmRMZWZ0Iiwic2VsZWN0Q2FyZFJpZ2h0Iiwic2VsZWN0Q2FyZFVwIiwic2VsZWN0Q2FyZERvd24iLCJidXlTZWxlY3RlZENhcmQiLCJhY3RpdmVFbGVtZW50IiwiZ2V0U2VsZWN0ZWRDYXJkIiwiY2FyZEVsZW1lbnQiLCJjbGFzc0xpc3QiLCJhZGQiLCJyZW1vdmUiLCJjYXJkcyIsImdldENhcmRzRG9tIiwiZm9yRWFjaCIsImNhcmQiLCJjbG9uZSIsImNsb25lTm9kZSIsInBhcmVudEVsZW1lbnQiLCJpbnNlcnRCZWZvcmUiLCJuZXh0U2libGluZyIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJzZWxlY3RDYXJkQnlOdW1iZXIiLCJjYXJkTnVtYmVyIiwibmV4dENhcmRTZWxlY3RvciIsImdldENhcmROdW1iZXIiLCJyZWdleCIsImlkIiwibWF0Y2giLCJwYXJzZUludCIsImVycm9yIiwibmV4dENhcmROdW1iZXIiLCJjb250YWlucyIsInVuZG9CdXR0b24iLCJhbGVydCJdLCJtYXBwaW5ncyI6IjtRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBOzs7UUFHQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMENBQTBDLGdDQUFnQztRQUMxRTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLHdEQUF3RCxrQkFBa0I7UUFDMUU7UUFDQSxpREFBaUQsY0FBYztRQUMvRDs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EseUNBQXlDLGlDQUFpQztRQUMxRSxnSEFBZ0gsbUJBQW1CLEVBQUU7UUFDckk7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwyQkFBMkIsMEJBQTBCLEVBQUU7UUFDdkQsaUNBQWlDLGVBQWU7UUFDaEQ7UUFDQTtRQUNBOztRQUVBO1FBQ0Esc0RBQXNELCtEQUErRDs7UUFFckg7UUFDQTs7O1FBR0E7UUFDQTs7Ozs7Ozs7Ozs7OztBQ2xGQTtBQUFBO0FBQUE7QUFBQTtBQUFBOzs7O0FBSU8sSUFBTUEsY0FBYyxHQUFHLFNBQWpCQSxjQUFpQixHQUFLO0FBQy9CLFNBQU9DLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixhQUF4QixDQUFQO0FBQ0gsQ0FGTTtBQUlQOzs7OztBQUlPLFNBQVNDLGVBQVQsQ0FBeUJDLFFBQXpCLEVBQWtDO0FBQ3JDLE1BQU1DLE9BQU8sR0FBR0osUUFBUSxDQUFDSyxhQUFULENBQXVCRixRQUF2QixDQUFoQjs7QUFDQSxNQUFHQyxPQUFILEVBQVc7QUFDUEEsV0FBTyxDQUFDRSxLQUFSO0FBQ0gsR0FGRCxNQUVPO0FBQ0hDLFdBQU8sQ0FBQ0MsR0FBUixtQkFBdUJMLFFBQXZCO0FBQ0g7QUFDSjtBQUVEOzs7OztBQUlPLFNBQVNNLDBCQUFULENBQW9DQyxNQUFwQyxFQUEyQztBQUM5QyxNQUFNQyxLQUFLLEdBQUdYLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixPQUF4QixDQUFkOztBQUNBLE1BQUdVLEtBQUgsRUFBUztBQUNMSixXQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWjtBQUNBRSxVQUFNO0FBQ1QsR0FIRCxNQUdPO0FBQ0hILFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHdCQUFaO0FBQ0FJLGNBQVUsQ0FBQ0gsMEJBQTBCLENBQUNJLElBQTNCLENBQWdDLElBQWhDLEVBQXNDSCxNQUF0QyxDQUFELEVBQWdELEdBQWhELENBQVY7QUFDSDtBQUNKLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbENEO0FBQ0E7QUFFQTs7OztBQUdPLFNBQVNJLElBQVQsR0FBZTtBQUNsQkwseUVBQTBCLENBQUM7QUFBQSxXQUFLTSxvQkFBb0IsQ0FBQyxRQUFELENBQXpCO0FBQUEsR0FBRCxDQUExQjtBQUNBTix5RUFBMEIsQ0FBQ08sZUFBRCxDQUExQjtBQUNIO0FBRUQ7Ozs7QUFHTyxJQUFNQyxtQkFBbUIsR0FBRztBQUMvQiwyQkFBeUI7QUFDckJDLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FEVTtBQUVyQkMsZUFBVyxFQUFFLGlDQUZRO0FBR3JCVCxVQUFNLEVBQUU7QUFBQSxhQUFNUiw0REFBZSxDQUFDLFFBQUQsQ0FBckI7QUFBQTtBQUhhLEdBRE07QUFNL0IsMkJBQXlCO0FBQ3JCZ0IsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURVO0FBRXJCQyxlQUFXLEVBQUUsaUNBRlE7QUFHckJULFVBQU0sRUFBRTtBQUFBLGFBQU1SLDREQUFlLENBQUMsUUFBRCxDQUFyQjtBQUFBO0FBSGEsR0FOTTtBQVcvQiwyQkFBeUI7QUFDckJnQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlQsVUFBTSxFQUFFO0FBQUEsYUFBTVIsNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQVhNO0FBZ0IvQiwyQkFBeUI7QUFDckJnQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlQsVUFBTSxFQUFFO0FBQUEsYUFBTVIsNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQWhCTTtBQXFCL0IsMkJBQXlCO0FBQ3JCZ0IsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURVO0FBRXJCQyxlQUFXLEVBQUUsaUNBRlE7QUFHckJULFVBQU0sRUFBRTtBQUFBLGFBQU1SLDREQUFlLENBQUMsUUFBRCxDQUFyQjtBQUFBO0FBSGEsR0FyQk07QUEwQi9CLDJCQUF5QjtBQUNyQmdCLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FEVTtBQUVyQkMsZUFBVyxFQUFFLGlDQUZRO0FBR3JCVCxVQUFNLEVBQUU7QUFBQSxhQUFNUiw0REFBZSxDQUFDLFFBQUQsQ0FBckI7QUFBQTtBQUhhLEdBMUJNO0FBK0IvQiwyQkFBeUI7QUFDckJnQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlQsVUFBTSxFQUFFO0FBQUEsYUFBTVIsNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQS9CTTtBQW9DL0IsMkJBQXlCO0FBQ3JCZ0IsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURVO0FBRXJCQyxlQUFXLEVBQUUsaUNBRlE7QUFHckJULFVBQU0sRUFBRTtBQUFBLGFBQU1SLDREQUFlLENBQUMsUUFBRCxDQUFyQjtBQUFBO0FBSGEsR0FwQ007QUF5Qy9CLDJCQUF5QjtBQUNyQmdCLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FEVTtBQUVyQkMsZUFBVyxFQUFFLGlDQUZRO0FBR3JCVCxVQUFNLEVBQUU7QUFBQSxhQUFNUiw0REFBZSxDQUFDLFFBQUQsQ0FBckI7QUFBQTtBQUhhLEdBekNNO0FBOEMvQiw0QkFBMEI7QUFDdEJnQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFc7QUFFdEJDLGVBQVcsRUFBRSxhQUZTO0FBR3RCVCxVQUFNLEVBQUU7QUFBQSxhQUFNUiw0REFBZSxDQUFDLE9BQUQsQ0FBckI7QUFBQTtBQUhjLEdBOUNLO0FBbUQvQiwwQkFBd0I7QUFDcEJnQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFM7QUFFcEJDLGVBQVcsRUFBRSx3QkFGTztBQUdwQlQsVUFBTSxFQUFFO0FBQUEsYUFBTVIsNERBQWUsQ0FBQyxjQUFELENBQXJCO0FBQUE7QUFIWSxHQW5ETztBQXdEL0IsNEJBQTBCO0FBQ3RCZ0IsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURXO0FBRXRCQyxlQUFXLEVBQUUsMEJBRlM7QUFHdEJULFVBQU0sRUFBRTtBQUFBLGFBQU1SLDREQUFlLENBQUMsbUJBQUQsQ0FBckI7QUFBQTtBQUhjLEdBeERLO0FBNkQvQixtQ0FBaUM7QUFDN0JnQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRGtCO0FBRTdCQyxlQUFXLEVBQUUsNEJBRmdCO0FBRzdCVCxVQUFNLEVBQUU7QUFBQSxhQUFNUiw0REFBZSxDQUFDLHNCQUFELENBQXJCO0FBQUE7QUFIcUIsR0E3REY7QUFrRS9CLGlDQUErQjtBQUMzQmdCLGFBQVMsRUFBRSxDQUFDLE1BQUQsQ0FEZ0I7QUFFM0JDLGVBQVcsRUFBRSxrQkFGYztBQUczQlQsVUFBTSxFQUFFO0FBQUEsYUFBTVUsY0FBYyxFQUFwQjtBQUFBO0FBSG1CLEdBbEVBO0FBdUUvQixrQ0FBZ0M7QUFDNUJGLGFBQVMsRUFBRSxDQUFDLE9BQUQsQ0FEaUI7QUFFNUJDLGVBQVcsRUFBRSxtQkFGZTtBQUc1QlQsVUFBTSxFQUFFO0FBQUEsYUFBTVcsZUFBZSxFQUFyQjtBQUFBO0FBSG9CLEdBdkVEO0FBNEUvQiwrQkFBNkI7QUFDekJILGFBQVMsRUFBRSxDQUFDLElBQUQsQ0FEYztBQUV6QkMsZUFBVyxFQUFFLGlCQUZZO0FBR3pCVCxVQUFNLEVBQUU7QUFBQSxhQUFNWSxZQUFZLEVBQWxCO0FBQUE7QUFIaUIsR0E1RUU7QUFpRi9CLGlDQUErQjtBQUMzQkosYUFBUyxFQUFFLENBQUMsTUFBRCxDQURnQjtBQUUzQkMsZUFBVyxFQUFFLG9CQUZjO0FBRzNCVCxVQUFNLEVBQUU7QUFBQSxhQUFNYSxjQUFjLEVBQXBCO0FBQUE7QUFIbUIsR0FqRkE7QUFzRi9CLGtDQUFnQztBQUM1QkwsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURpQjtBQUU1QkMsZUFBVyxFQUFFLG1CQUZlO0FBRzVCVCxVQUFNLEVBQUU7QUFBQSxhQUFNYyxlQUFlLEVBQXJCO0FBQUE7QUFIb0I7QUF0RkQsQ0FBNUI7QUE2RlA7Ozs7O0FBSU8sU0FBU1Qsb0JBQVQsQ0FBOEJaLFFBQTlCLEVBQXVDO0FBQzFDLE1BQU1zQixhQUFhLEdBQUdDLGVBQWUsRUFBckM7QUFDQSxNQUFNQyxXQUFXLEdBQUczQixRQUFRLENBQUNLLGFBQVQsQ0FBdUJGLFFBQXZCLENBQXBCOztBQUNBLE1BQUd3QixXQUFILEVBQWU7QUFDWEEsZUFBVyxDQUFDQyxTQUFaLENBQXNCQyxHQUF0QixDQUEwQixjQUExQjs7QUFDQSxRQUFHSixhQUFILEVBQWlCO0FBQ2JBLG1CQUFhLENBQUNHLFNBQWQsQ0FBd0JFLE1BQXhCLENBQWdDLGNBQWhDO0FBQ0g7QUFDSjtBQUNKO0FBRUQ7Ozs7QUFHQSxTQUFTZCxlQUFULEdBQTJCO0FBQ3ZCLE1BQU1lLEtBQUssR0FBR0MsV0FBVyxFQUF6QjtBQUNBRCxPQUFLLENBQUNFLE9BQU4sQ0FBYyxVQUFBQyxJQUFJLEVBQUk7QUFDbEIsUUFBTUMsS0FBSyxHQUFHRCxJQUFJLENBQUM3QixhQUFMLENBQW1CLFdBQW5CLEVBQWdDK0IsU0FBaEMsRUFBZDtBQUNBRCxTQUFLLENBQUNQLFNBQU4sQ0FBZ0JDLEdBQWhCLENBQW9CLFlBQXBCO0FBQ0FLLFFBQUksQ0FBQ0csYUFBTCxDQUFtQkMsWUFBbkIsQ0FBZ0NILEtBQWhDLEVBQXVDRCxJQUFJLENBQUNLLFdBQTVDO0FBQ0gsR0FKRDtBQUtIO0FBRUQ7Ozs7OztBQUlBLFNBQVNQLFdBQVQsR0FBdUI7QUFDbkIsNEJBQVdoQyxRQUFRLENBQUN3QyxnQkFBVCxDQUEwQixnQkFBMUIsQ0FBWDtBQUNIO0FBRUQ7Ozs7OztBQUlPLFNBQVNkLGVBQVQsR0FBMEI7QUFDN0IsU0FBTzFCLFFBQVEsQ0FBQ0ssYUFBVCxDQUF3QixlQUF4QixDQUFQO0FBQ0g7QUFFRDs7Ozs7QUFJTyxTQUFTb0Msa0JBQVQsQ0FBNEJDLFVBQTVCLEVBQXVDO0FBQzFDLE1BQU1DLGdCQUFnQixrQkFBV0QsVUFBWCxDQUF0QjtBQUNBM0Isc0JBQW9CLENBQUM0QixnQkFBRCxDQUFwQjtBQUNIO0FBRUQ7Ozs7OztBQUtPLFNBQVNDLGFBQVQsQ0FBdUJ4QyxPQUF2QixFQUErQjtBQUNsQyxNQUFNeUMsS0FBSyxHQUFHLE1BQWQ7O0FBQ0EsTUFBR3pDLE9BQUgsRUFBVztBQUNQLFFBQU1zQyxVQUFVLEdBQUd0QyxPQUFPLENBQUMwQyxFQUFSLENBQVdDLEtBQVgsQ0FBaUJGLEtBQWpCLEVBQXdCLENBQXhCLENBQW5COztBQUNBLFFBQUc7QUFDQyxhQUFPRyxRQUFRLENBQUNOLFVBQUQsQ0FBZjtBQUNILEtBRkQsQ0FFRSxPQUFNTyxLQUFOLEVBQVk7QUFDVjFDLGFBQU8sQ0FBQ0MsR0FBUixXQUFlSixPQUFPLENBQUMwQyxFQUF2QjtBQUNBLGFBQU8sSUFBUDtBQUNIO0FBQ0o7O0FBQ0QsU0FBTyxJQUFQO0FBQ0g7QUFFRDs7OztBQUdPLFNBQVMxQixjQUFULEdBQXlCO0FBQzVCLE1BQU1LLGFBQWEsR0FBR0MsZUFBZSxFQUFyQztBQUNBLE1BQU13QixjQUFjLEdBQUdOLGFBQWEsQ0FBQ25CLGFBQUQsQ0FBYixHQUErQixDQUF0RDtBQUVBZ0Isb0JBQWtCLENBQUNTLGNBQUQsQ0FBbEI7QUFDSDtBQUVEOzs7O0FBR08sU0FBUzdCLGVBQVQsR0FBMEI7QUFDN0IsTUFBTUksYUFBYSxHQUFHQyxlQUFlLEVBQXJDO0FBQ0EsTUFBTXdCLGNBQWMsR0FBR04sYUFBYSxDQUFDbkIsYUFBRCxDQUFiLEdBQStCLENBQXREO0FBRUFnQixvQkFBa0IsQ0FBQ1MsY0FBRCxDQUFsQjtBQUNIO0FBRUQ7Ozs7QUFHTyxTQUFTNUIsWUFBVCxHQUF1QjtBQUMxQixNQUFNRyxhQUFhLEdBQUdDLGVBQWUsRUFBckM7QUFDQSxNQUFNd0IsY0FBYyxHQUFHTixhQUFhLENBQUNuQixhQUFELENBQWIsR0FBK0IsQ0FBdEQ7QUFFQWdCLG9CQUFrQixDQUFDUyxjQUFELENBQWxCO0FBQ0g7QUFFRDs7OztBQUdPLFNBQVMzQixjQUFULEdBQXlCO0FBQzVCLE1BQU1FLGFBQWEsR0FBR0MsZUFBZSxFQUFyQztBQUNBLE1BQU13QixjQUFjLEdBQUdOLGFBQWEsQ0FBQ25CLGFBQUQsQ0FBYixHQUErQixDQUF0RDtBQUVBZ0Isb0JBQWtCLENBQUNTLGNBQUQsQ0FBbEI7QUFDSDtBQUVEOzs7O0FBR08sU0FBUzFCLGVBQVQsR0FBMEI7QUFDN0IsTUFBTUMsYUFBYSxHQUFHekIsUUFBUSxDQUFDSyxhQUFULENBQXdCLGVBQXhCLENBQXRCO0FBQ0FFLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFzQmlCLGFBQWEsQ0FBQ3FCLEVBQWhEOztBQUNBLE1BQUdyQixhQUFILEVBQWlCO0FBQ2IsUUFBSUEsYUFBYSxDQUFDRyxTQUFkLENBQXdCdUIsUUFBeEIsQ0FBaUMsUUFBakMsQ0FBSixFQUNBO0FBQ0k1QyxhQUFPLENBQUNDLEdBQVIsQ0FBWSxnQ0FBWjtBQUNBaUIsbUJBQWEsQ0FBQ25CLEtBQWQ7QUFDQUMsYUFBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUNILEtBTEQsTUFNSTtBQUNBO0FBQ0E7QUFDQUQsYUFBTyxDQUFDQyxHQUFSLENBQVksc0NBQVo7QUFDQSxVQUFNNEMsVUFBVSxHQUFHcEQsUUFBUSxDQUFDSyxhQUFULENBQXVCLFdBQXZCLENBQW5COztBQUNBLFVBQUkrQyxVQUFKLEVBQWU7QUFDWDtBQUNBQyxhQUFLLENBQUMsK0JBQUQsQ0FBTCxDQUZXLENBR1g7QUFDQTtBQUNILE9BTEQsTUFNSTtBQUNBQSxhQUFLLENBQUMsc0RBQUQsQ0FBTDtBQUNIO0FBQ0o7QUFDSixHQXRCRCxNQXNCTztBQUNIOUMsV0FBTyxDQUFDQyxHQUFSLG1CQUF1QmlCLGFBQWEsQ0FBQ3FCLEVBQXJDO0FBQ0g7QUFDSixDOzs7Ozs7Ozs7OztBQ3pQRCx1QyIsImZpbGUiOiJzY3JpcHRzL21hY2hpX2tvcm8uanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIi9cIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IDUpO1xuIiwiLyoqXG4gKiBSZXR1cm4gdGhlIGRvbSBub2RlIG9mIHRoZSBidXR0b24gaW4gdGhlIHBvcHVwXG4gKiBAcmV0dXJucyB7SFRNTEVsZW1lbnR9XG4gKi9cbmV4cG9ydCBjb25zdCBnZXRQb3B1cEJ1dHRvbiA9ICgpID0+e1xuICAgIHJldHVybiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInBvcHVwQnV0dG9uXCIpO1xufTtcblxuLyoqXG4gKiBDbGljayB0aGUgZWxlbWVudCBpbiB0aGUgc2VsZWN0b3IgaWYgaXQgaXMgZm91bmRcbiAqIEBwYXJhbSB7c3RyaW5nfSBzZWxlY3RvclxuICovXG5leHBvcnQgZnVuY3Rpb24gY2xpY2tCeVNlbGVjdG9yKHNlbGVjdG9yKXtcbiAgICBjb25zdCBlbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihzZWxlY3Rvcik7XG4gICAgaWYoZWxlbWVudCl7XG4gICAgICAgIGVsZW1lbnQuY2xpY2soKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZyhgRWxlbWVudCAke3NlbGVjdG9yfSBub3QgZm91bmRgKTtcbiAgICB9XG59XG5cbi8qKlxuICogV2FpdCBmb3IgdGhlIGJvYXJkIERPTSBlbGVtZW50IHRvIGV4aXN0LCBhbmQgdGhlbiBleGVjdXRlIHRoZSBtZXRob2QgcGFzc2VkXG4gKiBAcGFyYW0ge2Z1bmN0aW9ufSBtZXRob2RcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHdhaXRGb3JCb2FyZFRvRXhpc3RBbmRUaGVuKG1ldGhvZCl7XG4gICAgY29uc3QgYm9hcmQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImJvYXJkXCIpO1xuICAgIGlmKGJvYXJkKXtcbiAgICAgICAgY29uc29sZS5sb2coXCJCb2FyZCBpcyByZWFkeS5cIik7XG4gICAgICAgIG1ldGhvZCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiTm8gYm9hcmQgeWV0LCB3YWl0aW5nLlwiKTtcbiAgICAgICAgc2V0VGltZW91dCh3YWl0Rm9yQm9hcmRUb0V4aXN0QW5kVGhlbi5iaW5kKHRoaXMsIG1ldGhvZCksIDUwMCk7XG4gICAgfVxufVxuIiwiaW1wb3J0ICcuLi8uLi9zY3NzL21hY2hpX2tvcm8uc2Nzcyc7XG5pbXBvcnQge2NsaWNrQnlTZWxlY3Rvciwgd2FpdEZvckJvYXJkVG9FeGlzdEFuZFRoZW59IGZyb20gXCIuLi9kb21cIjtcblxuLyoqXG4gKiBNYWluIG1ldGhvZCB0byBiZSBleGVjdXRlZCAoYnkgY29udGVudC5qcylcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKXtcbiAgICB3YWl0Rm9yQm9hcmRUb0V4aXN0QW5kVGhlbigoKT0+IHNlbGVjdENhcmRCeVNlbGVjdG9yKFwiI2NhcmQxXCIpKTtcbiAgICB3YWl0Rm9yQm9hcmRUb0V4aXN0QW5kVGhlbihhZGRDYXJkVG9vbHRpcHMpO1xufVxuXG4vKipcbiAqIEhvdGtleSBtYXAgZm9yIG1hY2hpIGtvcm8gb25seVxuICovXG5leHBvcnQgY29uc3QgbWFjaGlLb3JvSG90a2V5c01hcCA9IHtcbiAgICBcIm1hY2hpX2tvcm9fYnV5X3Nsb3RfMVwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiMVwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQnV5IENhcmQgaW4gU2xvdCAxIChNYWNoaSBLb3JvKVwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNjYXJkMVwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX2J1eV9zbG90XzJcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIjJcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkJ1eSBDYXJkIGluIFNsb3QgMiAoTWFjaGkgS29ybylcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjY2FyZDJcIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19idXlfc2xvdF8zXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCIzXCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJCdXkgQ2FyZCBpbiBTbG90IDMgKE1hY2hpIEtvcm8pXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2NhcmQzXCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fYnV5X3Nsb3RfNFwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiNFwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQnV5IENhcmQgaW4gU2xvdCA0IChNYWNoaSBLb3JvKVwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNjYXJkNFwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX2J1eV9zbG90XzVcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIjVcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkJ1eSBDYXJkIGluIFNsb3QgNSAoTWFjaGkgS29ybylcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjY2FyZDVcIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19idXlfc2xvdF82XCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCI2XCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJCdXkgQ2FyZCBpbiBTbG90IDYgKE1hY2hpIEtvcm8pXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2NhcmQ2XCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fYnV5X3Nsb3RfN1wiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiN1wiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQnV5IENhcmQgaW4gU2xvdCA3IChNYWNoaSBLb3JvKVwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNjYXJkN1wiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX2J1eV9zbG90XzhcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIjhcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkJ1eSBDYXJkIGluIFNsb3QgOCAoTWFjaGkgS29ybylcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjY2FyZDhcIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19idXlfc2xvdF85XCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCI5XCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJCdXkgQ2FyZCBpbiBTbG90IDkgKE1hY2hpIEtvcm8pXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2NhcmQ5XCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fdG9nZ2xlX2RpY2VcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcImRcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlRvZ2dsZSBEaWNlXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2RpZTJcIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19yb2xsX2RpY2VcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcInJcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkhpdCAnUm9sbCBkaWNlJyBidXR0b25cIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjYnRuX1fDvHJmZWxuXCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fcmVyb2xsX2RpY2VcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcInFcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkhpdCAnUmVyb2xsIGRpY2UnIGJ1dHRvblwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNidG5fQnRuUm9sbEFnYWluXCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fZG9fbm90X3Jlcm9sbF9kaWNlXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCJ3XCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJIaXQgJ0RvIE5vdCBSZXJvbGwnIGJ1dHRvblwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNidG5fQnRuUm9sbE5vdEFnYWluXCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fc2VsZWN0X2NhcmRfbGVmdFwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wibGVmdFwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiU2VsZWN0IExlZnQgQ2FyZFwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IHNlbGVjdENhcmRMZWZ0KClcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19zZWxlY3RfY2FyZF9yaWdodFwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wicmlnaHRcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlNlbGVjdCBSaWdodCBDYXJkXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gc2VsZWN0Q2FyZFJpZ2h0KClcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19zZWxlY3RfY2FyZF91cFwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1widXBcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlNlbGVjdCBUb3AgQ2FyZFwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IHNlbGVjdENhcmRVcCgpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fc2VsZWN0X2NhcmRfZG93blwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiZG93blwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiU2VsZWN0IEJvdHRvbSBDYXJkXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gc2VsZWN0Q2FyZERvd24oKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX2J1eV9zZWxlY3RlZF9jYXJkXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCJiXCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJCdXkgU2VsZWN0ZWQgQ2FyZFwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGJ1eVNlbGVjdGVkQ2FyZCgpXG4gICAgfVxufTtcblxuLyoqXG4gKiBBZGQgdGhlIFwic2VsZWN0ZWRDYXJkXCIgY2xhc3MgdG8gdGhlIGVsZW1lbnQgbWF0Y2hlZCBieSB0aGUgc2VsZWN0b3IgKGlmIGFueSlcbiAqIEBwYXJhbSB7c3RyaW5nfSBzZWxlY3RvclxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0Q2FyZEJ5U2VsZWN0b3Ioc2VsZWN0b3Ipe1xuICAgIGNvbnN0IGFjdGl2ZUVsZW1lbnQgPSBnZXRTZWxlY3RlZENhcmQoKTtcbiAgICBjb25zdCBjYXJkRWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3Ioc2VsZWN0b3IpO1xuICAgIGlmKGNhcmRFbGVtZW50KXtcbiAgICAgICAgY2FyZEVsZW1lbnQuY2xhc3NMaXN0LmFkZChcInNlbGVjdGVkQ2FyZFwiKTtcbiAgICAgICAgaWYoYWN0aXZlRWxlbWVudCl7XG4gICAgICAgICAgICBhY3RpdmVFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoIFwic2VsZWN0ZWRDYXJkXCIgKTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLyoqXG4gKiBBZGRzIGNhcmQgdG9vbHRpcHMgb24gaG92ZXIgKHpvb21lZCBpbiBjYXJkcylcbiAqL1xuZnVuY3Rpb24gYWRkQ2FyZFRvb2x0aXBzKCkge1xuICAgIGNvbnN0IGNhcmRzID0gZ2V0Q2FyZHNEb20oKTtcbiAgICBjYXJkcy5mb3JFYWNoKGNhcmQgPT4ge1xuICAgICAgICBjb25zdCBjbG9uZSA9IGNhcmQucXVlcnlTZWxlY3RvcihcIi5jYXJkIGltZ1wiKS5jbG9uZU5vZGUoKTtcbiAgICAgICAgY2xvbmUuY2xhc3NMaXN0LmFkZChcImNhcmRab29tZWRcIik7XG4gICAgICAgIGNhcmQucGFyZW50RWxlbWVudC5pbnNlcnRCZWZvcmUoY2xvbmUsIGNhcmQubmV4dFNpYmxpbmcpO1xuICAgIH0pXG59XG5cbi8qKlxuICpcbiAqIEByZXR1cm5zIHtOb2RlTGlzdE9mPEVsZW1lbnQ+fVxuICovXG5mdW5jdGlvbiBnZXRDYXJkc0RvbSgpIHtcbiAgICByZXR1cm4gWy4uLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIuY2FyZENvbnRhaW5lclwiKV07XG59XG5cbi8qKlxuICogUmV0dXJuIHRoZSBjYXJkIHRoYXQgaXMgY3VycmVudGx5IHNlbGVjdGVkIChoYXMgdGhlIGNsYXNzIHNlbGVjdGVkQ2FyZClcbiAqIEByZXR1cm5zIHtFbGVtZW50fVxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0U2VsZWN0ZWRDYXJkKCl7XG4gICAgcmV0dXJuIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoIFwiLnNlbGVjdGVkQ2FyZFwiKTtcbn1cblxuLyoqXG4gKiBTZWxlY3QgYSBjYXJkIGJhc2VkIG9uIHRoZSBudW1iZXIgcHJvdmlkZWRcbiAqIEBwYXJhbSB7bnVtYmVyfSBjYXJkTnVtYmVyXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZWxlY3RDYXJkQnlOdW1iZXIoY2FyZE51bWJlcil7XG4gICAgY29uc3QgbmV4dENhcmRTZWxlY3RvciA9IGAjY2FyZCR7Y2FyZE51bWJlcn1gO1xuICAgIHNlbGVjdENhcmRCeVNlbGVjdG9yKG5leHRDYXJkU2VsZWN0b3IpO1xufVxuXG4vKipcbiAqIFJldHVybiB0aGUgY2FyZCBudW1iZXIgZm9yIHRoZSBwcm92aWRlZCBlbGVtZW50XG4gKiBAcGFyYW0ge0VsZW1lbnR9IGVsZW1lbnRcbiAqIEByZXR1cm5zIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRDYXJkTnVtYmVyKGVsZW1lbnQpe1xuICAgIGNvbnN0IHJlZ2V4ID0gL1xcZCskLztcbiAgICBpZihlbGVtZW50KXtcbiAgICAgICAgY29uc3QgY2FyZE51bWJlciA9IGVsZW1lbnQuaWQubWF0Y2gocmVnZXgpWzBdO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICByZXR1cm4gcGFyc2VJbnQoY2FyZE51bWJlcik7XG4gICAgICAgIH0gY2F0Y2goZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coYCR7ZWxlbWVudC5pZH0gZGlkIG5vdCBoYXZlIGEgbnVtYmVyIGF0IHRoZSBlbmQgb2YgaXRzIElEYCk7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbn1cblxuLyoqXG4gKiBTZWxlY3QgdGhlIGNhcmQgdG8gdGhlIGxlZnQgb2YgdGhlIGFjdGl2ZSBjYXJkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZWxlY3RDYXJkTGVmdCgpe1xuICAgIGNvbnN0IGFjdGl2ZUVsZW1lbnQgPSBnZXRTZWxlY3RlZENhcmQoKTtcbiAgICBjb25zdCBuZXh0Q2FyZE51bWJlciA9IGdldENhcmROdW1iZXIoYWN0aXZlRWxlbWVudCkgLSAxO1xuXG4gICAgc2VsZWN0Q2FyZEJ5TnVtYmVyKG5leHRDYXJkTnVtYmVyKTtcbn1cblxuLyoqXG4gKiBTZWxlY3QgdGhlIGNhcmQgdG8gdGhlIHJpZ2h0IG9mIHRoZSBhY3RpdmUgY2FyZFxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0Q2FyZFJpZ2h0KCl7XG4gICAgY29uc3QgYWN0aXZlRWxlbWVudCA9IGdldFNlbGVjdGVkQ2FyZCgpO1xuICAgIGNvbnN0IG5leHRDYXJkTnVtYmVyID0gZ2V0Q2FyZE51bWJlcihhY3RpdmVFbGVtZW50KSArIDE7XG5cbiAgICBzZWxlY3RDYXJkQnlOdW1iZXIobmV4dENhcmROdW1iZXIpO1xufVxuXG4vKipcbiAqIFNlbGVjdCB0aGUgY2FyZCB0byB0aGUgdXAgb2YgdGhlIGFjdGl2ZSBjYXJkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZWxlY3RDYXJkVXAoKXtcbiAgICBjb25zdCBhY3RpdmVFbGVtZW50ID0gZ2V0U2VsZWN0ZWRDYXJkKCk7XG4gICAgY29uc3QgbmV4dENhcmROdW1iZXIgPSBnZXRDYXJkTnVtYmVyKGFjdGl2ZUVsZW1lbnQpIC0gNTtcblxuICAgIHNlbGVjdENhcmRCeU51bWJlcihuZXh0Q2FyZE51bWJlcik7XG59XG5cbi8qKlxuICogU2VsZWN0IHRoZSBjYXJkIHRvIHRoZSBkb3duIG9mIHRoZSBhY3RpdmUgY2FyZFxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0Q2FyZERvd24oKXtcbiAgICBjb25zdCBhY3RpdmVFbGVtZW50ID0gZ2V0U2VsZWN0ZWRDYXJkKCk7XG4gICAgY29uc3QgbmV4dENhcmROdW1iZXIgPSBnZXRDYXJkTnVtYmVyKGFjdGl2ZUVsZW1lbnQpICsgNTtcblxuICAgIHNlbGVjdENhcmRCeU51bWJlcihuZXh0Q2FyZE51bWJlcik7XG59XG5cbi8qKlxuICogQnV5IHRoZSBjYXJkIHRoYXQgaXMgY3VycmVudGx5IHNlbGVjdGVkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBidXlTZWxlY3RlZENhcmQoKXtcbiAgICBjb25zdCBhY3RpdmVFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggXCIuc2VsZWN0ZWRDYXJkXCIpO1xuICAgIGNvbnNvbGUubG9nKFwiT2sgSSB3YW50IHRvIGJ1eSBcIiArIGFjdGl2ZUVsZW1lbnQuaWQpO1xuICAgIGlmKGFjdGl2ZUVsZW1lbnQpe1xuICAgICAgICBpZiAoYWN0aXZlRWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoXCJhY3RpdmVcIikpXG4gICAgICAgIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiSXQncyBhY3RpdmUsIHN1cmUsIEknbGwgYnV5IGl0XCIpO1xuICAgICAgICAgICAgYWN0aXZlRWxlbWVudC5jbGljaygpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDbGlja1wiKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgLy8gQW4gZGVuIGVpbmFpIGF2YWlsYWJsZSBhdXRoXG4gICAgICAgICAgICAvLyBBbiBkZW4gZWluYWkgaCBzZWlyYSBzb3UgLS0gYXV0byBpc3dzIHRvIGx5bm95bWUgbWUgdG8gbmEgdHNla2Fyb3VtZSBzZWlyYSBhcG8gcHJpblxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJEb2Vzbid0IHNlZW0gdG8gYmUgYXZhaWxhYmxlIHRob3VnaC5cIik7XG4gICAgICAgICAgICBjb25zdCB1bmRvQnV0dG9uID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNidG5fdW5kb1wiKTtcbiAgICAgICAgICAgIGlmICh1bmRvQnV0dG9uKXtcbiAgICAgICAgICAgICAgICAvLyBBbiBleGVpcyBhZ29yYXNlaSBoZGhcbiAgICAgICAgICAgICAgICBhbGVydChcIllvdSd2ZSBhbHJlYWR5IGNob3NlbiBhIGNhcmQuXCIpO1xuICAgICAgICAgICAgICAgIC8vIGFuIHZnYWxvdW1lIHRvIGJsZSBvdGFuIGRlbiBlaW5haSBoIHNlaXJhIHNvdSBkZSB4cmVpYXpldGFpIGF1dG9cbiAgICAgICAgICAgICAgICAvLyBhbGxhIHByZXBlaSBuYSB4YW5hZ2luZXRhaSBibGUgb3RhbiBlaW5haSBoIHNlaXJhIHNvdVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICBhbGVydChcIllvdSBjYW4ndCBidXkgdGhpcyBvbmUgOiggXFxuQ2hvc2UgYW4gYXZhaWxhYmxlIGNhcmQuXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coYEVsZW1lbnQgJHthY3RpdmVFbGVtZW50LmlkfSBub3QgZm91bmRgKTtcbiAgICB9XG59IiwiLy8gZXh0cmFjdGVkIGJ5IG1pbmktY3NzLWV4dHJhY3QtcGx1Z2luIl0sInNvdXJjZVJvb3QiOiIifQ==