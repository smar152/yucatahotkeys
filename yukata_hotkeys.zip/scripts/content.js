/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/scripts/content.js":
/*!********************************!*\
  !*** ./src/scripts/content.js ***!
  \********************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _hotkeys_machi_koro__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./hotkeys/machi_koro */ "./src/scripts/hotkeys/machi_koro.js");
/* harmony import */ var _hotkeys_global__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./hotkeys/global */ "./src/scripts/hotkeys/global.js");
/* harmony import */ var _dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dom */ "./src/scripts/dom.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/**
 * This is the content script that will run in all yucata.de pages
 * Keys of the map are the buttons pressed
 * Values of the map are objects describing the action containing a description and a method
 */



/**
 * All of the hotkeys combined
 */

var hotkeysMap = _objectSpread({}, _hotkeys_machi_koro__WEBPACK_IMPORTED_MODULE_0__["machiKoroHotkeysMap"], {}, _hotkeys_global__WEBPACK_IMPORTED_MODULE_1__["globalHotkeysMap"]);

setupHotkeys();
Object(_dom__WEBPACK_IMPORTED_MODULE_2__["waitForBoardToExistAndThen"])(addTooltip);
Object(_hotkeys_machi_koro__WEBPACK_IMPORTED_MODULE_0__["main"])();
/**
 * Add a tooltip to the UI containing the shortcuts
 */

function addTooltip() {
  var board = document.getElementById("board");
  var tooltipTriggerElement = Object.assign(document.createElement("div"), {
    className: "hotkeyTooltipTrigger ui-btn ui-input-btn ui-btn-a ui-corner-all ui-shadow ui-btn-inline ui-mini ui-first-child",
    textContent: "List of Hotkeys"
  });
  var tooltipText = Object.assign(document.createElement("div"), {
    className: "tooltipText"
  });
  Object.keys(hotkeysMap).forEach(function (key) {
    var _hotkeysMap$key = hotkeysMap[key],
        keyCombos = _hotkeysMap$key.keyCombos,
        description = _hotkeysMap$key.description;
    var row = Object.assign(document.createElement("div"), {
      className: "tooltipTextRow"
    });
    var labelCell = Object.assign(document.createElement("div"), {
      className: "tooltipTextlabel",
      textContent: keyCombos[0].toLocaleUpperCase() + ":"
    });
    var valueCell = Object.assign(document.createElement("div"), {
      className: "tooltipTextValue",
      textContent: description
    });
    row.appendChild(labelCell);
    row.appendChild(valueCell);
    tooltipText.appendChild(row);
  });
  tooltipTriggerElement.appendChild(tooltipText);
  board.appendChild(tooltipTriggerElement);
  board.appendChild(tooltipText);
}
/**
 * Set up the keypress handlers for all the hotkeys
 */


function setupHotkeys() {
  console.log("Custom Yucata hotkeys added."); // For each key defined in the map (unique action name)

  Object.keys(hotkeysMap).forEach(function (actionId) {
    // Get the data object
    var data = hotkeysMap[actionId];

    if (data) {
      var keyCombos = data.keyCombos,
          method = data.method,
          description = data.description;
      keyCombos.forEach(function (key) {
        // Attach an keypress event listener to the window object
        window.addEventListener("keydown", function (e) {
          // If the key in the event matches the key we are setting up the handler for
          if (e.key === key) {
            // If we have a binding for this hotkey
            console.log("Action: ".concat(description));
            method();
          }
        });
      });
    }
  });
}

/***/ }),

/***/ "./src/scripts/dom.js":
/*!****************************!*\
  !*** ./src/scripts/dom.js ***!
  \****************************/
/*! exports provided: getPopupButton, clickBySelector, waitForBoardToExistAndThen */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPopupButton", function() { return getPopupButton; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clickBySelector", function() { return clickBySelector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "waitForBoardToExistAndThen", function() { return waitForBoardToExistAndThen; });
/**
 * Return the dom node of the button in the popup
 * @returns {HTMLElement}
 */
var getPopupButton = function getPopupButton() {
  return document.getElementById("popupButton");
};
/**
 * Click the element in the selector if it is found
 * @param {string} selector
 */

function clickBySelector(selector) {
  var element = document.querySelector(selector);

  if (element) {
    element.click();
  } else {
    console.log("Element ".concat(selector, " not found"));
  }
}
/**
 * Wait for the board DOM element to exist, and then execute the method passed
 * @param {function} method
 */

function waitForBoardToExistAndThen(method) {
  var board = document.getElementById("board");

  if (board) {
    console.log("Board is ready.");
    method();
  } else {
    console.log("No board yet, waiting.");
    setTimeout(waitForBoardToExistAndThen.bind(this, method), 500);
  }
}

/***/ }),

/***/ "./src/scripts/hotkeys/global.js":
/*!***************************************!*\
  !*** ./src/scripts/hotkeys/global.js ***!
  \***************************************/
/*! exports provided: globalHotkeysMap */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "globalHotkeysMap", function() { return globalHotkeysMap; });
/* harmony import */ var _dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../dom */ "./src/scripts/dom.js");

/**
 * Hotkey map for all games
 */

var globalHotkeysMap = {
  "global_ok": {
    keyCombos: ["g"],
    description: "Hit 'OK' when it's your turn",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_0__["clickBySelector"])(".ui-popup-active input[value='OK']");
    }
  },
  "global_undo": {
    keyCombos: ["u"],
    description: "Hit 'Undo' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_0__["clickBySelector"])("#btn_undo");
    }
  },
  "global_pass": {
    keyCombos: ["p"],
    description: "Hit the 'Pass' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_0__["clickBySelector"])("#btn_BtnPassBuy");
    }
  },
  "global_finish": {
    keyCombos: ["f"],
    description: "Hit the 'Finish Turn' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_0__["clickBySelector"])("#btn_finishTurn");
    }
  },
  "global_next_game": {
    keyCombos: ["n"],
    description: "Hit the 'Next Game' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_0__["clickBySelector"])("#btn_nextGame");
    }
  }
};

/***/ }),

/***/ "./src/scripts/hotkeys/machi_koro.js":
/*!*******************************************!*\
  !*** ./src/scripts/hotkeys/machi_koro.js ***!
  \*******************************************/
/*! exports provided: main, machiKoroHotkeysMap, selectCardBySelector, getSelectedCard, selectCardByNumber, getCardNumber, selectCardLeft, selectCardRight, selectCardUp, selectCardDown, buySelectedCard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "main", function() { return main; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "machiKoroHotkeysMap", function() { return machiKoroHotkeysMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardBySelector", function() { return selectCardBySelector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSelectedCard", function() { return getSelectedCard; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardByNumber", function() { return selectCardByNumber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCardNumber", function() { return getCardNumber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardLeft", function() { return selectCardLeft; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardRight", function() { return selectCardRight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardUp", function() { return selectCardUp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardDown", function() { return selectCardDown; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "buySelectedCard", function() { return buySelectedCard; });
/* harmony import */ var _scss_machi_koro_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../scss/machi_koro.scss */ "./src/scss/machi_koro.scss");
/* harmony import */ var _scss_machi_koro_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_scss_machi_koro_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../dom */ "./src/scripts/dom.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }



/**
 * Main method to be executed (by content.js)
 */

function main() {
  Object(_dom__WEBPACK_IMPORTED_MODULE_1__["waitForBoardToExistAndThen"])(function () {
    return selectCardBySelector("#card1");
  });
  Object(_dom__WEBPACK_IMPORTED_MODULE_1__["waitForBoardToExistAndThen"])(addCardTooltips);
}
/**
 * Hotkey map for machi koro only
 */

var machiKoroHotkeysMap = {
  "machi_koro_buy_slot_1": {
    keyCombos: ["1"],
    description: "Buy Card in Slot 1 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card1");
    }
  },
  "machi_koro_buy_slot_2": {
    keyCombos: ["2"],
    description: "Buy Card in Slot 2 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card2");
    }
  },
  "machi_koro_buy_slot_3": {
    keyCombos: ["3"],
    description: "Buy Card in Slot 3 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card3");
    }
  },
  "machi_koro_buy_slot_4": {
    keyCombos: ["4"],
    description: "Buy Card in Slot 4 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card4");
    }
  },
  "machi_koro_buy_slot_5": {
    keyCombos: ["5"],
    description: "Buy Card in Slot 5 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card5");
    }
  },
  "machi_koro_buy_slot_6": {
    keyCombos: ["6"],
    description: "Buy Card in Slot 6 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card6");
    }
  },
  "machi_koro_buy_slot_7": {
    keyCombos: ["7"],
    description: "Buy Card in Slot 7 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card7");
    }
  },
  "machi_koro_buy_slot_8": {
    keyCombos: ["8"],
    description: "Buy Card in Slot 8 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card8");
    }
  },
  "machi_koro_buy_slot_9": {
    keyCombos: ["9"],
    description: "Buy Card in Slot 9 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card9");
    }
  },
  "machi_koro_toggle_dice": {
    keyCombos: ["d"],
    description: "Toggle Dice",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#die2");
    }
  },
  "machi_koro_roll_dice": {
    keyCombos: ["r"],
    description: "Hit 'Roll dice' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#btn_Würfeln");
    }
  },
  "machi_koro_reroll_dice": {
    keyCombos: ["q"],
    description: "Hit 'Reroll dice' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#btn_BtnRollAgain");
    }
  },
  "machi_koro_do_not_reroll_dice": {
    keyCombos: ["w"],
    description: "Hit 'Do Not Reroll' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#btn_BtnRollNotAgain");
    }
  },
  "machi_koro_select_card_left": {
    keyCombos: ["ArrowLeft"],
    description: "Select Left Card",
    method: function method() {
      return selectCardLeft();
    }
  },
  "machi_koro_select_card_right": {
    keyCombos: ["ArrowRight"],
    description: "Select Right Card",
    method: function method() {
      return selectCardRight();
    }
  },
  "machi_koro_select_card_up": {
    keyCombos: ["ArrowUp"],
    description: "Select Top Card",
    method: function method() {
      return selectCardUp();
    }
  },
  "machi_koro_select_card_down": {
    keyCombos: ["ArrowDown"],
    description: "Select Bottom Card",
    method: function method() {
      return selectCardDown();
    }
  },
  "machi_koro_buy_selected_card": {
    keyCombos: ["b"],
    description: "Buy Selected Card",
    method: function method() {
      return buySelectedCard();
    }
  }
};
/**
 * Add the "selectedCard" class to the element matched by the selector (if any)
 * @param {string} selector
 */

function selectCardBySelector(selector) {
  var activeElement = getSelectedCard();
  var cardElement = document.querySelector(selector);

  if (cardElement) {
    cardElement.classList.add("selectedCard");

    if (activeElement) {
      activeElement.classList.remove("selectedCard");
    }
  }
}
/**
 * Adds card tooltips on hover (zoomed in cards)
 */

function addCardTooltips() {
  var cards = getCardsDom();
  cards.forEach(function (card) {
    var clone = card.querySelector(".card img").cloneNode();
    clone.classList.add("cardZoomed");
    card.parentElement.insertBefore(clone, card.nextSibling);
  });
}
/**
 *
 * @returns {NodeListOf<Element>}
 */


function getCardsDom() {
  return _toConsumableArray(document.querySelectorAll(".cardContainer"));
}
/**
 * Return the card that is currently selected (has the class selectedCard)
 * @returns {Element}
 */


function getSelectedCard() {
  return document.querySelector(".selectedCard");
}
/**
 * Select a card based on the number provided
 * @param {number} cardNumber
 */

function selectCardByNumber(cardNumber) {
  var nextCardSelector = "#card".concat(cardNumber);
  selectCardBySelector(nextCardSelector);
}
/**
 * Return the card number for the provided element
 * @param {Element} element
 * @returns {number}
 */

function getCardNumber(element) {
  var regex = /\d+$/;

  if (element) {
    var cardNumber = element.id.match(regex)[0];

    try {
      return parseInt(cardNumber);
    } catch (error) {
      console.log("".concat(element.id, " did not have a number at the end of its ID"));
      return null;
    }
  }

  return null;
}
/**
 * Select the card to the left of the active card
 */

function selectCardLeft() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) - 1;
  selectCardByNumber(nextCardNumber);
}
/**
 * Select the card to the right of the active card
 */

function selectCardRight() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) + 1;
  selectCardByNumber(nextCardNumber);
}
/**
 * Select the card to the up of the active card
 */

function selectCardUp() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) - 5;
  selectCardByNumber(nextCardNumber);
}
/**
 * Select the card to the down of the active card
 */

function selectCardDown() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) + 5;
  selectCardByNumber(nextCardNumber);
}
/**
 * Buy the card that is currently selected
 */

function buySelectedCard() {
  var activeElement = document.querySelector(".selectedCard");
  console.log("Ok I want to buy " + activeElement.id);

  if (activeElement) {
    if (activeElement.classList.contains("active")) {
      console.log("It's active, sure, I'll buy it");
      activeElement.click();
      console.log("Click");
    } else {
      // auto bvgainei an
      // 1. den einai available auth
      // 2. exeis agorasei hdh  ** αν υπαρχει κουμπί αντού "#btn_undo"
      // 3. den einai h seira sou -- auto isws to lynoyme me to na tsekaroume seira apo prin
      console.log("Doesn't seem to be available though.");
      var undoButton = document.querySelector("#btn_undo");

      if (undoButton) {
        alert("You've already chosen a card."); // an vgaloume to ble otan den einai h seira sou de xreiazetai auto
        // alla prepei na xanaginetai ble otan einai h seira sou
      } else {
        alert("You can't buy this one :( \nChose an available card.");
      }
    }
  } else {
    console.log("Element ".concat(activeElement.id, " not found"));
  }
}

/***/ }),

/***/ "./src/scss/machi_koro.scss":
/*!**********************************!*\
  !*** ./src/scss/machi_koro.scss ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 1:
/*!***********************************!*\
  !*** multi ./src/scripts/content ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/pano/code/yucatahotkeys/build/src/scripts/content */"./src/scripts/content.js");


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NjcmlwdHMvY29udGVudC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2NyaXB0cy9kb20uanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NjcmlwdHMvaG90a2V5cy9nbG9iYWwuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NjcmlwdHMvaG90a2V5cy9tYWNoaV9rb3JvLmpzIiwid2VicGFjazovLy8uL3NyYy9zY3NzL21hY2hpX2tvcm8uc2NzcyJdLCJuYW1lcyI6WyJob3RrZXlzTWFwIiwibWFjaGlLb3JvSG90a2V5c01hcCIsImdsb2JhbEhvdGtleXNNYXAiLCJzZXR1cEhvdGtleXMiLCJ3YWl0Rm9yQm9hcmRUb0V4aXN0QW5kVGhlbiIsImFkZFRvb2x0aXAiLCJtYWNoaV9rb3JvX21haW4iLCJib2FyZCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJ0b29sdGlwVHJpZ2dlckVsZW1lbnQiLCJPYmplY3QiLCJhc3NpZ24iLCJjcmVhdGVFbGVtZW50IiwiY2xhc3NOYW1lIiwidGV4dENvbnRlbnQiLCJ0b29sdGlwVGV4dCIsImtleXMiLCJmb3JFYWNoIiwia2V5Iiwia2V5Q29tYm9zIiwiZGVzY3JpcHRpb24iLCJyb3ciLCJsYWJlbENlbGwiLCJ0b0xvY2FsZVVwcGVyQ2FzZSIsInZhbHVlQ2VsbCIsImFwcGVuZENoaWxkIiwiY29uc29sZSIsImxvZyIsImFjdGlvbklkIiwiZGF0YSIsIm1ldGhvZCIsIndpbmRvdyIsImFkZEV2ZW50TGlzdGVuZXIiLCJlIiwiZ2V0UG9wdXBCdXR0b24iLCJjbGlja0J5U2VsZWN0b3IiLCJzZWxlY3RvciIsImVsZW1lbnQiLCJxdWVyeVNlbGVjdG9yIiwiY2xpY2siLCJzZXRUaW1lb3V0IiwiYmluZCIsIm1haW4iLCJzZWxlY3RDYXJkQnlTZWxlY3RvciIsImFkZENhcmRUb29sdGlwcyIsInNlbGVjdENhcmRMZWZ0Iiwic2VsZWN0Q2FyZFJpZ2h0Iiwic2VsZWN0Q2FyZFVwIiwic2VsZWN0Q2FyZERvd24iLCJidXlTZWxlY3RlZENhcmQiLCJhY3RpdmVFbGVtZW50IiwiZ2V0U2VsZWN0ZWRDYXJkIiwiY2FyZEVsZW1lbnQiLCJjbGFzc0xpc3QiLCJhZGQiLCJyZW1vdmUiLCJjYXJkcyIsImdldENhcmRzRG9tIiwiY2FyZCIsImNsb25lIiwiY2xvbmVOb2RlIiwicGFyZW50RWxlbWVudCIsImluc2VydEJlZm9yZSIsIm5leHRTaWJsaW5nIiwicXVlcnlTZWxlY3RvckFsbCIsInNlbGVjdENhcmRCeU51bWJlciIsImNhcmROdW1iZXIiLCJuZXh0Q2FyZFNlbGVjdG9yIiwiZ2V0Q2FyZE51bWJlciIsInJlZ2V4IiwiaWQiLCJtYXRjaCIsInBhcnNlSW50IiwiZXJyb3IiLCJuZXh0Q2FyZE51bWJlciIsImNvbnRhaW5zIiwidW5kb0J1dHRvbiIsImFsZXJ0Il0sIm1hcHBpbmdzIjoiO1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xGQTs7Ozs7QUFLQTtBQUNBO0FBQ0E7QUFHQTs7OztBQUdBLElBQU1BLFVBQVUscUJBQ1hDLHVFQURXLE1BRVhDLGdFQUZXLENBQWhCOztBQUtBQyxZQUFZO0FBQ1pDLHVFQUEwQixDQUFDQyxVQUFELENBQTFCO0FBQ0FDLGdFQUFlO0FBR2Y7Ozs7QUFHQSxTQUFTRCxVQUFULEdBQXFCO0FBQ2pCLE1BQU1FLEtBQUssR0FBR0MsUUFBUSxDQUFDQyxjQUFULENBQXdCLE9BQXhCLENBQWQ7QUFDQSxNQUFNQyxxQkFBcUIsR0FBR0MsTUFBTSxDQUFDQyxNQUFQLENBQWNKLFFBQVEsQ0FBQ0ssYUFBVCxDQUF1QixLQUF2QixDQUFkLEVBQTZDO0FBQ3ZFQyxhQUFTLEVBQUUsZ0hBRDREO0FBRXZFQyxlQUFXLEVBQUU7QUFGMEQsR0FBN0MsQ0FBOUI7QUFJQSxNQUFNQyxXQUFXLEdBQUdMLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjSixRQUFRLENBQUNLLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBZCxFQUE2QztBQUM3REMsYUFBUyxFQUFFO0FBRGtELEdBQTdDLENBQXBCO0FBSUFILFFBQU0sQ0FBQ00sSUFBUCxDQUFZakIsVUFBWixFQUF3QmtCLE9BQXhCLENBQWdDLFVBQUFDLEdBQUcsRUFBSTtBQUFBLDBCQUNIbkIsVUFBVSxDQUFDbUIsR0FBRCxDQURQO0FBQUEsUUFDN0JDLFNBRDZCLG1CQUM3QkEsU0FENkI7QUFBQSxRQUNsQkMsV0FEa0IsbUJBQ2xCQSxXQURrQjtBQUVwQyxRQUFNQyxHQUFHLEdBQUdYLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjSixRQUFRLENBQUNLLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBZCxFQUE2QztBQUNyREMsZUFBUyxFQUFFO0FBRDBDLEtBQTdDLENBQVo7QUFHQSxRQUFNUyxTQUFTLEdBQUdaLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjSixRQUFRLENBQUNLLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBZCxFQUE2QztBQUMzREMsZUFBUyxFQUFFLGtCQURnRDtBQUUzREMsaUJBQVcsRUFBRUssU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhSSxpQkFBYixLQUFtQztBQUZXLEtBQTdDLENBQWxCO0FBSUEsUUFBTUMsU0FBUyxHQUFHZCxNQUFNLENBQUNDLE1BQVAsQ0FBY0osUUFBUSxDQUFDSyxhQUFULENBQXVCLEtBQXZCLENBQWQsRUFBNkM7QUFDM0RDLGVBQVMsRUFBRSxrQkFEZ0Q7QUFFM0RDLGlCQUFXLEVBQUVNO0FBRjhDLEtBQTdDLENBQWxCO0FBSUFDLE9BQUcsQ0FBQ0ksV0FBSixDQUFnQkgsU0FBaEI7QUFDQUQsT0FBRyxDQUFDSSxXQUFKLENBQWdCRCxTQUFoQjtBQUNBVCxlQUFXLENBQUNVLFdBQVosQ0FBd0JKLEdBQXhCO0FBQ0YsR0FoQkQ7QUFrQkFaLHVCQUFxQixDQUFDZ0IsV0FBdEIsQ0FBa0NWLFdBQWxDO0FBQ0FULE9BQUssQ0FBQ21CLFdBQU4sQ0FBa0JoQixxQkFBbEI7QUFDQUgsT0FBSyxDQUFDbUIsV0FBTixDQUFrQlYsV0FBbEI7QUFDSDtBQUdEOzs7OztBQUdBLFNBQVNiLFlBQVQsR0FBdUI7QUFDbkJ3QixTQUFPLENBQUNDLEdBQVIsQ0FBWSw4QkFBWixFQURtQixDQUVuQjs7QUFDQWpCLFFBQU0sQ0FBQ00sSUFBUCxDQUFZakIsVUFBWixFQUF3QmtCLE9BQXhCLENBQWdDLFVBQUFXLFFBQVEsRUFBSTtBQUN4QztBQUNBLFFBQU1DLElBQUksR0FBRzlCLFVBQVUsQ0FBQzZCLFFBQUQsQ0FBdkI7O0FBQ0EsUUFBR0MsSUFBSCxFQUFRO0FBQUEsVUFDR1YsU0FESCxHQUNxQ1UsSUFEckMsQ0FDR1YsU0FESDtBQUFBLFVBQ2NXLE1BRGQsR0FDcUNELElBRHJDLENBQ2NDLE1BRGQ7QUFBQSxVQUNzQlYsV0FEdEIsR0FDcUNTLElBRHJDLENBQ3NCVCxXQUR0QjtBQUVKRCxlQUFTLENBQUNGLE9BQVYsQ0FBa0IsVUFBQUMsR0FBRyxFQUFJO0FBQ3JCO0FBQ0FhLGNBQU0sQ0FBQ0MsZ0JBQVAsQ0FBd0IsU0FBeEIsRUFBbUMsVUFBQ0MsQ0FBRCxFQUFPO0FBQ3RDO0FBQ0EsY0FBR0EsQ0FBQyxDQUFDZixHQUFGLEtBQVVBLEdBQWIsRUFBaUI7QUFDYjtBQUNBUSxtQkFBTyxDQUFDQyxHQUFSLG1CQUF1QlAsV0FBdkI7QUFDQVUsa0JBQU07QUFDVDtBQUNKLFNBUEQ7QUFRSCxPQVZEO0FBV0g7QUFDSixHQWpCRDtBQWtCSCxDOzs7Ozs7Ozs7Ozs7QUNwRkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTs7OztBQUlPLElBQU1JLGNBQWMsR0FBRyxTQUFqQkEsY0FBaUIsR0FBSztBQUMvQixTQUFPM0IsUUFBUSxDQUFDQyxjQUFULENBQXdCLGFBQXhCLENBQVA7QUFDSCxDQUZNO0FBSVA7Ozs7O0FBSU8sU0FBUzJCLGVBQVQsQ0FBeUJDLFFBQXpCLEVBQWtDO0FBQ3JDLE1BQU1DLE9BQU8sR0FBRzlCLFFBQVEsQ0FBQytCLGFBQVQsQ0FBdUJGLFFBQXZCLENBQWhCOztBQUNBLE1BQUdDLE9BQUgsRUFBVztBQUNQQSxXQUFPLENBQUNFLEtBQVI7QUFDSCxHQUZELE1BRU87QUFDSGIsV0FBTyxDQUFDQyxHQUFSLG1CQUF1QlMsUUFBdkI7QUFDSDtBQUNKO0FBRUQ7Ozs7O0FBSU8sU0FBU2pDLDBCQUFULENBQW9DMkIsTUFBcEMsRUFBMkM7QUFDOUMsTUFBTXhCLEtBQUssR0FBR0MsUUFBUSxDQUFDQyxjQUFULENBQXdCLE9BQXhCLENBQWQ7O0FBQ0EsTUFBR0YsS0FBSCxFQUFTO0FBQ0xvQixXQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWjtBQUNBRyxVQUFNO0FBQ1QsR0FIRCxNQUdPO0FBQ0hKLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHdCQUFaO0FBQ0FhLGNBQVUsQ0FBQ3JDLDBCQUEwQixDQUFDc0MsSUFBM0IsQ0FBZ0MsSUFBaEMsRUFBc0NYLE1BQXRDLENBQUQsRUFBZ0QsR0FBaEQsQ0FBVjtBQUNIO0FBQ0osQzs7Ozs7Ozs7Ozs7O0FDbENEO0FBQUE7QUFBQTtBQUFBO0FBRUE7Ozs7QUFHTyxJQUFNN0IsZ0JBQWdCLEdBQUc7QUFDNUIsZUFBYTtBQUNUa0IsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURGO0FBRVRDLGVBQVcsRUFBRSw4QkFGSjtBQUdUVSxVQUFNLEVBQUU7QUFBQSxhQUFNSyw0REFBZSxDQUFDLG9DQUFELENBQXJCO0FBQUE7QUFIQyxHQURlO0FBTTVCLGlCQUFlO0FBQ1hoQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBREE7QUFFWEMsZUFBVyxFQUFFLG1CQUZGO0FBR1hVLFVBQU0sRUFBRTtBQUFBLGFBQU1LLDREQUFlLENBQUMsV0FBRCxDQUFyQjtBQUFBO0FBSEcsR0FOYTtBQVc1QixpQkFBZTtBQUNYaEIsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURBO0FBRVhDLGVBQVcsRUFBRSx1QkFGRjtBQUdYVSxVQUFNLEVBQUU7QUFBQSxhQUFNSyw0REFBZSxDQUFDLGlCQUFELENBQXJCO0FBQUE7QUFIRyxHQVhhO0FBZ0I1QixtQkFBaUI7QUFDYmhCLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FERTtBQUViQyxlQUFXLEVBQUUsOEJBRkE7QUFHYlUsVUFBTSxFQUFFO0FBQUEsYUFBTUssNERBQWUsQ0FBQyxpQkFBRCxDQUFyQjtBQUFBO0FBSEssR0FoQlc7QUFxQjVCLHNCQUFvQjtBQUNoQmhCLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FESztBQUVoQkMsZUFBVyxFQUFFLDRCQUZHO0FBR2hCVSxVQUFNLEVBQUU7QUFBQSxhQUFNSyw0REFBZSxDQUFDLGVBQUQsQ0FBckI7QUFBQTtBQUhRO0FBckJRLENBQXpCLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTFA7QUFDQTtBQUVBOzs7O0FBR08sU0FBU08sSUFBVCxHQUFlO0FBQ2xCdkMseUVBQTBCLENBQUM7QUFBQSxXQUFLd0Msb0JBQW9CLENBQUMsUUFBRCxDQUF6QjtBQUFBLEdBQUQsQ0FBMUI7QUFDQXhDLHlFQUEwQixDQUFDeUMsZUFBRCxDQUExQjtBQUNIO0FBRUQ7Ozs7QUFHTyxJQUFNNUMsbUJBQW1CLEdBQUc7QUFDL0IsMkJBQXlCO0FBQ3JCbUIsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURVO0FBRXJCQyxlQUFXLEVBQUUsaUNBRlE7QUFHckJVLFVBQU0sRUFBRTtBQUFBLGFBQU1LLDREQUFlLENBQUMsUUFBRCxDQUFyQjtBQUFBO0FBSGEsR0FETTtBQU0vQiwyQkFBeUI7QUFDckJoQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlUsVUFBTSxFQUFFO0FBQUEsYUFBTUssNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQU5NO0FBVy9CLDJCQUF5QjtBQUNyQmhCLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FEVTtBQUVyQkMsZUFBVyxFQUFFLGlDQUZRO0FBR3JCVSxVQUFNLEVBQUU7QUFBQSxhQUFNSyw0REFBZSxDQUFDLFFBQUQsQ0FBckI7QUFBQTtBQUhhLEdBWE07QUFnQi9CLDJCQUF5QjtBQUNyQmhCLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FEVTtBQUVyQkMsZUFBVyxFQUFFLGlDQUZRO0FBR3JCVSxVQUFNLEVBQUU7QUFBQSxhQUFNSyw0REFBZSxDQUFDLFFBQUQsQ0FBckI7QUFBQTtBQUhhLEdBaEJNO0FBcUIvQiwyQkFBeUI7QUFDckJoQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlUsVUFBTSxFQUFFO0FBQUEsYUFBTUssNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQXJCTTtBQTBCL0IsMkJBQXlCO0FBQ3JCaEIsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURVO0FBRXJCQyxlQUFXLEVBQUUsaUNBRlE7QUFHckJVLFVBQU0sRUFBRTtBQUFBLGFBQU1LLDREQUFlLENBQUMsUUFBRCxDQUFyQjtBQUFBO0FBSGEsR0ExQk07QUErQi9CLDJCQUF5QjtBQUNyQmhCLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FEVTtBQUVyQkMsZUFBVyxFQUFFLGlDQUZRO0FBR3JCVSxVQUFNLEVBQUU7QUFBQSxhQUFNSyw0REFBZSxDQUFDLFFBQUQsQ0FBckI7QUFBQTtBQUhhLEdBL0JNO0FBb0MvQiwyQkFBeUI7QUFDckJoQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlUsVUFBTSxFQUFFO0FBQUEsYUFBTUssNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQXBDTTtBQXlDL0IsMkJBQXlCO0FBQ3JCaEIsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURVO0FBRXJCQyxlQUFXLEVBQUUsaUNBRlE7QUFHckJVLFVBQU0sRUFBRTtBQUFBLGFBQU1LLDREQUFlLENBQUMsUUFBRCxDQUFyQjtBQUFBO0FBSGEsR0F6Q007QUE4Qy9CLDRCQUEwQjtBQUN0QmhCLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FEVztBQUV0QkMsZUFBVyxFQUFFLGFBRlM7QUFHdEJVLFVBQU0sRUFBRTtBQUFBLGFBQU1LLDREQUFlLENBQUMsT0FBRCxDQUFyQjtBQUFBO0FBSGMsR0E5Q0s7QUFtRC9CLDBCQUF3QjtBQUNwQmhCLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FEUztBQUVwQkMsZUFBVyxFQUFFLHdCQUZPO0FBR3BCVSxVQUFNLEVBQUU7QUFBQSxhQUFNSyw0REFBZSxDQUFDLGNBQUQsQ0FBckI7QUFBQTtBQUhZLEdBbkRPO0FBd0QvQiw0QkFBMEI7QUFDdEJoQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFc7QUFFdEJDLGVBQVcsRUFBRSwwQkFGUztBQUd0QlUsVUFBTSxFQUFFO0FBQUEsYUFBTUssNERBQWUsQ0FBQyxtQkFBRCxDQUFyQjtBQUFBO0FBSGMsR0F4REs7QUE2RC9CLG1DQUFpQztBQUM3QmhCLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FEa0I7QUFFN0JDLGVBQVcsRUFBRSw0QkFGZ0I7QUFHN0JVLFVBQU0sRUFBRTtBQUFBLGFBQU1LLDREQUFlLENBQUMsc0JBQUQsQ0FBckI7QUFBQTtBQUhxQixHQTdERjtBQWtFL0IsaUNBQStCO0FBQzNCaEIsYUFBUyxFQUFFLENBQUMsV0FBRCxDQURnQjtBQUUzQkMsZUFBVyxFQUFFLGtCQUZjO0FBRzNCVSxVQUFNLEVBQUU7QUFBQSxhQUFNZSxjQUFjLEVBQXBCO0FBQUE7QUFIbUIsR0FsRUE7QUF1RS9CLGtDQUFnQztBQUM1QjFCLGFBQVMsRUFBRSxDQUFDLFlBQUQsQ0FEaUI7QUFFNUJDLGVBQVcsRUFBRSxtQkFGZTtBQUc1QlUsVUFBTSxFQUFFO0FBQUEsYUFBTWdCLGVBQWUsRUFBckI7QUFBQTtBQUhvQixHQXZFRDtBQTRFL0IsK0JBQTZCO0FBQ3pCM0IsYUFBUyxFQUFFLENBQUMsU0FBRCxDQURjO0FBRXpCQyxlQUFXLEVBQUUsaUJBRlk7QUFHekJVLFVBQU0sRUFBRTtBQUFBLGFBQU1pQixZQUFZLEVBQWxCO0FBQUE7QUFIaUIsR0E1RUU7QUFpRi9CLGlDQUErQjtBQUMzQjVCLGFBQVMsRUFBRSxDQUFDLFdBQUQsQ0FEZ0I7QUFFM0JDLGVBQVcsRUFBRSxvQkFGYztBQUczQlUsVUFBTSxFQUFFO0FBQUEsYUFBTWtCLGNBQWMsRUFBcEI7QUFBQTtBQUhtQixHQWpGQTtBQXNGL0Isa0NBQWdDO0FBQzVCN0IsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURpQjtBQUU1QkMsZUFBVyxFQUFFLG1CQUZlO0FBRzVCVSxVQUFNLEVBQUU7QUFBQSxhQUFNbUIsZUFBZSxFQUFyQjtBQUFBO0FBSG9CO0FBdEZELENBQTVCO0FBNkZQOzs7OztBQUlPLFNBQVNOLG9CQUFULENBQThCUCxRQUE5QixFQUF1QztBQUMxQyxNQUFNYyxhQUFhLEdBQUdDLGVBQWUsRUFBckM7QUFDQSxNQUFNQyxXQUFXLEdBQUc3QyxRQUFRLENBQUMrQixhQUFULENBQXVCRixRQUF2QixDQUFwQjs7QUFDQSxNQUFHZ0IsV0FBSCxFQUFlO0FBQ1hBLGVBQVcsQ0FBQ0MsU0FBWixDQUFzQkMsR0FBdEIsQ0FBMEIsY0FBMUI7O0FBQ0EsUUFBR0osYUFBSCxFQUFpQjtBQUNiQSxtQkFBYSxDQUFDRyxTQUFkLENBQXdCRSxNQUF4QixDQUFnQyxjQUFoQztBQUNIO0FBQ0o7QUFDSjtBQUVEOzs7O0FBR0EsU0FBU1gsZUFBVCxHQUEyQjtBQUN2QixNQUFNWSxLQUFLLEdBQUdDLFdBQVcsRUFBekI7QUFDQUQsT0FBSyxDQUFDdkMsT0FBTixDQUFjLFVBQUF5QyxJQUFJLEVBQUk7QUFDbEIsUUFBTUMsS0FBSyxHQUFHRCxJQUFJLENBQUNwQixhQUFMLENBQW1CLFdBQW5CLEVBQWdDc0IsU0FBaEMsRUFBZDtBQUNBRCxTQUFLLENBQUNOLFNBQU4sQ0FBZ0JDLEdBQWhCLENBQW9CLFlBQXBCO0FBQ0FJLFFBQUksQ0FBQ0csYUFBTCxDQUFtQkMsWUFBbkIsQ0FBZ0NILEtBQWhDLEVBQXVDRCxJQUFJLENBQUNLLFdBQTVDO0FBQ0gsR0FKRDtBQUtIO0FBRUQ7Ozs7OztBQUlBLFNBQVNOLFdBQVQsR0FBdUI7QUFDbkIsNEJBQVdsRCxRQUFRLENBQUN5RCxnQkFBVCxDQUEwQixnQkFBMUIsQ0FBWDtBQUNIO0FBRUQ7Ozs7OztBQUlPLFNBQVNiLGVBQVQsR0FBMEI7QUFDN0IsU0FBTzVDLFFBQVEsQ0FBQytCLGFBQVQsQ0FBd0IsZUFBeEIsQ0FBUDtBQUNIO0FBRUQ7Ozs7O0FBSU8sU0FBUzJCLGtCQUFULENBQTRCQyxVQUE1QixFQUF1QztBQUMxQyxNQUFNQyxnQkFBZ0Isa0JBQVdELFVBQVgsQ0FBdEI7QUFDQXZCLHNCQUFvQixDQUFDd0IsZ0JBQUQsQ0FBcEI7QUFDSDtBQUVEOzs7Ozs7QUFLTyxTQUFTQyxhQUFULENBQXVCL0IsT0FBdkIsRUFBK0I7QUFDbEMsTUFBTWdDLEtBQUssR0FBRyxNQUFkOztBQUNBLE1BQUdoQyxPQUFILEVBQVc7QUFDUCxRQUFNNkIsVUFBVSxHQUFHN0IsT0FBTyxDQUFDaUMsRUFBUixDQUFXQyxLQUFYLENBQWlCRixLQUFqQixFQUF3QixDQUF4QixDQUFuQjs7QUFDQSxRQUFHO0FBQ0MsYUFBT0csUUFBUSxDQUFDTixVQUFELENBQWY7QUFDSCxLQUZELENBRUUsT0FBTU8sS0FBTixFQUFZO0FBQ1YvQyxhQUFPLENBQUNDLEdBQVIsV0FBZVUsT0FBTyxDQUFDaUMsRUFBdkI7QUFDQSxhQUFPLElBQVA7QUFDSDtBQUNKOztBQUNELFNBQU8sSUFBUDtBQUNIO0FBRUQ7Ozs7QUFHTyxTQUFTekIsY0FBVCxHQUF5QjtBQUM1QixNQUFNSyxhQUFhLEdBQUdDLGVBQWUsRUFBckM7QUFDQSxNQUFNdUIsY0FBYyxHQUFHTixhQUFhLENBQUNsQixhQUFELENBQWIsR0FBK0IsQ0FBdEQ7QUFFQWUsb0JBQWtCLENBQUNTLGNBQUQsQ0FBbEI7QUFDSDtBQUVEOzs7O0FBR08sU0FBUzVCLGVBQVQsR0FBMEI7QUFDN0IsTUFBTUksYUFBYSxHQUFHQyxlQUFlLEVBQXJDO0FBQ0EsTUFBTXVCLGNBQWMsR0FBR04sYUFBYSxDQUFDbEIsYUFBRCxDQUFiLEdBQStCLENBQXREO0FBRUFlLG9CQUFrQixDQUFDUyxjQUFELENBQWxCO0FBQ0g7QUFFRDs7OztBQUdPLFNBQVMzQixZQUFULEdBQXVCO0FBQzFCLE1BQU1HLGFBQWEsR0FBR0MsZUFBZSxFQUFyQztBQUNBLE1BQU11QixjQUFjLEdBQUdOLGFBQWEsQ0FBQ2xCLGFBQUQsQ0FBYixHQUErQixDQUF0RDtBQUVBZSxvQkFBa0IsQ0FBQ1MsY0FBRCxDQUFsQjtBQUNIO0FBRUQ7Ozs7QUFHTyxTQUFTMUIsY0FBVCxHQUF5QjtBQUM1QixNQUFNRSxhQUFhLEdBQUdDLGVBQWUsRUFBckM7QUFDQSxNQUFNdUIsY0FBYyxHQUFHTixhQUFhLENBQUNsQixhQUFELENBQWIsR0FBK0IsQ0FBdEQ7QUFFQWUsb0JBQWtCLENBQUNTLGNBQUQsQ0FBbEI7QUFDSDtBQUVEOzs7O0FBR08sU0FBU3pCLGVBQVQsR0FBMEI7QUFDN0IsTUFBTUMsYUFBYSxHQUFHM0MsUUFBUSxDQUFDK0IsYUFBVCxDQUF3QixlQUF4QixDQUF0QjtBQUNBWixTQUFPLENBQUNDLEdBQVIsQ0FBWSxzQkFBc0J1QixhQUFhLENBQUNvQixFQUFoRDs7QUFDQSxNQUFHcEIsYUFBSCxFQUFpQjtBQUNiLFFBQUlBLGFBQWEsQ0FBQ0csU0FBZCxDQUF3QnNCLFFBQXhCLENBQWlDLFFBQWpDLENBQUosRUFDQTtBQUNJakQsYUFBTyxDQUFDQyxHQUFSLENBQVksZ0NBQVo7QUFDQXVCLG1CQUFhLENBQUNYLEtBQWQ7QUFDQWIsYUFBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUNILEtBTEQsTUFNSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FELGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHNDQUFaO0FBQ0EsVUFBTWlELFVBQVUsR0FBR3JFLFFBQVEsQ0FBQytCLGFBQVQsQ0FBdUIsV0FBdkIsQ0FBbkI7O0FBQ0EsVUFBSXNDLFVBQUosRUFBZTtBQUNYQyxhQUFLLENBQUMsK0JBQUQsQ0FBTCxDQURXLENBRVg7QUFDQTtBQUNILE9BSkQsTUFLSTtBQUNBQSxhQUFLLENBQUMsc0RBQUQsQ0FBTDtBQUNIO0FBQ0o7QUFDSixHQXZCRCxNQXVCTztBQUNIbkQsV0FBTyxDQUFDQyxHQUFSLG1CQUF1QnVCLGFBQWEsQ0FBQ29CLEVBQXJDO0FBQ0g7QUFDSixDOzs7Ozs7Ozs7OztBQzFQRCx1QyIsImZpbGUiOiJzY3JpcHRzL2NvbnRlbnQuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIi9cIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IDEpO1xuIiwiLyoqXG4gKiBUaGlzIGlzIHRoZSBjb250ZW50IHNjcmlwdCB0aGF0IHdpbGwgcnVuIGluIGFsbCB5dWNhdGEuZGUgcGFnZXNcbiAqIEtleXMgb2YgdGhlIG1hcCBhcmUgdGhlIGJ1dHRvbnMgcHJlc3NlZFxuICogVmFsdWVzIG9mIHRoZSBtYXAgYXJlIG9iamVjdHMgZGVzY3JpYmluZyB0aGUgYWN0aW9uIGNvbnRhaW5pbmcgYSBkZXNjcmlwdGlvbiBhbmQgYSBtZXRob2RcbiAqL1xuaW1wb3J0IHttYWNoaUtvcm9Ib3RrZXlzTWFwLCBtYWluIGFzIG1hY2hpX2tvcm9fbWFpbn0gZnJvbSAnLi9ob3RrZXlzL21hY2hpX2tvcm8nO1xuaW1wb3J0IHtnbG9iYWxIb3RrZXlzTWFwfSBmcm9tICcuL2hvdGtleXMvZ2xvYmFsJztcbmltcG9ydCB7d2FpdEZvckJvYXJkVG9FeGlzdEFuZFRoZW59IGZyb20gXCIuL2RvbVwiO1xuXG5cbi8qKlxuICogQWxsIG9mIHRoZSBob3RrZXlzIGNvbWJpbmVkXG4gKi9cbmNvbnN0IGhvdGtleXNNYXAgPSB7XG4gIC4uLm1hY2hpS29yb0hvdGtleXNNYXAsXG4gIC4uLmdsb2JhbEhvdGtleXNNYXAsXG59O1xuXG5zZXR1cEhvdGtleXMoKTtcbndhaXRGb3JCb2FyZFRvRXhpc3RBbmRUaGVuKGFkZFRvb2x0aXApO1xubWFjaGlfa29yb19tYWluKCk7XG5cblxuLyoqXG4gKiBBZGQgYSB0b29sdGlwIHRvIHRoZSBVSSBjb250YWluaW5nIHRoZSBzaG9ydGN1dHNcbiAqL1xuZnVuY3Rpb24gYWRkVG9vbHRpcCgpe1xuICAgIGNvbnN0IGJvYXJkID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJib2FyZFwiKTtcbiAgICBjb25zdCB0b29sdGlwVHJpZ2dlckVsZW1lbnQgPSBPYmplY3QuYXNzaWduKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiksIHtcbiAgICAgICAgY2xhc3NOYW1lOiBcImhvdGtleVRvb2x0aXBUcmlnZ2VyIHVpLWJ0biB1aS1pbnB1dC1idG4gdWktYnRuLWEgdWktY29ybmVyLWFsbCB1aS1zaGFkb3cgdWktYnRuLWlubGluZSB1aS1taW5pIHVpLWZpcnN0LWNoaWxkXCIsXG4gICAgICAgIHRleHRDb250ZW50OiBcIkxpc3Qgb2YgSG90a2V5c1wiXG4gICAgfSk7XG4gICAgY29uc3QgdG9vbHRpcFRleHQgPSBPYmplY3QuYXNzaWduKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiksIHtcbiAgICAgICAgY2xhc3NOYW1lOiBcInRvb2x0aXBUZXh0XCIsXG4gICAgfSk7XG5cbiAgICBPYmplY3Qua2V5cyhob3RrZXlzTWFwKS5mb3JFYWNoKGtleSA9PiB7XG4gICAgICAgY29uc3Qge2tleUNvbWJvcywgZGVzY3JpcHRpb259ID0gaG90a2V5c01hcFtrZXldO1xuICAgICAgIGNvbnN0IHJvdyA9IE9iamVjdC5hc3NpZ24oZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKSwge1xuICAgICAgICAgICBjbGFzc05hbWU6IFwidG9vbHRpcFRleHRSb3dcIlxuICAgICAgIH0pO1xuICAgICAgIGNvbnN0IGxhYmVsQ2VsbCA9IE9iamVjdC5hc3NpZ24oZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKSwge1xuICAgICAgICAgICBjbGFzc05hbWU6IFwidG9vbHRpcFRleHRsYWJlbFwiLFxuICAgICAgICAgICB0ZXh0Q29udGVudDoga2V5Q29tYm9zWzBdLnRvTG9jYWxlVXBwZXJDYXNlKCkgKyBcIjpcIlxuICAgICAgIH0pO1xuICAgICAgIGNvbnN0IHZhbHVlQ2VsbCA9IE9iamVjdC5hc3NpZ24oZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKSwge1xuICAgICAgICAgICBjbGFzc05hbWU6IFwidG9vbHRpcFRleHRWYWx1ZVwiLFxuICAgICAgICAgICB0ZXh0Q29udGVudDogZGVzY3JpcHRpb25cbiAgICAgICB9KTtcbiAgICAgICByb3cuYXBwZW5kQ2hpbGQobGFiZWxDZWxsKTtcbiAgICAgICByb3cuYXBwZW5kQ2hpbGQodmFsdWVDZWxsKTtcbiAgICAgICB0b29sdGlwVGV4dC5hcHBlbmRDaGlsZChyb3cpO1xuICAgIH0pO1xuXG4gICAgdG9vbHRpcFRyaWdnZXJFbGVtZW50LmFwcGVuZENoaWxkKHRvb2x0aXBUZXh0KTtcbiAgICBib2FyZC5hcHBlbmRDaGlsZCh0b29sdGlwVHJpZ2dlckVsZW1lbnQpO1xuICAgIGJvYXJkLmFwcGVuZENoaWxkKHRvb2x0aXBUZXh0KTtcbn1cblxuXG4vKipcbiAqIFNldCB1cCB0aGUga2V5cHJlc3MgaGFuZGxlcnMgZm9yIGFsbCB0aGUgaG90a2V5c1xuICovXG5mdW5jdGlvbiBzZXR1cEhvdGtleXMoKXtcbiAgICBjb25zb2xlLmxvZyhcIkN1c3RvbSBZdWNhdGEgaG90a2V5cyBhZGRlZC5cIik7XG4gICAgLy8gRm9yIGVhY2gga2V5IGRlZmluZWQgaW4gdGhlIG1hcCAodW5pcXVlIGFjdGlvbiBuYW1lKVxuICAgIE9iamVjdC5rZXlzKGhvdGtleXNNYXApLmZvckVhY2goYWN0aW9uSWQgPT4ge1xuICAgICAgICAvLyBHZXQgdGhlIGRhdGEgb2JqZWN0XG4gICAgICAgIGNvbnN0IGRhdGEgPSBob3RrZXlzTWFwW2FjdGlvbklkXTtcbiAgICAgICAgaWYoZGF0YSl7XG4gICAgICAgICAgICBjb25zdCB7a2V5Q29tYm9zLCBtZXRob2QsIGRlc2NyaXB0aW9ufSA9IGRhdGE7XG4gICAgICAgICAgICBrZXlDb21ib3MuZm9yRWFjaChrZXkgPT4ge1xuICAgICAgICAgICAgICAgIC8vIEF0dGFjaCBhbiBrZXlwcmVzcyBldmVudCBsaXN0ZW5lciB0byB0aGUgd2luZG93IG9iamVjdFxuICAgICAgICAgICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCAoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAvLyBJZiB0aGUga2V5IGluIHRoZSBldmVudCBtYXRjaGVzIHRoZSBrZXkgd2UgYXJlIHNldHRpbmcgdXAgdGhlIGhhbmRsZXIgZm9yXG4gICAgICAgICAgICAgICAgICAgIGlmKGUua2V5ID09PSBrZXkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gSWYgd2UgaGF2ZSBhIGJpbmRpbmcgZm9yIHRoaXMgaG90a2V5XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgQWN0aW9uOiAke2Rlc2NyaXB0aW9ufWApO1xuICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfSk7XG59XG5cblxuXG5cblxuXG5cblxuIiwiLyoqXG4gKiBSZXR1cm4gdGhlIGRvbSBub2RlIG9mIHRoZSBidXR0b24gaW4gdGhlIHBvcHVwXG4gKiBAcmV0dXJucyB7SFRNTEVsZW1lbnR9XG4gKi9cbmV4cG9ydCBjb25zdCBnZXRQb3B1cEJ1dHRvbiA9ICgpID0+e1xuICAgIHJldHVybiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInBvcHVwQnV0dG9uXCIpO1xufTtcblxuLyoqXG4gKiBDbGljayB0aGUgZWxlbWVudCBpbiB0aGUgc2VsZWN0b3IgaWYgaXQgaXMgZm91bmRcbiAqIEBwYXJhbSB7c3RyaW5nfSBzZWxlY3RvclxuICovXG5leHBvcnQgZnVuY3Rpb24gY2xpY2tCeVNlbGVjdG9yKHNlbGVjdG9yKXtcbiAgICBjb25zdCBlbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihzZWxlY3Rvcik7XG4gICAgaWYoZWxlbWVudCl7XG4gICAgICAgIGVsZW1lbnQuY2xpY2soKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZyhgRWxlbWVudCAke3NlbGVjdG9yfSBub3QgZm91bmRgKTtcbiAgICB9XG59XG5cbi8qKlxuICogV2FpdCBmb3IgdGhlIGJvYXJkIERPTSBlbGVtZW50IHRvIGV4aXN0LCBhbmQgdGhlbiBleGVjdXRlIHRoZSBtZXRob2QgcGFzc2VkXG4gKiBAcGFyYW0ge2Z1bmN0aW9ufSBtZXRob2RcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHdhaXRGb3JCb2FyZFRvRXhpc3RBbmRUaGVuKG1ldGhvZCl7XG4gICAgY29uc3QgYm9hcmQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImJvYXJkXCIpO1xuICAgIGlmKGJvYXJkKXtcbiAgICAgICAgY29uc29sZS5sb2coXCJCb2FyZCBpcyByZWFkeS5cIik7XG4gICAgICAgIG1ldGhvZCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiTm8gYm9hcmQgeWV0LCB3YWl0aW5nLlwiKTtcbiAgICAgICAgc2V0VGltZW91dCh3YWl0Rm9yQm9hcmRUb0V4aXN0QW5kVGhlbi5iaW5kKHRoaXMsIG1ldGhvZCksIDUwMCk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHtjbGlja0J5U2VsZWN0b3J9IGZyb20gXCIuLi9kb21cIjtcblxuLyoqXG4gKiBIb3RrZXkgbWFwIGZvciBhbGwgZ2FtZXNcbiAqL1xuZXhwb3J0IGNvbnN0IGdsb2JhbEhvdGtleXNNYXAgPSB7XG4gICAgXCJnbG9iYWxfb2tcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcImdcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkhpdCAnT0snIHdoZW4gaXQncyB5b3VyIHR1cm5cIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIudWktcG9wdXAtYWN0aXZlIGlucHV0W3ZhbHVlPSdPSyddXCIpXG4gICAgfSxcbiAgICBcImdsb2JhbF91bmRvXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCJ1XCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJIaXQgJ1VuZG8nIGJ1dHRvblwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNidG5fdW5kb1wiKVxuICAgIH0sXG4gICAgXCJnbG9iYWxfcGFzc1wiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wicFwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiSGl0IHRoZSAnUGFzcycgYnV0dG9uXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2J0bl9CdG5QYXNzQnV5XCIpXG4gICAgfSxcbiAgICBcImdsb2JhbF9maW5pc2hcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcImZcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkhpdCB0aGUgJ0ZpbmlzaCBUdXJuJyBidXR0b25cIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjYnRuX2ZpbmlzaFR1cm5cIilcbiAgICB9LFxuICAgIFwiZ2xvYmFsX25leHRfZ2FtZVwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiblwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiSGl0IHRoZSAnTmV4dCBHYW1lJyBidXR0b25cIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjYnRuX25leHRHYW1lXCIpXG4gICAgfVxufTtcbiIsImltcG9ydCAnLi4vLi4vc2Nzcy9tYWNoaV9rb3JvLnNjc3MnO1xuaW1wb3J0IHtjbGlja0J5U2VsZWN0b3IsIHdhaXRGb3JCb2FyZFRvRXhpc3RBbmRUaGVufSBmcm9tIFwiLi4vZG9tXCI7XG5cbi8qKlxuICogTWFpbiBtZXRob2QgdG8gYmUgZXhlY3V0ZWQgKGJ5IGNvbnRlbnQuanMpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCl7XG4gICAgd2FpdEZvckJvYXJkVG9FeGlzdEFuZFRoZW4oKCk9PiBzZWxlY3RDYXJkQnlTZWxlY3RvcihcIiNjYXJkMVwiKSk7XG4gICAgd2FpdEZvckJvYXJkVG9FeGlzdEFuZFRoZW4oYWRkQ2FyZFRvb2x0aXBzKTtcbn1cblxuLyoqXG4gKiBIb3RrZXkgbWFwIGZvciBtYWNoaSBrb3JvIG9ubHlcbiAqL1xuZXhwb3J0IGNvbnN0IG1hY2hpS29yb0hvdGtleXNNYXAgPSB7XG4gICAgXCJtYWNoaV9rb3JvX2J1eV9zbG90XzFcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIjFcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkJ1eSBDYXJkIGluIFNsb3QgMSAoTWFjaGkgS29ybylcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjY2FyZDFcIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19idXlfc2xvdF8yXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCIyXCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJCdXkgQ2FyZCBpbiBTbG90IDIgKE1hY2hpIEtvcm8pXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2NhcmQyXCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fYnV5X3Nsb3RfM1wiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiM1wiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQnV5IENhcmQgaW4gU2xvdCAzIChNYWNoaSBLb3JvKVwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNjYXJkM1wiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX2J1eV9zbG90XzRcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIjRcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkJ1eSBDYXJkIGluIFNsb3QgNCAoTWFjaGkgS29ybylcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjY2FyZDRcIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19idXlfc2xvdF81XCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCI1XCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJCdXkgQ2FyZCBpbiBTbG90IDUgKE1hY2hpIEtvcm8pXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2NhcmQ1XCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fYnV5X3Nsb3RfNlwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiNlwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQnV5IENhcmQgaW4gU2xvdCA2IChNYWNoaSBLb3JvKVwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNjYXJkNlwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX2J1eV9zbG90XzdcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIjdcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkJ1eSBDYXJkIGluIFNsb3QgNyAoTWFjaGkgS29ybylcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjY2FyZDdcIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19idXlfc2xvdF84XCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCI4XCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJCdXkgQ2FyZCBpbiBTbG90IDggKE1hY2hpIEtvcm8pXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2NhcmQ4XCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fYnV5X3Nsb3RfOVwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiOVwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQnV5IENhcmQgaW4gU2xvdCA5IChNYWNoaSBLb3JvKVwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNjYXJkOVwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX3RvZ2dsZV9kaWNlXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCJkXCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJUb2dnbGUgRGljZVwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNkaWUyXCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fcm9sbF9kaWNlXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCJyXCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJIaXQgJ1JvbGwgZGljZScgYnV0dG9uXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2J0bl9Xw7xyZmVsblwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX3Jlcm9sbF9kaWNlXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCJxXCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJIaXQgJ1Jlcm9sbCBkaWNlJyBidXR0b25cIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjYnRuX0J0blJvbGxBZ2FpblwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX2RvX25vdF9yZXJvbGxfZGljZVwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wid1wiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiSGl0ICdEbyBOb3QgUmVyb2xsJyBidXR0b25cIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjYnRuX0J0blJvbGxOb3RBZ2FpblwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX3NlbGVjdF9jYXJkX2xlZnRcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIkFycm93TGVmdFwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiU2VsZWN0IExlZnQgQ2FyZFwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IHNlbGVjdENhcmRMZWZ0KClcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19zZWxlY3RfY2FyZF9yaWdodFwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiQXJyb3dSaWdodFwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiU2VsZWN0IFJpZ2h0IENhcmRcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBzZWxlY3RDYXJkUmlnaHQoKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX3NlbGVjdF9jYXJkX3VwXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCJBcnJvd1VwXCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJTZWxlY3QgVG9wIENhcmRcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBzZWxlY3RDYXJkVXAoKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX3NlbGVjdF9jYXJkX2Rvd25cIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIkFycm93RG93blwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiU2VsZWN0IEJvdHRvbSBDYXJkXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gc2VsZWN0Q2FyZERvd24oKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX2J1eV9zZWxlY3RlZF9jYXJkXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCJiXCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJCdXkgU2VsZWN0ZWQgQ2FyZFwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGJ1eVNlbGVjdGVkQ2FyZCgpXG4gICAgfVxufTtcblxuLyoqXG4gKiBBZGQgdGhlIFwic2VsZWN0ZWRDYXJkXCIgY2xhc3MgdG8gdGhlIGVsZW1lbnQgbWF0Y2hlZCBieSB0aGUgc2VsZWN0b3IgKGlmIGFueSlcbiAqIEBwYXJhbSB7c3RyaW5nfSBzZWxlY3RvclxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0Q2FyZEJ5U2VsZWN0b3Ioc2VsZWN0b3Ipe1xuICAgIGNvbnN0IGFjdGl2ZUVsZW1lbnQgPSBnZXRTZWxlY3RlZENhcmQoKTtcbiAgICBjb25zdCBjYXJkRWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3Ioc2VsZWN0b3IpO1xuICAgIGlmKGNhcmRFbGVtZW50KXtcbiAgICAgICAgY2FyZEVsZW1lbnQuY2xhc3NMaXN0LmFkZChcInNlbGVjdGVkQ2FyZFwiKTtcbiAgICAgICAgaWYoYWN0aXZlRWxlbWVudCl7XG4gICAgICAgICAgICBhY3RpdmVFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoIFwic2VsZWN0ZWRDYXJkXCIgKTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLyoqXG4gKiBBZGRzIGNhcmQgdG9vbHRpcHMgb24gaG92ZXIgKHpvb21lZCBpbiBjYXJkcylcbiAqL1xuZnVuY3Rpb24gYWRkQ2FyZFRvb2x0aXBzKCkge1xuICAgIGNvbnN0IGNhcmRzID0gZ2V0Q2FyZHNEb20oKTtcbiAgICBjYXJkcy5mb3JFYWNoKGNhcmQgPT4ge1xuICAgICAgICBjb25zdCBjbG9uZSA9IGNhcmQucXVlcnlTZWxlY3RvcihcIi5jYXJkIGltZ1wiKS5jbG9uZU5vZGUoKTtcbiAgICAgICAgY2xvbmUuY2xhc3NMaXN0LmFkZChcImNhcmRab29tZWRcIik7XG4gICAgICAgIGNhcmQucGFyZW50RWxlbWVudC5pbnNlcnRCZWZvcmUoY2xvbmUsIGNhcmQubmV4dFNpYmxpbmcpO1xuICAgIH0pXG59XG5cbi8qKlxuICpcbiAqIEByZXR1cm5zIHtOb2RlTGlzdE9mPEVsZW1lbnQ+fVxuICovXG5mdW5jdGlvbiBnZXRDYXJkc0RvbSgpIHtcbiAgICByZXR1cm4gWy4uLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIuY2FyZENvbnRhaW5lclwiKV07XG59XG5cbi8qKlxuICogUmV0dXJuIHRoZSBjYXJkIHRoYXQgaXMgY3VycmVudGx5IHNlbGVjdGVkIChoYXMgdGhlIGNsYXNzIHNlbGVjdGVkQ2FyZClcbiAqIEByZXR1cm5zIHtFbGVtZW50fVxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0U2VsZWN0ZWRDYXJkKCl7XG4gICAgcmV0dXJuIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoIFwiLnNlbGVjdGVkQ2FyZFwiKTtcbn1cblxuLyoqXG4gKiBTZWxlY3QgYSBjYXJkIGJhc2VkIG9uIHRoZSBudW1iZXIgcHJvdmlkZWRcbiAqIEBwYXJhbSB7bnVtYmVyfSBjYXJkTnVtYmVyXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZWxlY3RDYXJkQnlOdW1iZXIoY2FyZE51bWJlcil7XG4gICAgY29uc3QgbmV4dENhcmRTZWxlY3RvciA9IGAjY2FyZCR7Y2FyZE51bWJlcn1gO1xuICAgIHNlbGVjdENhcmRCeVNlbGVjdG9yKG5leHRDYXJkU2VsZWN0b3IpO1xufVxuXG4vKipcbiAqIFJldHVybiB0aGUgY2FyZCBudW1iZXIgZm9yIHRoZSBwcm92aWRlZCBlbGVtZW50XG4gKiBAcGFyYW0ge0VsZW1lbnR9IGVsZW1lbnRcbiAqIEByZXR1cm5zIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRDYXJkTnVtYmVyKGVsZW1lbnQpe1xuICAgIGNvbnN0IHJlZ2V4ID0gL1xcZCskLztcbiAgICBpZihlbGVtZW50KXtcbiAgICAgICAgY29uc3QgY2FyZE51bWJlciA9IGVsZW1lbnQuaWQubWF0Y2gocmVnZXgpWzBdO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICByZXR1cm4gcGFyc2VJbnQoY2FyZE51bWJlcik7XG4gICAgICAgIH0gY2F0Y2goZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coYCR7ZWxlbWVudC5pZH0gZGlkIG5vdCBoYXZlIGEgbnVtYmVyIGF0IHRoZSBlbmQgb2YgaXRzIElEYCk7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbn1cblxuLyoqXG4gKiBTZWxlY3QgdGhlIGNhcmQgdG8gdGhlIGxlZnQgb2YgdGhlIGFjdGl2ZSBjYXJkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZWxlY3RDYXJkTGVmdCgpe1xuICAgIGNvbnN0IGFjdGl2ZUVsZW1lbnQgPSBnZXRTZWxlY3RlZENhcmQoKTtcbiAgICBjb25zdCBuZXh0Q2FyZE51bWJlciA9IGdldENhcmROdW1iZXIoYWN0aXZlRWxlbWVudCkgLSAxO1xuXG4gICAgc2VsZWN0Q2FyZEJ5TnVtYmVyKG5leHRDYXJkTnVtYmVyKTtcbn1cblxuLyoqXG4gKiBTZWxlY3QgdGhlIGNhcmQgdG8gdGhlIHJpZ2h0IG9mIHRoZSBhY3RpdmUgY2FyZFxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0Q2FyZFJpZ2h0KCl7XG4gICAgY29uc3QgYWN0aXZlRWxlbWVudCA9IGdldFNlbGVjdGVkQ2FyZCgpO1xuICAgIGNvbnN0IG5leHRDYXJkTnVtYmVyID0gZ2V0Q2FyZE51bWJlcihhY3RpdmVFbGVtZW50KSArIDE7XG5cbiAgICBzZWxlY3RDYXJkQnlOdW1iZXIobmV4dENhcmROdW1iZXIpO1xufVxuXG4vKipcbiAqIFNlbGVjdCB0aGUgY2FyZCB0byB0aGUgdXAgb2YgdGhlIGFjdGl2ZSBjYXJkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZWxlY3RDYXJkVXAoKXtcbiAgICBjb25zdCBhY3RpdmVFbGVtZW50ID0gZ2V0U2VsZWN0ZWRDYXJkKCk7XG4gICAgY29uc3QgbmV4dENhcmROdW1iZXIgPSBnZXRDYXJkTnVtYmVyKGFjdGl2ZUVsZW1lbnQpIC0gNTtcblxuICAgIHNlbGVjdENhcmRCeU51bWJlcihuZXh0Q2FyZE51bWJlcik7XG59XG5cbi8qKlxuICogU2VsZWN0IHRoZSBjYXJkIHRvIHRoZSBkb3duIG9mIHRoZSBhY3RpdmUgY2FyZFxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0Q2FyZERvd24oKXtcbiAgICBjb25zdCBhY3RpdmVFbGVtZW50ID0gZ2V0U2VsZWN0ZWRDYXJkKCk7XG4gICAgY29uc3QgbmV4dENhcmROdW1iZXIgPSBnZXRDYXJkTnVtYmVyKGFjdGl2ZUVsZW1lbnQpICsgNTtcblxuICAgIHNlbGVjdENhcmRCeU51bWJlcihuZXh0Q2FyZE51bWJlcik7XG59XG5cbi8qKlxuICogQnV5IHRoZSBjYXJkIHRoYXQgaXMgY3VycmVudGx5IHNlbGVjdGVkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBidXlTZWxlY3RlZENhcmQoKXtcbiAgICBjb25zdCBhY3RpdmVFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggXCIuc2VsZWN0ZWRDYXJkXCIpO1xuICAgIGNvbnNvbGUubG9nKFwiT2sgSSB3YW50IHRvIGJ1eSBcIiArIGFjdGl2ZUVsZW1lbnQuaWQpO1xuICAgIGlmKGFjdGl2ZUVsZW1lbnQpe1xuICAgICAgICBpZiAoYWN0aXZlRWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoXCJhY3RpdmVcIikpXG4gICAgICAgIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiSXQncyBhY3RpdmUsIHN1cmUsIEknbGwgYnV5IGl0XCIpO1xuICAgICAgICAgICAgYWN0aXZlRWxlbWVudC5jbGljaygpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJDbGlja1wiKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgLy8gYXV0byBidmdhaW5laSBhblxuICAgICAgICAgICAgLy8gMS4gZGVuIGVpbmFpIGF2YWlsYWJsZSBhdXRoXG4gICAgICAgICAgICAvLyAyLiBleGVpcyBhZ29yYXNlaSBoZGggICoqIM6xzr0gz4XPgM6xz4HPh861zrkgzrrOv8+FzrzPgM6vIM6xzr3PhM6/z40gXCIjYnRuX3VuZG9cIlxuICAgICAgICAgICAgLy8gMy4gZGVuIGVpbmFpIGggc2VpcmEgc291IC0tIGF1dG8gaXN3cyB0byBseW5veW1lIG1lIHRvIG5hIHRzZWthcm91bWUgc2VpcmEgYXBvIHByaW5cbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRG9lc24ndCBzZWVtIHRvIGJlIGF2YWlsYWJsZSB0aG91Z2guXCIpO1xuICAgICAgICAgICAgY29uc3QgdW5kb0J1dHRvbiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjYnRuX3VuZG9cIik7XG4gICAgICAgICAgICBpZiAodW5kb0J1dHRvbil7XG4gICAgICAgICAgICAgICAgYWxlcnQoXCJZb3UndmUgYWxyZWFkeSBjaG9zZW4gYSBjYXJkLlwiKTtcbiAgICAgICAgICAgICAgICAvLyBhbiB2Z2Fsb3VtZSB0byBibGUgb3RhbiBkZW4gZWluYWkgaCBzZWlyYSBzb3UgZGUgeHJlaWF6ZXRhaSBhdXRvXG4gICAgICAgICAgICAgICAgLy8gYWxsYSBwcmVwZWkgbmEgeGFuYWdpbmV0YWkgYmxlIG90YW4gZWluYWkgaCBzZWlyYSBzb3VcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgYWxlcnQoXCJZb3UgY2FuJ3QgYnV5IHRoaXMgb25lIDooIFxcbkNob3NlIGFuIGF2YWlsYWJsZSBjYXJkLlwiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBFbGVtZW50ICR7YWN0aXZlRWxlbWVudC5pZH0gbm90IGZvdW5kYCk7XG4gICAgfVxufVxuIiwiLy8gZXh0cmFjdGVkIGJ5IG1pbmktY3NzLWV4dHJhY3QtcGx1Z2luIl0sInNvdXJjZVJvb3QiOiIifQ==