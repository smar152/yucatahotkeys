/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/hotkeys-js/dist/hotkeys.esm.js":
/*!*****************************************************!*\
  !*** ./node_modules/hotkeys-js/dist/hotkeys.esm.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/*!
 * hotkeys-js v3.7.1
 * A simple micro-library for defining and dispatching keyboard shortcuts. It has no dependencies.
 * 
 * Copyright (c) 2019 kenny wong <wowohoo@qq.com>
 * http://jaywcjlove.github.io/hotkeys
 * 
 * Licensed under the MIT license.
 */

function _typeof(obj) {
  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function (obj) {
      return typeof obj;
    };
  } else {
    _typeof = function (obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

var isff = typeof navigator !== 'undefined' ? navigator.userAgent.toLowerCase().indexOf('firefox') > 0 : false; // 绑定事件

function addEvent(object, event, method) {
  if (object.addEventListener) {
    object.addEventListener(event, method, false);
  } else if (object.attachEvent) {
    object.attachEvent("on".concat(event), function () {
      method(window.event);
    });
  }
} // 修饰键转换成对应的键码


function getMods(modifier, key) {
  var mods = key.slice(0, key.length - 1);

  for (var i = 0; i < mods.length; i++) {
    mods[i] = modifier[mods[i].toLowerCase()];
  }

  return mods;
} // 处理传的key字符串转换成数组


function getKeys(key) {
  if (typeof key !== 'string') key = '';
  key = key.replace(/\s/g, ''); // 匹配任何空白字符,包括空格、制表符、换页符等等

  var keys = key.split(','); // 同时设置多个快捷键，以','分割

  var index = keys.lastIndexOf(''); // 快捷键可能包含','，需特殊处理

  for (; index >= 0;) {
    keys[index - 1] += ',';
    keys.splice(index, 1);
    index = keys.lastIndexOf('');
  }

  return keys;
} // 比较修饰键的数组


function compareArray(a1, a2) {
  var arr1 = a1.length >= a2.length ? a1 : a2;
  var arr2 = a1.length >= a2.length ? a2 : a1;
  var isIndex = true;

  for (var i = 0; i < arr1.length; i++) {
    if (arr2.indexOf(arr1[i]) === -1) isIndex = false;
  }

  return isIndex;
}

var _modifierMap;
var _keyMap = {
  // 特殊键
  backspace: 8,
  tab: 9,
  clear: 12,
  enter: 13,
  "return": 13,
  esc: 27,
  escape: 27,
  space: 32,
  left: 37,
  up: 38,
  right: 39,
  down: 40,
  del: 46,
  "delete": 46,
  ins: 45,
  insert: 45,
  home: 36,
  end: 35,
  pageup: 33,
  pagedown: 34,
  capslock: 20,
  '⇪': 20,
  ',': 188,
  '.': 190,
  '/': 191,
  '`': 192,
  '-': isff ? 173 : 189,
  '=': isff ? 61 : 187,
  ';': isff ? 59 : 186,
  '\'': 222,
  '[': 219,
  ']': 221,
  '\\': 220
};
var _modifier = {
  // 修饰键
  // shiftKey
  '⇧': 16,
  shift: 16,
  // altKey
  '⌥': 18,
  alt: 18,
  option: 18,
  // ctrlKey
  '⌃': 17,
  ctrl: 17,
  control: 17,
  // metaKey
  '⌘': isff ? 224 : 91,
  cmd: isff ? 224 : 91,
  command: isff ? 224 : 91
};
var modifierMap = (_modifierMap = {
  16: 'shiftKey',
  18: 'altKey',
  17: 'ctrlKey'
}, _defineProperty(_modifierMap, isff ? 224 : 91, 'metaKey'), _defineProperty(_modifierMap, "shiftKey", 16), _defineProperty(_modifierMap, "ctrlKey", 17), _defineProperty(_modifierMap, "altKey", 18), _defineProperty(_modifierMap, "metaKey", 91), _modifierMap);

var _mods = _defineProperty({
  16: false,
  18: false,
  17: false
}, isff ? 224 : 91, false);

var _handlers = {}; // F1~F12 特殊键

for (var k = 1; k < 20; k++) {
  _keyMap["f".concat(k)] = 111 + k;
}

var _downKeys = []; // 记录摁下的绑定键

var _scope = 'all'; // 默认热键范围

var elementHasBindEvent = []; // 已绑定事件的节点记录
// 返回键码

var code = function code(x) {
  return _keyMap[x.toLowerCase()] || _modifier[x.toLowerCase()] || x.toUpperCase().charCodeAt(0);
}; // 设置获取当前范围（默认为'所有'）


function setScope(scope) {
  _scope = scope || 'all';
} // 获取当前范围


function getScope() {
  return _scope || 'all';
} // 获取摁下绑定键的键值


function getPressedKeyCodes() {
  return _downKeys.slice(0);
} // 表单控件控件判断 返回 Boolean
// hotkey is effective only when filter return true


function filter(event) {
  var target = event.target || event.srcElement;
  var tagName = target.tagName;
  var flag = true; // ignore: isContentEditable === 'true', <input> and <textarea> when readOnly state is false, <select>

  if (target.isContentEditable || tagName === 'TEXTAREA' || (tagName === 'INPUT' || tagName === 'TEXTAREA') && !target.readOnly) {
    flag = false;
  }

  return flag;
} // 判断摁下的键是否为某个键，返回true或者false


function isPressed(keyCode) {
  if (typeof keyCode === 'string') {
    keyCode = code(keyCode); // 转换成键码
  }

  return _downKeys.indexOf(keyCode) !== -1;
} // 循环删除handlers中的所有 scope(范围)


function deleteScope(scope, newScope) {
  var handlers;
  var i; // 没有指定scope，获取scope

  if (!scope) scope = getScope();

  for (var key in _handlers) {
    if (Object.prototype.hasOwnProperty.call(_handlers, key)) {
      handlers = _handlers[key];

      for (i = 0; i < handlers.length;) {
        if (handlers[i].scope === scope) handlers.splice(i, 1);else i++;
      }
    }
  } // 如果scope被删除，将scope重置为all


  if (getScope() === scope) setScope(newScope || 'all');
} // 清除修饰键


function clearModifier(event) {
  var key = event.keyCode || event.which || event.charCode;

  var i = _downKeys.indexOf(key); // 从列表中清除按压过的键


  if (i >= 0) {
    _downKeys.splice(i, 1);
  } // 特殊处理 cmmand 键，在 cmmand 组合快捷键 keyup 只执行一次的问题


  if (event.key && event.key.toLowerCase() === 'meta') {
    _downKeys.splice(0, _downKeys.length);
  } // 修饰键 shiftKey altKey ctrlKey (command||metaKey) 清除


  if (key === 93 || key === 224) key = 91;

  if (key in _mods) {
    _mods[key] = false; // 将修饰键重置为false

    for (var k in _modifier) {
      if (_modifier[k] === key) hotkeys[k] = false;
    }
  }
}

function unbind(keysInfo) {
  // unbind(), unbind all keys
  if (!keysInfo) {
    Object.keys(_handlers).forEach(function (key) {
      return delete _handlers[key];
    });
  } else if (Array.isArray(keysInfo)) {
    // support like : unbind([{key: 'ctrl+a', scope: 's1'}, {key: 'ctrl-a', scope: 's2', splitKey: '-'}])
    keysInfo.forEach(function (info) {
      if (info.key) eachUnbind(info);
    });
  } else if (_typeof(keysInfo) === 'object') {
    // support like unbind({key: 'ctrl+a, ctrl+b', scope:'abc'})
    if (keysInfo.key) eachUnbind(keysInfo);
  } else if (typeof keysInfo === 'string') {
    for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      args[_key - 1] = arguments[_key];
    }

    // support old method
    // eslint-disable-line
    var scope = args[0],
        method = args[1];

    if (typeof scope === 'function') {
      method = scope;
      scope = '';
    }

    eachUnbind({
      key: keysInfo,
      scope: scope,
      method: method,
      splitKey: '+'
    });
  }
} // 解除绑定某个范围的快捷键


var eachUnbind = function eachUnbind(_ref) {
  var key = _ref.key,
      scope = _ref.scope,
      method = _ref.method,
      _ref$splitKey = _ref.splitKey,
      splitKey = _ref$splitKey === void 0 ? '+' : _ref$splitKey;
  var multipleKeys = getKeys(key);
  multipleKeys.forEach(function (originKey) {
    var unbindKeys = originKey.split(splitKey);
    var len = unbindKeys.length;
    var lastKey = unbindKeys[len - 1];
    var keyCode = lastKey === '*' ? '*' : code(lastKey);
    if (!_handlers[keyCode]) return; // 判断是否传入范围，没有就获取范围

    if (!scope) scope = getScope();
    var mods = len > 1 ? getMods(_modifier, unbindKeys) : [];
    _handlers[keyCode] = _handlers[keyCode].map(function (record) {
      // 通过函数判断，是否解除绑定，函数相等直接返回
      var isMatchingMethod = method ? record.method === method : true;

      if (isMatchingMethod && record.scope === scope && compareArray(record.mods, mods)) {
        return {};
      }

      return record;
    });
  });
}; // 对监听对应快捷键的回调函数进行处理


function eventHandler(event, handler, scope) {
  var modifiersMatch; // 看它是否在当前范围

  if (handler.scope === scope || handler.scope === 'all') {
    // 检查是否匹配修饰符（如果有返回true）
    modifiersMatch = handler.mods.length > 0;

    for (var y in _mods) {
      if (Object.prototype.hasOwnProperty.call(_mods, y)) {
        if (!_mods[y] && handler.mods.indexOf(+y) > -1 || _mods[y] && handler.mods.indexOf(+y) === -1) {
          modifiersMatch = false;
        }
      }
    } // 调用处理程序，如果是修饰键不做处理


    if (handler.mods.length === 0 && !_mods[16] && !_mods[18] && !_mods[17] && !_mods[91] || modifiersMatch || handler.shortcut === '*') {
      if (handler.method(event, handler) === false) {
        if (event.preventDefault) event.preventDefault();else event.returnValue = false;
        if (event.stopPropagation) event.stopPropagation();
        if (event.cancelBubble) event.cancelBubble = true;
      }
    }
  }
} // 处理keydown事件


function dispatch(event) {
  var asterisk = _handlers['*'];
  var key = event.keyCode || event.which || event.charCode; // 表单控件过滤 默认表单控件不触发快捷键

  if (!hotkeys.filter.call(this, event)) return; // Gecko(Firefox)的command键值224，在Webkit(Chrome)中保持一致
  // Webkit左右 command 键值不一样

  if (key === 93 || key === 224) key = 91;
  /**
   * Collect bound keys
   * If an Input Method Editor is processing key input and the event is keydown, return 229.
   * https://stackoverflow.com/questions/25043934/is-it-ok-to-ignore-keydown-events-with-keycode-229
   * http://lists.w3.org/Archives/Public/www-dom/2010JulSep/att-0182/keyCode-spec.html
   */

  if (_downKeys.indexOf(key) === -1 && key !== 229) _downKeys.push(key);
  /**
   * Jest test cases are required.
   * ===============================
   */

  ['ctrlKey', 'altKey', 'shiftKey', 'metaKey'].forEach(function (keyName) {
    var keyNum = modifierMap[keyName];

    if (event[keyName] && _downKeys.indexOf(keyNum) === -1) {
      _downKeys.push(keyNum);
    } else if (!event[keyName] && _downKeys.indexOf(keyNum) > -1) {
      _downKeys.splice(_downKeys.indexOf(keyNum), 1);
    }
  });
  /**
   * -------------------------------
   */

  if (key in _mods) {
    _mods[key] = true; // 将特殊字符的key注册到 hotkeys 上

    for (var k in _modifier) {
      if (_modifier[k] === key) hotkeys[k] = true;
    }

    if (!asterisk) return;
  } // 将 modifierMap 里面的修饰键绑定到 event 中


  for (var e in _mods) {
    if (Object.prototype.hasOwnProperty.call(_mods, e)) {
      _mods[e] = event[modifierMap[e]];
    }
  } // 获取范围 默认为 `all`


  var scope = getScope(); // 对任何快捷键都需要做的处理

  if (asterisk) {
    for (var i = 0; i < asterisk.length; i++) {
      if (asterisk[i].scope === scope && (event.type === 'keydown' && asterisk[i].keydown || event.type === 'keyup' && asterisk[i].keyup)) {
        eventHandler(event, asterisk[i], scope);
      }
    }
  } // key 不在 _handlers 中返回


  if (!(key in _handlers)) return;

  for (var _i = 0; _i < _handlers[key].length; _i++) {
    if (event.type === 'keydown' && _handlers[key][_i].keydown || event.type === 'keyup' && _handlers[key][_i].keyup) {
      if (_handlers[key][_i].key) {
        var record = _handlers[key][_i];
        var splitKey = record.splitKey;
        var keyShortcut = record.key.split(splitKey);
        var _downKeysCurrent = []; // 记录当前按键键值

        for (var a = 0; a < keyShortcut.length; a++) {
          _downKeysCurrent.push(code(keyShortcut[a]));
        }

        if (_downKeysCurrent.sort().join('') === _downKeys.sort().join('')) {
          // 找到处理内容
          eventHandler(event, record, scope);
        }
      }
    }
  }
} // 判断 element 是否已经绑定事件


function isElementBind(element) {
  return elementHasBindEvent.indexOf(element) > -1;
}

function hotkeys(key, option, method) {
  _downKeys = [];
  var keys = getKeys(key); // 需要处理的快捷键列表

  var mods = [];
  var scope = 'all'; // scope默认为all，所有范围都有效

  var element = document; // 快捷键事件绑定节点

  var i = 0;
  var keyup = false;
  var keydown = true;
  var splitKey = '+'; // 对为设定范围的判断

  if (method === undefined && typeof option === 'function') {
    method = option;
  }

  if (Object.prototype.toString.call(option) === '[object Object]') {
    if (option.scope) scope = option.scope; // eslint-disable-line

    if (option.element) element = option.element; // eslint-disable-line

    if (option.keyup) keyup = option.keyup; // eslint-disable-line

    if (option.keydown !== undefined) keydown = option.keydown; // eslint-disable-line

    if (typeof option.splitKey === 'string') splitKey = option.splitKey; // eslint-disable-line
  }

  if (typeof option === 'string') scope = option; // 对于每个快捷键进行处理

  for (; i < keys.length; i++) {
    key = keys[i].split(splitKey); // 按键列表

    mods = []; // 如果是组合快捷键取得组合快捷键

    if (key.length > 1) mods = getMods(_modifier, key); // 将非修饰键转化为键码

    key = key[key.length - 1];
    key = key === '*' ? '*' : code(key); // *表示匹配所有快捷键
    // 判断key是否在_handlers中，不在就赋一个空数组

    if (!(key in _handlers)) _handlers[key] = [];

    _handlers[key].push({
      keyup: keyup,
      keydown: keydown,
      scope: scope,
      mods: mods,
      shortcut: keys[i],
      method: method,
      key: keys[i],
      splitKey: splitKey
    });
  } // 在全局document上设置快捷键


  if (typeof element !== 'undefined' && !isElementBind(element) && window) {
    elementHasBindEvent.push(element);
    addEvent(element, 'keydown', function (e) {
      dispatch(e);
    });
    addEvent(window, 'focus', function () {
      _downKeys = [];
    });
    addEvent(element, 'keyup', function (e) {
      dispatch(e);
      clearModifier(e);
    });
  }
}

var _api = {
  setScope: setScope,
  getScope: getScope,
  deleteScope: deleteScope,
  getPressedKeyCodes: getPressedKeyCodes,
  isPressed: isPressed,
  filter: filter,
  unbind: unbind
};

for (var a in _api) {
  if (Object.prototype.hasOwnProperty.call(_api, a)) {
    hotkeys[a] = _api[a];
  }
}

if (typeof window !== 'undefined') {
  var _hotkeys = window.hotkeys;

  hotkeys.noConflict = function (deep) {
    if (deep && window.hotkeys === hotkeys) {
      window.hotkeys = _hotkeys;
    }

    return hotkeys;
  };

  window.hotkeys = hotkeys;
}

/* harmony default export */ __webpack_exports__["default"] = (hotkeys);


/***/ }),

/***/ "./src/scripts/content.js":
/*!********************************!*\
  !*** ./src/scripts/content.js ***!
  \********************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _hotkeys_machi_koro__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./hotkeys/machi_koro */ "./src/scripts/hotkeys/machi_koro.js");
/* harmony import */ var _hotkeys_global__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./hotkeys/global */ "./src/scripts/hotkeys/global.js");
/* harmony import */ var _dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dom */ "./src/scripts/dom.js");
/* harmony import */ var hotkeys_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! hotkeys-js */ "./node_modules/hotkeys-js/dist/hotkeys.esm.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/**
 * This is the content script that will run in all yucata.de pages
 * Keys of the map are the buttons pressed
 * Values of the map are objects describing the action containing a description and a method
 */




/**
 * All of the hotkeys combined
 */

var hotkeysMap = _objectSpread({}, _hotkeys_machi_koro__WEBPACK_IMPORTED_MODULE_0__["machiKoroHotkeysMap"], {}, _hotkeys_global__WEBPACK_IMPORTED_MODULE_1__["globalHotkeysMap"]);

setupHotkeys();
Object(_dom__WEBPACK_IMPORTED_MODULE_2__["waitForBoardToExistAndThen"])(addTooltip);
Object(_hotkeys_machi_koro__WEBPACK_IMPORTED_MODULE_0__["main"])();
/**
 * Add a tooltip to the UI containing the shortcuts
 */

function addTooltip() {
  var board = document.getElementById("board");
  var tooltipTriggerElement = Object.assign(document.createElement("div"), {
    className: "hotkeyTooltipTrigger ui-btn ui-input-btn ui-btn-a ui-corner-all ui-shadow ui-btn-inline ui-mini ui-first-child",
    textContent: "List of Hotkeys"
  });
  var tooltipText = Object.assign(document.createElement("div"), {
    className: "tooltipText"
  });
  Object.keys(hotkeysMap).forEach(function (key) {
    var _hotkeysMap$key = hotkeysMap[key],
        keyCombos = _hotkeysMap$key.keyCombos,
        description = _hotkeysMap$key.description;
    var row = Object.assign(document.createElement("div"), {
      className: "tooltipTextRow"
    });
    var labelCell = Object.assign(document.createElement("div"), {
      className: "tooltipTextlabel",
      textContent: keyCombos[0].toLocaleUpperCase() + ":"
    });
    var valueCell = Object.assign(document.createElement("div"), {
      className: "tooltipTextValue",
      textContent: description
    });
    row.appendChild(labelCell);
    row.appendChild(valueCell);
    tooltipText.appendChild(row);
  });
  tooltipTriggerElement.appendChild(tooltipText);
  board.appendChild(tooltipTriggerElement);
  board.appendChild(tooltipText);
}
/**
 * Set up the keypress handlers for all the hotkeys
 */


function setupHotkeys() {
  console.log("Custom Yucata hotkeys added."); // For each key defined in the map (unique action name)

  Object.keys(hotkeysMap).forEach(function (actionId) {
    // Get the data object
    var data = hotkeysMap[actionId];

    if (data) {
      var keyCombos = data.keyCombos,
          method = data.method,
          description = data.description;
      keyCombos.forEach(function (key) {
        var keyMethod = method;
        Object(hotkeys_js__WEBPACK_IMPORTED_MODULE_3__["default"])(key, function () {
          console.log("Action: ".concat(description));
          keyMethod();
        });
      });
    }
  });
}

/***/ }),

/***/ "./src/scripts/dom.js":
/*!****************************!*\
  !*** ./src/scripts/dom.js ***!
  \****************************/
/*! exports provided: getPopupButton, clickBySelector, waitForBoardToExistAndThen */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPopupButton", function() { return getPopupButton; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clickBySelector", function() { return clickBySelector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "waitForBoardToExistAndThen", function() { return waitForBoardToExistAndThen; });
/**
 * Return the dom node of the button in the popup
 * @returns {HTMLElement}
 */
var getPopupButton = function getPopupButton() {
  return document.getElementById("popupButton");
};
/**
 * Click the element in the selector if it is found
 * @param {string} selector
 */

function clickBySelector(selector) {
  var element = document.querySelector(selector);

  if (element) {
    element.click();
  } else {
    console.log("Element ".concat(selector, " not found"));
  }
}
/**
 * Wait for the board DOM element to exist, and then execute the method passed
 * @param {function} method
 */

function waitForBoardToExistAndThen(method) {
  var board = document.getElementById("board");

  if (board) {
    console.log("Board is ready.");
    method();
  } else {
    console.log("No board yet, waiting.");
    setTimeout(waitForBoardToExistAndThen.bind(this, method), 500);
  }
}

/***/ }),

/***/ "./src/scripts/hotkeys/global.js":
/*!***************************************!*\
  !*** ./src/scripts/hotkeys/global.js ***!
  \***************************************/
/*! exports provided: globalHotkeysMap */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "globalHotkeysMap", function() { return globalHotkeysMap; });
/* harmony import */ var _dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../dom */ "./src/scripts/dom.js");

/**
 * Hotkey map for all games
 */

var globalHotkeysMap = {
  "global_ok": {
    keyCombos: ["g"],
    description: "Hit 'OK' when it's your turn",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_0__["clickBySelector"])(".ui-popup-active input[value='OK']");
    }
  },
  "global_undo": {
    keyCombos: ["u"],
    description: "Hit 'Undo' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_0__["clickBySelector"])("#btn_undo");
    }
  },
  "global_pass": {
    keyCombos: ["p"],
    description: "Hit the 'Pass' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_0__["clickBySelector"])("#btn_BtnPassBuy");
    }
  },
  "global_finish": {
    keyCombos: ["f"],
    description: "Hit the 'Finish Turn' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_0__["clickBySelector"])("#btn_finishTurn");
    }
  },
  "global_next_game": {
    keyCombos: ["n"],
    description: "Hit the 'Next Game' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_0__["clickBySelector"])("#btn_nextGame");
    }
  }
};

/***/ }),

/***/ "./src/scripts/hotkeys/machi_koro.js":
/*!*******************************************!*\
  !*** ./src/scripts/hotkeys/machi_koro.js ***!
  \*******************************************/
/*! exports provided: main, machiKoroHotkeysMap, selectCardBySelector, getSelectedCard, selectCardByNumber, getCardNumber, selectCardLeft, selectCardRight, selectCardUp, selectCardDown, buySelectedCard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "main", function() { return main; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "machiKoroHotkeysMap", function() { return machiKoroHotkeysMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardBySelector", function() { return selectCardBySelector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSelectedCard", function() { return getSelectedCard; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardByNumber", function() { return selectCardByNumber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCardNumber", function() { return getCardNumber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardLeft", function() { return selectCardLeft; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardRight", function() { return selectCardRight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardUp", function() { return selectCardUp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectCardDown", function() { return selectCardDown; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "buySelectedCard", function() { return buySelectedCard; });
/* harmony import */ var _scss_machi_koro_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../scss/machi_koro.scss */ "./src/scss/machi_koro.scss");
/* harmony import */ var _scss_machi_koro_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_scss_machi_koro_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../dom */ "./src/scripts/dom.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }



/**
 * Main method to be executed (by content.js)
 */

function main() {
  Object(_dom__WEBPACK_IMPORTED_MODULE_1__["waitForBoardToExistAndThen"])(function () {
    return selectCardBySelector("#card1");
  });
  Object(_dom__WEBPACK_IMPORTED_MODULE_1__["waitForBoardToExistAndThen"])(addCardTooltips);
}
/**
 * Hotkey map for machi koro only
 */

var machiKoroHotkeysMap = {
  "machi_koro_buy_slot_1": {
    keyCombos: ["1"],
    description: "Buy Card in Slot 1 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card1");
    }
  },
  "machi_koro_buy_slot_2": {
    keyCombos: ["2"],
    description: "Buy Card in Slot 2 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card2");
    }
  },
  "machi_koro_buy_slot_3": {
    keyCombos: ["3"],
    description: "Buy Card in Slot 3 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card3");
    }
  },
  "machi_koro_buy_slot_4": {
    keyCombos: ["4"],
    description: "Buy Card in Slot 4 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card4");
    }
  },
  "machi_koro_buy_slot_5": {
    keyCombos: ["5"],
    description: "Buy Card in Slot 5 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card5");
    }
  },
  "machi_koro_buy_slot_6": {
    keyCombos: ["6"],
    description: "Buy Card in Slot 6 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card6");
    }
  },
  "machi_koro_buy_slot_7": {
    keyCombos: ["7"],
    description: "Buy Card in Slot 7 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card7");
    }
  },
  "machi_koro_buy_slot_8": {
    keyCombos: ["8"],
    description: "Buy Card in Slot 8 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card8");
    }
  },
  "machi_koro_buy_slot_9": {
    keyCombos: ["9"],
    description: "Buy Card in Slot 9 (Machi Koro)",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#card9");
    }
  },
  "machi_koro_toggle_dice": {
    keyCombos: ["d"],
    description: "Toggle Dice",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#die2");
    }
  },
  "machi_koro_roll_dice": {
    keyCombos: ["r"],
    description: "Hit 'Roll dice' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#btn_Würfeln");
    }
  },
  "machi_koro_reroll_dice": {
    keyCombos: ["q"],
    description: "Hit 'Reroll dice' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#btn_BtnRollAgain");
    }
  },
  "machi_koro_do_not_reroll_dice": {
    keyCombos: ["w"],
    description: "Hit 'Do Not Reroll' button",
    method: function method() {
      return Object(_dom__WEBPACK_IMPORTED_MODULE_1__["clickBySelector"])("#btn_BtnRollNotAgain");
    }
  },
  "machi_koro_select_card_left": {
    keyCombos: ["left"],
    description: "Select Left Card",
    method: function method() {
      return selectCardLeft();
    }
  },
  "machi_koro_select_card_right": {
    keyCombos: ["right"],
    description: "Select Right Card",
    method: function method() {
      return selectCardRight();
    }
  },
  "machi_koro_select_card_up": {
    keyCombos: ["up"],
    description: "Select Top Card",
    method: function method() {
      return selectCardUp();
    }
  },
  "machi_koro_select_card_down": {
    keyCombos: ["down"],
    description: "Select Bottom Card",
    method: function method() {
      return selectCardDown();
    }
  },
  "machi_koro_buy_selected_card": {
    keyCombos: ["b"],
    description: "Buy Selected Card",
    method: function method() {
      return buySelectedCard();
    }
  }
};
/**
 * Add the "selectedCard" class to the element matched by the selector (if any)
 * @param {string} selector
 */

function selectCardBySelector(selector) {
  var activeElement = getSelectedCard();
  var cardElement = document.querySelector(selector);

  if (cardElement) {
    cardElement.classList.add("selectedCard");

    if (activeElement) {
      activeElement.classList.remove("selectedCard");
    }
  }
}
/**
 * Adds card tooltips on hover (zoomed in cards)
 */

function addCardTooltips() {
  var cards = getCardsDom();
  cards.forEach(function (card) {
    var clone = card.querySelector(".card img").cloneNode();
    clone.classList.add("cardZoomed");
    card.parentElement.insertBefore(clone, card.nextSibling);
  });
}
/**
 *
 * @returns {NodeListOf<Element>}
 */


function getCardsDom() {
  return _toConsumableArray(document.querySelectorAll(".cardContainer"));
}
/**
 * Return the card that is currently selected (has the class selectedCard)
 * @returns {Element}
 */


function getSelectedCard() {
  return document.querySelector(".selectedCard");
}
/**
 * Select a card based on the number provided
 * @param {number} cardNumber
 */

function selectCardByNumber(cardNumber) {
  var nextCardSelector = "#card".concat(cardNumber);
  selectCardBySelector(nextCardSelector);
}
/**
 * Return the card number for the provided element
 * @param {Element} element
 * @returns {number}
 */

function getCardNumber(element) {
  var regex = /\d+$/;

  if (element) {
    var cardNumber = element.id.match(regex)[0];

    try {
      return parseInt(cardNumber);
    } catch (error) {
      console.log("".concat(element.id, " did not have a number at the end of its ID"));
      return null;
    }
  }

  return null;
}
/**
 * Select the card to the left of the active card
 */

function selectCardLeft() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) - 1;
  selectCardByNumber(nextCardNumber);
}
/**
 * Select the card to the right of the active card
 */

function selectCardRight() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) + 1;
  selectCardByNumber(nextCardNumber);
}
/**
 * Select the card to the up of the active card
 */

function selectCardUp() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) - 5;
  selectCardByNumber(nextCardNumber);
}
/**
 * Select the card to the down of the active card
 */

function selectCardDown() {
  var activeElement = getSelectedCard();
  var nextCardNumber = getCardNumber(activeElement) + 5;
  selectCardByNumber(nextCardNumber);
}
/**
 * Buy the card that is currently selected
 */

function buySelectedCard() {
  var activeElement = document.querySelector(".selectedCard");
  console.log("Ok I want to buy " + activeElement.id);

  if (activeElement) {
    if (activeElement.classList.contains("active")) {
      console.log("It's active, sure, I'll buy it");
      activeElement.click();
      console.log("Click");
    } else {
      // An den einai available auth
      // An den einai h seira sou -- auto isws to lynoyme me to na tsekaroume seira apo prin
      console.log("Doesn't seem to be available though.");
      var undoButton = document.querySelector("#btn_undo");

      if (undoButton) {
        // An exeis agorasei hdh
        alert("You've already chosen a card."); // an vgaloume to ble otan den einai h seira sou de xreiazetai auto
        // alla prepei na xanaginetai ble otan einai h seira sou
      } else {
        alert("You can't buy this one :( \nChose an available card.");
      }
    }
  } else {
    console.log("Element ".concat(activeElement.id, " not found"));
  }
}

/***/ }),

/***/ "./src/scss/machi_koro.scss":
/*!**********************************!*\
  !*** ./src/scss/machi_koro.scss ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 1:
/*!***********************************!*\
  !*** multi ./src/scripts/content ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/pano/code/yucatahotkeys/build/src/scripts/content */"./src/scripts/content.js");


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL2hvdGtleXMtanMvZGlzdC9ob3RrZXlzLmVzbS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2NyaXB0cy9jb250ZW50LmpzIiwid2VicGFjazovLy8uL3NyYy9zY3JpcHRzL2RvbS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2NyaXB0cy9ob3RrZXlzL2dsb2JhbC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2NyaXB0cy9ob3RrZXlzL21hY2hpX2tvcm8uanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3Njc3MvbWFjaGlfa29yby5zY3NzIl0sIm5hbWVzIjpbImhvdGtleXNNYXAiLCJtYWNoaUtvcm9Ib3RrZXlzTWFwIiwiZ2xvYmFsSG90a2V5c01hcCIsInNldHVwSG90a2V5cyIsIndhaXRGb3JCb2FyZFRvRXhpc3RBbmRUaGVuIiwiYWRkVG9vbHRpcCIsIm1hY2hpX2tvcm9fbWFpbiIsImJvYXJkIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInRvb2x0aXBUcmlnZ2VyRWxlbWVudCIsIk9iamVjdCIsImFzc2lnbiIsImNyZWF0ZUVsZW1lbnQiLCJjbGFzc05hbWUiLCJ0ZXh0Q29udGVudCIsInRvb2x0aXBUZXh0Iiwia2V5cyIsImZvckVhY2giLCJrZXkiLCJrZXlDb21ib3MiLCJkZXNjcmlwdGlvbiIsInJvdyIsImxhYmVsQ2VsbCIsInRvTG9jYWxlVXBwZXJDYXNlIiwidmFsdWVDZWxsIiwiYXBwZW5kQ2hpbGQiLCJjb25zb2xlIiwibG9nIiwiYWN0aW9uSWQiLCJkYXRhIiwibWV0aG9kIiwia2V5TWV0aG9kIiwiaG90a2V5cyIsImdldFBvcHVwQnV0dG9uIiwiY2xpY2tCeVNlbGVjdG9yIiwic2VsZWN0b3IiLCJlbGVtZW50IiwicXVlcnlTZWxlY3RvciIsImNsaWNrIiwic2V0VGltZW91dCIsImJpbmQiLCJtYWluIiwic2VsZWN0Q2FyZEJ5U2VsZWN0b3IiLCJhZGRDYXJkVG9vbHRpcHMiLCJzZWxlY3RDYXJkTGVmdCIsInNlbGVjdENhcmRSaWdodCIsInNlbGVjdENhcmRVcCIsInNlbGVjdENhcmREb3duIiwiYnV5U2VsZWN0ZWRDYXJkIiwiYWN0aXZlRWxlbWVudCIsImdldFNlbGVjdGVkQ2FyZCIsImNhcmRFbGVtZW50IiwiY2xhc3NMaXN0IiwiYWRkIiwicmVtb3ZlIiwiY2FyZHMiLCJnZXRDYXJkc0RvbSIsImNhcmQiLCJjbG9uZSIsImNsb25lTm9kZSIsInBhcmVudEVsZW1lbnQiLCJpbnNlcnRCZWZvcmUiLCJuZXh0U2libGluZyIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJzZWxlY3RDYXJkQnlOdW1iZXIiLCJjYXJkTnVtYmVyIiwibmV4dENhcmRTZWxlY3RvciIsImdldENhcmROdW1iZXIiLCJyZWdleCIsImlkIiwibWF0Y2giLCJwYXJzZUludCIsImVycm9yIiwibmV4dENhcmROdW1iZXIiLCJjb250YWlucyIsInVuZG9CdXR0b24iLCJhbGVydCJdLCJtYXBwaW5ncyI6IjtRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBOzs7UUFHQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMENBQTBDLGdDQUFnQztRQUMxRTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLHdEQUF3RCxrQkFBa0I7UUFDMUU7UUFDQSxpREFBaUQsY0FBYztRQUMvRDs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EseUNBQXlDLGlDQUFpQztRQUMxRSxnSEFBZ0gsbUJBQW1CLEVBQUU7UUFDckk7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwyQkFBMkIsMEJBQTBCLEVBQUU7UUFDdkQsaUNBQWlDLGVBQWU7UUFDaEQ7UUFDQTtRQUNBOztRQUVBO1FBQ0Esc0RBQXNELCtEQUErRDs7UUFFckg7UUFDQTs7O1FBR0E7UUFDQTs7Ozs7Ozs7Ozs7OztBQ2xGQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNIO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSwrR0FBK0c7O0FBRS9HO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsQ0FBQzs7O0FBR0Q7QUFDQTs7QUFFQSxpQkFBaUIsaUJBQWlCO0FBQ2xDO0FBQ0E7O0FBRUE7QUFDQSxDQUFDOzs7QUFHRDtBQUNBO0FBQ0EsK0JBQStCOztBQUUvQiw0QkFBNEI7O0FBRTVCLG1DQUFtQzs7QUFFbkMsUUFBUSxZQUFZO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsQ0FBQzs7O0FBR0Q7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsaUJBQWlCLGlCQUFpQjtBQUNsQztBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQsbUJBQW1COztBQUVuQixlQUFlLFFBQVE7QUFDdkI7QUFDQTs7QUFFQSxtQkFBbUI7O0FBRW5CLG1CQUFtQjs7QUFFbkIsNkJBQTZCO0FBQzdCOztBQUVBO0FBQ0E7QUFDQSxFQUFFOzs7QUFHRjtBQUNBO0FBQ0EsQ0FBQzs7O0FBR0Q7QUFDQTtBQUNBLENBQUM7OztBQUdEO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7OztBQUdBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQjs7QUFFbEI7QUFDQTtBQUNBOztBQUVBO0FBQ0EsQ0FBQzs7O0FBR0Q7QUFDQTtBQUNBLDRCQUE0QjtBQUM1Qjs7QUFFQTtBQUNBLENBQUM7OztBQUdEO0FBQ0E7QUFDQSxRQUFROztBQUVSOztBQUVBO0FBQ0E7QUFDQTs7QUFFQSxpQkFBaUIscUJBQXFCO0FBQ3RDLCtEQUErRDtBQUMvRDtBQUNBO0FBQ0EsR0FBRzs7O0FBR0g7QUFDQSxDQUFDOzs7QUFHRDtBQUNBOztBQUVBLGlDQUFpQzs7O0FBR2pDO0FBQ0E7QUFDQSxHQUFHOzs7QUFHSDtBQUNBO0FBQ0EsR0FBRzs7O0FBR0g7O0FBRUE7QUFDQSx1QkFBdUI7O0FBRXZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0gsK0JBQStCLDJCQUEyQixHQUFHLDBDQUEwQztBQUN2RztBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSCw0QkFBNEIsbUNBQW1DO0FBQy9EO0FBQ0EsR0FBRztBQUNILDBGQUEwRixhQUFhO0FBQ3ZHO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLENBQUM7OztBQUdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQzs7QUFFcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNILEVBQUU7OztBQUdGO0FBQ0EscUJBQXFCOztBQUVyQjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSzs7O0FBR0w7QUFDQTtBQUNBLHlEQUF5RDtBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7O0FBR0Q7QUFDQTtBQUNBLDJEQUEyRDs7QUFFM0QsZ0RBQWdEO0FBQ2hEOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBOztBQUVBO0FBQ0Esc0JBQXNCOztBQUV0QjtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxHQUFHOzs7QUFHSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7OztBQUdILHlCQUF5Qjs7QUFFekI7QUFDQSxtQkFBbUIscUJBQXFCO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRzs7O0FBR0g7O0FBRUEsa0JBQWtCLDRCQUE0QjtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDOztBQUVsQyx1QkFBdUIsd0JBQXdCO0FBQy9DO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOzs7QUFHRDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLDBCQUEwQjs7QUFFMUI7QUFDQSxvQkFBb0I7O0FBRXBCLHlCQUF5Qjs7QUFFekI7QUFDQTtBQUNBO0FBQ0EscUJBQXFCOztBQUVyQjtBQUNBO0FBQ0E7O0FBRUE7QUFDQSwyQ0FBMkM7O0FBRTNDLGlEQUFpRDs7QUFFakQsMkNBQTJDOztBQUUzQywrREFBK0Q7O0FBRS9ELHdFQUF3RTtBQUN4RTs7QUFFQSxpREFBaUQ7O0FBRWpELFFBQVEsaUJBQWlCO0FBQ3pCLGtDQUFrQzs7QUFFbEMsY0FBYzs7QUFFZCx1REFBdUQ7O0FBRXZEO0FBQ0Esd0NBQXdDO0FBQ3hDOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHOzs7QUFHSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVlLHNFQUFPLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFpQnZCOzs7OztBQUtBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7Ozs7QUFHQSxJQUFNQSxVQUFVLHFCQUNYQyx1RUFEVyxNQUVYQyxnRUFGVyxDQUFoQjs7QUFLQUMsWUFBWTtBQUNaQyx1RUFBMEIsQ0FBQ0MsVUFBRCxDQUExQjtBQUNBQyxnRUFBZTtBQUdmOzs7O0FBR0EsU0FBU0QsVUFBVCxHQUFxQjtBQUNqQixNQUFNRSxLQUFLLEdBQUdDLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixPQUF4QixDQUFkO0FBQ0EsTUFBTUMscUJBQXFCLEdBQUdDLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjSixRQUFRLENBQUNLLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBZCxFQUE2QztBQUN2RUMsYUFBUyxFQUFFLGdIQUQ0RDtBQUV2RUMsZUFBVyxFQUFFO0FBRjBELEdBQTdDLENBQTlCO0FBSUEsTUFBTUMsV0FBVyxHQUFHTCxNQUFNLENBQUNDLE1BQVAsQ0FBY0osUUFBUSxDQUFDSyxhQUFULENBQXVCLEtBQXZCLENBQWQsRUFBNkM7QUFDN0RDLGFBQVMsRUFBRTtBQURrRCxHQUE3QyxDQUFwQjtBQUlBSCxRQUFNLENBQUNNLElBQVAsQ0FBWWpCLFVBQVosRUFBd0JrQixPQUF4QixDQUFnQyxVQUFBQyxHQUFHLEVBQUk7QUFBQSwwQkFDSG5CLFVBQVUsQ0FBQ21CLEdBQUQsQ0FEUDtBQUFBLFFBQzdCQyxTQUQ2QixtQkFDN0JBLFNBRDZCO0FBQUEsUUFDbEJDLFdBRGtCLG1CQUNsQkEsV0FEa0I7QUFFcEMsUUFBTUMsR0FBRyxHQUFHWCxNQUFNLENBQUNDLE1BQVAsQ0FBY0osUUFBUSxDQUFDSyxhQUFULENBQXVCLEtBQXZCLENBQWQsRUFBNkM7QUFDckRDLGVBQVMsRUFBRTtBQUQwQyxLQUE3QyxDQUFaO0FBR0EsUUFBTVMsU0FBUyxHQUFHWixNQUFNLENBQUNDLE1BQVAsQ0FBY0osUUFBUSxDQUFDSyxhQUFULENBQXVCLEtBQXZCLENBQWQsRUFBNkM7QUFDM0RDLGVBQVMsRUFBRSxrQkFEZ0Q7QUFFM0RDLGlCQUFXLEVBQUVLLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYUksaUJBQWIsS0FBbUM7QUFGVyxLQUE3QyxDQUFsQjtBQUlBLFFBQU1DLFNBQVMsR0FBR2QsTUFBTSxDQUFDQyxNQUFQLENBQWNKLFFBQVEsQ0FBQ0ssYUFBVCxDQUF1QixLQUF2QixDQUFkLEVBQTZDO0FBQzNEQyxlQUFTLEVBQUUsa0JBRGdEO0FBRTNEQyxpQkFBVyxFQUFFTTtBQUY4QyxLQUE3QyxDQUFsQjtBQUlBQyxPQUFHLENBQUNJLFdBQUosQ0FBZ0JILFNBQWhCO0FBQ0FELE9BQUcsQ0FBQ0ksV0FBSixDQUFnQkQsU0FBaEI7QUFDQVQsZUFBVyxDQUFDVSxXQUFaLENBQXdCSixHQUF4QjtBQUNGLEdBaEJEO0FBa0JBWix1QkFBcUIsQ0FBQ2dCLFdBQXRCLENBQWtDVixXQUFsQztBQUNBVCxPQUFLLENBQUNtQixXQUFOLENBQWtCaEIscUJBQWxCO0FBQ0FILE9BQUssQ0FBQ21CLFdBQU4sQ0FBa0JWLFdBQWxCO0FBQ0g7QUFHRDs7Ozs7QUFHQSxTQUFTYixZQUFULEdBQXVCO0FBQ25Cd0IsU0FBTyxDQUFDQyxHQUFSLENBQVksOEJBQVosRUFEbUIsQ0FFbkI7O0FBQ0FqQixRQUFNLENBQUNNLElBQVAsQ0FBWWpCLFVBQVosRUFBd0JrQixPQUF4QixDQUFnQyxVQUFBVyxRQUFRLEVBQUk7QUFDeEM7QUFDQSxRQUFNQyxJQUFJLEdBQUc5QixVQUFVLENBQUM2QixRQUFELENBQXZCOztBQUNBLFFBQUdDLElBQUgsRUFBUTtBQUFBLFVBQ0dWLFNBREgsR0FDcUNVLElBRHJDLENBQ0dWLFNBREg7QUFBQSxVQUNjVyxNQURkLEdBQ3FDRCxJQURyQyxDQUNjQyxNQURkO0FBQUEsVUFDc0JWLFdBRHRCLEdBQ3FDUyxJQURyQyxDQUNzQlQsV0FEdEI7QUFFSkQsZUFBUyxDQUFDRixPQUFWLENBQWtCLFVBQUFDLEdBQUcsRUFBSTtBQUNyQixZQUFNYSxTQUFTLEdBQUdELE1BQWxCO0FBQ0FFLGtFQUFPLENBQUNkLEdBQUQsRUFBTSxZQUFVO0FBQ25CUSxpQkFBTyxDQUFDQyxHQUFSLG1CQUF1QlAsV0FBdkI7QUFDSVcsbUJBQVM7QUFDaEIsU0FITSxDQUFQO0FBSUgsT0FORDtBQU9IO0FBQ0osR0FiRDtBQWNILEM7Ozs7Ozs7Ozs7OztBQ2pGRDtBQUFBO0FBQUE7QUFBQTtBQUFBOzs7O0FBSU8sSUFBTUUsY0FBYyxHQUFHLFNBQWpCQSxjQUFpQixHQUFLO0FBQy9CLFNBQU8xQixRQUFRLENBQUNDLGNBQVQsQ0FBd0IsYUFBeEIsQ0FBUDtBQUNILENBRk07QUFJUDs7Ozs7QUFJTyxTQUFTMEIsZUFBVCxDQUF5QkMsUUFBekIsRUFBa0M7QUFDckMsTUFBTUMsT0FBTyxHQUFHN0IsUUFBUSxDQUFDOEIsYUFBVCxDQUF1QkYsUUFBdkIsQ0FBaEI7O0FBQ0EsTUFBR0MsT0FBSCxFQUFXO0FBQ1BBLFdBQU8sQ0FBQ0UsS0FBUjtBQUNILEdBRkQsTUFFTztBQUNIWixXQUFPLENBQUNDLEdBQVIsbUJBQXVCUSxRQUF2QjtBQUNIO0FBQ0o7QUFFRDs7Ozs7QUFJTyxTQUFTaEMsMEJBQVQsQ0FBb0MyQixNQUFwQyxFQUEyQztBQUM5QyxNQUFNeEIsS0FBSyxHQUFHQyxRQUFRLENBQUNDLGNBQVQsQ0FBd0IsT0FBeEIsQ0FBZDs7QUFDQSxNQUFHRixLQUFILEVBQVM7QUFDTG9CLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLGlCQUFaO0FBQ0FHLFVBQU07QUFDVCxHQUhELE1BR087QUFDSEosV0FBTyxDQUFDQyxHQUFSLENBQVksd0JBQVo7QUFDQVksY0FBVSxDQUFDcEMsMEJBQTBCLENBQUNxQyxJQUEzQixDQUFnQyxJQUFoQyxFQUFzQ1YsTUFBdEMsQ0FBRCxFQUFnRCxHQUFoRCxDQUFWO0FBQ0g7QUFDSixDOzs7Ozs7Ozs7Ozs7QUNsQ0Q7QUFBQTtBQUFBO0FBQUE7QUFFQTs7OztBQUdPLElBQU03QixnQkFBZ0IsR0FBRztBQUM1QixlQUFhO0FBQ1RrQixhQUFTLEVBQUUsQ0FBQyxHQUFELENBREY7QUFFVEMsZUFBVyxFQUFFLDhCQUZKO0FBR1RVLFVBQU0sRUFBRTtBQUFBLGFBQU1JLDREQUFlLENBQUMsb0NBQUQsQ0FBckI7QUFBQTtBQUhDLEdBRGU7QUFNNUIsaUJBQWU7QUFDWGYsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURBO0FBRVhDLGVBQVcsRUFBRSxtQkFGRjtBQUdYVSxVQUFNLEVBQUU7QUFBQSxhQUFNSSw0REFBZSxDQUFDLFdBQUQsQ0FBckI7QUFBQTtBQUhHLEdBTmE7QUFXNUIsaUJBQWU7QUFDWGYsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURBO0FBRVhDLGVBQVcsRUFBRSx1QkFGRjtBQUdYVSxVQUFNLEVBQUU7QUFBQSxhQUFNSSw0REFBZSxDQUFDLGlCQUFELENBQXJCO0FBQUE7QUFIRyxHQVhhO0FBZ0I1QixtQkFBaUI7QUFDYmYsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURFO0FBRWJDLGVBQVcsRUFBRSw4QkFGQTtBQUdiVSxVQUFNLEVBQUU7QUFBQSxhQUFNSSw0REFBZSxDQUFDLGlCQUFELENBQXJCO0FBQUE7QUFISyxHQWhCVztBQXFCNUIsc0JBQW9CO0FBQ2hCZixhQUFTLEVBQUUsQ0FBQyxHQUFELENBREs7QUFFaEJDLGVBQVcsRUFBRSw0QkFGRztBQUdoQlUsVUFBTSxFQUFFO0FBQUEsYUFBTUksNERBQWUsQ0FBQyxlQUFELENBQXJCO0FBQUE7QUFIUTtBQXJCUSxDQUF6QixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0xQO0FBQ0E7QUFFQTs7OztBQUdPLFNBQVNPLElBQVQsR0FBZTtBQUNsQnRDLHlFQUEwQixDQUFDO0FBQUEsV0FBS3VDLG9CQUFvQixDQUFDLFFBQUQsQ0FBekI7QUFBQSxHQUFELENBQTFCO0FBQ0F2Qyx5RUFBMEIsQ0FBQ3dDLGVBQUQsQ0FBMUI7QUFDSDtBQUVEOzs7O0FBR08sSUFBTTNDLG1CQUFtQixHQUFHO0FBQy9CLDJCQUF5QjtBQUNyQm1CLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FEVTtBQUVyQkMsZUFBVyxFQUFFLGlDQUZRO0FBR3JCVSxVQUFNLEVBQUU7QUFBQSxhQUFNSSw0REFBZSxDQUFDLFFBQUQsQ0FBckI7QUFBQTtBQUhhLEdBRE07QUFNL0IsMkJBQXlCO0FBQ3JCZixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlUsVUFBTSxFQUFFO0FBQUEsYUFBTUksNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQU5NO0FBVy9CLDJCQUF5QjtBQUNyQmYsYUFBUyxFQUFFLENBQUMsR0FBRCxDQURVO0FBRXJCQyxlQUFXLEVBQUUsaUNBRlE7QUFHckJVLFVBQU0sRUFBRTtBQUFBLGFBQU1JLDREQUFlLENBQUMsUUFBRCxDQUFyQjtBQUFBO0FBSGEsR0FYTTtBQWdCL0IsMkJBQXlCO0FBQ3JCZixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlUsVUFBTSxFQUFFO0FBQUEsYUFBTUksNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQWhCTTtBQXFCL0IsMkJBQXlCO0FBQ3JCZixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlUsVUFBTSxFQUFFO0FBQUEsYUFBTUksNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQXJCTTtBQTBCL0IsMkJBQXlCO0FBQ3JCZixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlUsVUFBTSxFQUFFO0FBQUEsYUFBTUksNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQTFCTTtBQStCL0IsMkJBQXlCO0FBQ3JCZixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlUsVUFBTSxFQUFFO0FBQUEsYUFBTUksNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQS9CTTtBQW9DL0IsMkJBQXlCO0FBQ3JCZixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlUsVUFBTSxFQUFFO0FBQUEsYUFBTUksNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQXBDTTtBQXlDL0IsMkJBQXlCO0FBQ3JCZixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFU7QUFFckJDLGVBQVcsRUFBRSxpQ0FGUTtBQUdyQlUsVUFBTSxFQUFFO0FBQUEsYUFBTUksNERBQWUsQ0FBQyxRQUFELENBQXJCO0FBQUE7QUFIYSxHQXpDTTtBQThDL0IsNEJBQTBCO0FBQ3RCZixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRFc7QUFFdEJDLGVBQVcsRUFBRSxhQUZTO0FBR3RCVSxVQUFNLEVBQUU7QUFBQSxhQUFNSSw0REFBZSxDQUFDLE9BQUQsQ0FBckI7QUFBQTtBQUhjLEdBOUNLO0FBbUQvQiwwQkFBd0I7QUFDcEJmLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FEUztBQUVwQkMsZUFBVyxFQUFFLHdCQUZPO0FBR3BCVSxVQUFNLEVBQUU7QUFBQSxhQUFNSSw0REFBZSxDQUFDLGNBQUQsQ0FBckI7QUFBQTtBQUhZLEdBbkRPO0FBd0QvQiw0QkFBMEI7QUFDdEJmLGFBQVMsRUFBRSxDQUFDLEdBQUQsQ0FEVztBQUV0QkMsZUFBVyxFQUFFLDBCQUZTO0FBR3RCVSxVQUFNLEVBQUU7QUFBQSxhQUFNSSw0REFBZSxDQUFDLG1CQUFELENBQXJCO0FBQUE7QUFIYyxHQXhESztBQTZEL0IsbUNBQWlDO0FBQzdCZixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRGtCO0FBRTdCQyxlQUFXLEVBQUUsNEJBRmdCO0FBRzdCVSxVQUFNLEVBQUU7QUFBQSxhQUFNSSw0REFBZSxDQUFDLHNCQUFELENBQXJCO0FBQUE7QUFIcUIsR0E3REY7QUFrRS9CLGlDQUErQjtBQUMzQmYsYUFBUyxFQUFFLENBQUMsTUFBRCxDQURnQjtBQUUzQkMsZUFBVyxFQUFFLGtCQUZjO0FBRzNCVSxVQUFNLEVBQUU7QUFBQSxhQUFNYyxjQUFjLEVBQXBCO0FBQUE7QUFIbUIsR0FsRUE7QUF1RS9CLGtDQUFnQztBQUM1QnpCLGFBQVMsRUFBRSxDQUFDLE9BQUQsQ0FEaUI7QUFFNUJDLGVBQVcsRUFBRSxtQkFGZTtBQUc1QlUsVUFBTSxFQUFFO0FBQUEsYUFBTWUsZUFBZSxFQUFyQjtBQUFBO0FBSG9CLEdBdkVEO0FBNEUvQiwrQkFBNkI7QUFDekIxQixhQUFTLEVBQUUsQ0FBQyxJQUFELENBRGM7QUFFekJDLGVBQVcsRUFBRSxpQkFGWTtBQUd6QlUsVUFBTSxFQUFFO0FBQUEsYUFBTWdCLFlBQVksRUFBbEI7QUFBQTtBQUhpQixHQTVFRTtBQWlGL0IsaUNBQStCO0FBQzNCM0IsYUFBUyxFQUFFLENBQUMsTUFBRCxDQURnQjtBQUUzQkMsZUFBVyxFQUFFLG9CQUZjO0FBRzNCVSxVQUFNLEVBQUU7QUFBQSxhQUFNaUIsY0FBYyxFQUFwQjtBQUFBO0FBSG1CLEdBakZBO0FBc0YvQixrQ0FBZ0M7QUFDNUI1QixhQUFTLEVBQUUsQ0FBQyxHQUFELENBRGlCO0FBRTVCQyxlQUFXLEVBQUUsbUJBRmU7QUFHNUJVLFVBQU0sRUFBRTtBQUFBLGFBQU1rQixlQUFlLEVBQXJCO0FBQUE7QUFIb0I7QUF0RkQsQ0FBNUI7QUE2RlA7Ozs7O0FBSU8sU0FBU04sb0JBQVQsQ0FBOEJQLFFBQTlCLEVBQXVDO0FBQzFDLE1BQU1jLGFBQWEsR0FBR0MsZUFBZSxFQUFyQztBQUNBLE1BQU1DLFdBQVcsR0FBRzVDLFFBQVEsQ0FBQzhCLGFBQVQsQ0FBdUJGLFFBQXZCLENBQXBCOztBQUNBLE1BQUdnQixXQUFILEVBQWU7QUFDWEEsZUFBVyxDQUFDQyxTQUFaLENBQXNCQyxHQUF0QixDQUEwQixjQUExQjs7QUFDQSxRQUFHSixhQUFILEVBQWlCO0FBQ2JBLG1CQUFhLENBQUNHLFNBQWQsQ0FBd0JFLE1BQXhCLENBQWdDLGNBQWhDO0FBQ0g7QUFDSjtBQUNKO0FBRUQ7Ozs7QUFHQSxTQUFTWCxlQUFULEdBQTJCO0FBQ3ZCLE1BQU1ZLEtBQUssR0FBR0MsV0FBVyxFQUF6QjtBQUNBRCxPQUFLLENBQUN0QyxPQUFOLENBQWMsVUFBQXdDLElBQUksRUFBSTtBQUNsQixRQUFNQyxLQUFLLEdBQUdELElBQUksQ0FBQ3BCLGFBQUwsQ0FBbUIsV0FBbkIsRUFBZ0NzQixTQUFoQyxFQUFkO0FBQ0FELFNBQUssQ0FBQ04sU0FBTixDQUFnQkMsR0FBaEIsQ0FBb0IsWUFBcEI7QUFDQUksUUFBSSxDQUFDRyxhQUFMLENBQW1CQyxZQUFuQixDQUFnQ0gsS0FBaEMsRUFBdUNELElBQUksQ0FBQ0ssV0FBNUM7QUFDSCxHQUpEO0FBS0g7QUFFRDs7Ozs7O0FBSUEsU0FBU04sV0FBVCxHQUF1QjtBQUNuQiw0QkFBV2pELFFBQVEsQ0FBQ3dELGdCQUFULENBQTBCLGdCQUExQixDQUFYO0FBQ0g7QUFFRDs7Ozs7O0FBSU8sU0FBU2IsZUFBVCxHQUEwQjtBQUM3QixTQUFPM0MsUUFBUSxDQUFDOEIsYUFBVCxDQUF3QixlQUF4QixDQUFQO0FBQ0g7QUFFRDs7Ozs7QUFJTyxTQUFTMkIsa0JBQVQsQ0FBNEJDLFVBQTVCLEVBQXVDO0FBQzFDLE1BQU1DLGdCQUFnQixrQkFBV0QsVUFBWCxDQUF0QjtBQUNBdkIsc0JBQW9CLENBQUN3QixnQkFBRCxDQUFwQjtBQUNIO0FBRUQ7Ozs7OztBQUtPLFNBQVNDLGFBQVQsQ0FBdUIvQixPQUF2QixFQUErQjtBQUNsQyxNQUFNZ0MsS0FBSyxHQUFHLE1BQWQ7O0FBQ0EsTUFBR2hDLE9BQUgsRUFBVztBQUNQLFFBQU02QixVQUFVLEdBQUc3QixPQUFPLENBQUNpQyxFQUFSLENBQVdDLEtBQVgsQ0FBaUJGLEtBQWpCLEVBQXdCLENBQXhCLENBQW5COztBQUNBLFFBQUc7QUFDQyxhQUFPRyxRQUFRLENBQUNOLFVBQUQsQ0FBZjtBQUNILEtBRkQsQ0FFRSxPQUFNTyxLQUFOLEVBQVk7QUFDVjlDLGFBQU8sQ0FBQ0MsR0FBUixXQUFlUyxPQUFPLENBQUNpQyxFQUF2QjtBQUNBLGFBQU8sSUFBUDtBQUNIO0FBQ0o7O0FBQ0QsU0FBTyxJQUFQO0FBQ0g7QUFFRDs7OztBQUdPLFNBQVN6QixjQUFULEdBQXlCO0FBQzVCLE1BQU1LLGFBQWEsR0FBR0MsZUFBZSxFQUFyQztBQUNBLE1BQU11QixjQUFjLEdBQUdOLGFBQWEsQ0FBQ2xCLGFBQUQsQ0FBYixHQUErQixDQUF0RDtBQUVBZSxvQkFBa0IsQ0FBQ1MsY0FBRCxDQUFsQjtBQUNIO0FBRUQ7Ozs7QUFHTyxTQUFTNUIsZUFBVCxHQUEwQjtBQUM3QixNQUFNSSxhQUFhLEdBQUdDLGVBQWUsRUFBckM7QUFDQSxNQUFNdUIsY0FBYyxHQUFHTixhQUFhLENBQUNsQixhQUFELENBQWIsR0FBK0IsQ0FBdEQ7QUFFQWUsb0JBQWtCLENBQUNTLGNBQUQsQ0FBbEI7QUFDSDtBQUVEOzs7O0FBR08sU0FBUzNCLFlBQVQsR0FBdUI7QUFDMUIsTUFBTUcsYUFBYSxHQUFHQyxlQUFlLEVBQXJDO0FBQ0EsTUFBTXVCLGNBQWMsR0FBR04sYUFBYSxDQUFDbEIsYUFBRCxDQUFiLEdBQStCLENBQXREO0FBRUFlLG9CQUFrQixDQUFDUyxjQUFELENBQWxCO0FBQ0g7QUFFRDs7OztBQUdPLFNBQVMxQixjQUFULEdBQXlCO0FBQzVCLE1BQU1FLGFBQWEsR0FBR0MsZUFBZSxFQUFyQztBQUNBLE1BQU11QixjQUFjLEdBQUdOLGFBQWEsQ0FBQ2xCLGFBQUQsQ0FBYixHQUErQixDQUF0RDtBQUVBZSxvQkFBa0IsQ0FBQ1MsY0FBRCxDQUFsQjtBQUNIO0FBRUQ7Ozs7QUFHTyxTQUFTekIsZUFBVCxHQUEwQjtBQUM3QixNQUFNQyxhQUFhLEdBQUcxQyxRQUFRLENBQUM4QixhQUFULENBQXdCLGVBQXhCLENBQXRCO0FBQ0FYLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFzQnNCLGFBQWEsQ0FBQ29CLEVBQWhEOztBQUNBLE1BQUdwQixhQUFILEVBQWlCO0FBQ2IsUUFBSUEsYUFBYSxDQUFDRyxTQUFkLENBQXdCc0IsUUFBeEIsQ0FBaUMsUUFBakMsQ0FBSixFQUNBO0FBQ0loRCxhQUFPLENBQUNDLEdBQVIsQ0FBWSxnQ0FBWjtBQUNBc0IsbUJBQWEsQ0FBQ1gsS0FBZDtBQUNBWixhQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0gsS0FMRCxNQU1JO0FBQ0E7QUFDQTtBQUNBRCxhQUFPLENBQUNDLEdBQVIsQ0FBWSxzQ0FBWjtBQUNBLFVBQU1nRCxVQUFVLEdBQUdwRSxRQUFRLENBQUM4QixhQUFULENBQXVCLFdBQXZCLENBQW5COztBQUNBLFVBQUlzQyxVQUFKLEVBQWU7QUFDWDtBQUNBQyxhQUFLLENBQUMsK0JBQUQsQ0FBTCxDQUZXLENBR1g7QUFDQTtBQUNILE9BTEQsTUFNSTtBQUNBQSxhQUFLLENBQUMsc0RBQUQsQ0FBTDtBQUNIO0FBQ0o7QUFDSixHQXRCRCxNQXNCTztBQUNIbEQsV0FBTyxDQUFDQyxHQUFSLG1CQUF1QnNCLGFBQWEsQ0FBQ29CLEVBQXJDO0FBQ0g7QUFDSixDOzs7Ozs7Ozs7OztBQ3pQRCx1QyIsImZpbGUiOiJzY3JpcHRzL2NvbnRlbnQuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIi9cIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IDEpO1xuIiwiLyohXG4gKiBob3RrZXlzLWpzIHYzLjcuMVxuICogQSBzaW1wbGUgbWljcm8tbGlicmFyeSBmb3IgZGVmaW5pbmcgYW5kIGRpc3BhdGNoaW5nIGtleWJvYXJkIHNob3J0Y3V0cy4gSXQgaGFzIG5vIGRlcGVuZGVuY2llcy5cbiAqIFxuICogQ29weXJpZ2h0IChjKSAyMDE5IGtlbm55IHdvbmcgPHdvd29ob29AcXEuY29tPlxuICogaHR0cDovL2pheXdjamxvdmUuZ2l0aHViLmlvL2hvdGtleXNcbiAqIFxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlLlxuICovXG5cbmZ1bmN0aW9uIF90eXBlb2Yob2JqKSB7XG4gIGlmICh0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgdHlwZW9mIFN5bWJvbC5pdGVyYXRvciA9PT0gXCJzeW1ib2xcIikge1xuICAgIF90eXBlb2YgPSBmdW5jdGlvbiAob2JqKSB7XG4gICAgICByZXR1cm4gdHlwZW9mIG9iajtcbiAgICB9O1xuICB9IGVsc2Uge1xuICAgIF90eXBlb2YgPSBmdW5jdGlvbiAob2JqKSB7XG4gICAgICByZXR1cm4gb2JqICYmIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBvYmouY29uc3RydWN0b3IgPT09IFN5bWJvbCAmJiBvYmogIT09IFN5bWJvbC5wcm90b3R5cGUgPyBcInN5bWJvbFwiIDogdHlwZW9mIG9iajtcbiAgICB9O1xuICB9XG5cbiAgcmV0dXJuIF90eXBlb2Yob2JqKTtcbn1cblxuZnVuY3Rpb24gX2RlZmluZVByb3BlcnR5KG9iaiwga2V5LCB2YWx1ZSkge1xuICBpZiAoa2V5IGluIG9iaikge1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmosIGtleSwge1xuICAgICAgdmFsdWU6IHZhbHVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlXG4gICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgb2JqW2tleV0gPSB2YWx1ZTtcbiAgfVxuXG4gIHJldHVybiBvYmo7XG59XG5cbnZhciBpc2ZmID0gdHlwZW9mIG5hdmlnYXRvciAhPT0gJ3VuZGVmaW5lZCcgPyBuYXZpZ2F0b3IudXNlckFnZW50LnRvTG93ZXJDYXNlKCkuaW5kZXhPZignZmlyZWZveCcpID4gMCA6IGZhbHNlOyAvLyDnu5Hlrprkuovku7ZcblxuZnVuY3Rpb24gYWRkRXZlbnQob2JqZWN0LCBldmVudCwgbWV0aG9kKSB7XG4gIGlmIChvYmplY3QuYWRkRXZlbnRMaXN0ZW5lcikge1xuICAgIG9iamVjdC5hZGRFdmVudExpc3RlbmVyKGV2ZW50LCBtZXRob2QsIGZhbHNlKTtcbiAgfSBlbHNlIGlmIChvYmplY3QuYXR0YWNoRXZlbnQpIHtcbiAgICBvYmplY3QuYXR0YWNoRXZlbnQoXCJvblwiLmNvbmNhdChldmVudCksIGZ1bmN0aW9uICgpIHtcbiAgICAgIG1ldGhvZCh3aW5kb3cuZXZlbnQpO1xuICAgIH0pO1xuICB9XG59IC8vIOS/rumlsOmUrui9rOaNouaIkOWvueW6lOeahOmUrueggVxuXG5cbmZ1bmN0aW9uIGdldE1vZHMobW9kaWZpZXIsIGtleSkge1xuICB2YXIgbW9kcyA9IGtleS5zbGljZSgwLCBrZXkubGVuZ3RoIC0gMSk7XG5cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBtb2RzLmxlbmd0aDsgaSsrKSB7XG4gICAgbW9kc1tpXSA9IG1vZGlmaWVyW21vZHNbaV0udG9Mb3dlckNhc2UoKV07XG4gIH1cblxuICByZXR1cm4gbW9kcztcbn0gLy8g5aSE55CG5Lyg55qEa2V55a2X56ym5Liy6L2s5o2i5oiQ5pWw57uEXG5cblxuZnVuY3Rpb24gZ2V0S2V5cyhrZXkpIHtcbiAgaWYgKHR5cGVvZiBrZXkgIT09ICdzdHJpbmcnKSBrZXkgPSAnJztcbiAga2V5ID0ga2V5LnJlcGxhY2UoL1xccy9nLCAnJyk7IC8vIOWMuemFjeS7u+S9leepuueZveWtl+espizljIXmi6znqbrmoLzjgIHliLbooajnrKbjgIHmjaLpobXnrKbnrYnnrYlcblxuICB2YXIga2V5cyA9IGtleS5zcGxpdCgnLCcpOyAvLyDlkIzml7borr7nva7lpJrkuKrlv6vmjbfplK7vvIzku6UnLCfliIblibJcblxuICB2YXIgaW5kZXggPSBrZXlzLmxhc3RJbmRleE9mKCcnKTsgLy8g5b+r5o236ZSu5Y+v6IO95YyF5ZCrJywn77yM6ZyA54m55q6K5aSE55CGXG5cbiAgZm9yICg7IGluZGV4ID49IDA7KSB7XG4gICAga2V5c1tpbmRleCAtIDFdICs9ICcsJztcbiAgICBrZXlzLnNwbGljZShpbmRleCwgMSk7XG4gICAgaW5kZXggPSBrZXlzLmxhc3RJbmRleE9mKCcnKTtcbiAgfVxuXG4gIHJldHVybiBrZXlzO1xufSAvLyDmr5TovoPkv67ppbDplK7nmoTmlbDnu4RcblxuXG5mdW5jdGlvbiBjb21wYXJlQXJyYXkoYTEsIGEyKSB7XG4gIHZhciBhcnIxID0gYTEubGVuZ3RoID49IGEyLmxlbmd0aCA/IGExIDogYTI7XG4gIHZhciBhcnIyID0gYTEubGVuZ3RoID49IGEyLmxlbmd0aCA/IGEyIDogYTE7XG4gIHZhciBpc0luZGV4ID0gdHJ1ZTtcblxuICBmb3IgKHZhciBpID0gMDsgaSA8IGFycjEubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAoYXJyMi5pbmRleE9mKGFycjFbaV0pID09PSAtMSkgaXNJbmRleCA9IGZhbHNlO1xuICB9XG5cbiAgcmV0dXJuIGlzSW5kZXg7XG59XG5cbnZhciBfbW9kaWZpZXJNYXA7XG52YXIgX2tleU1hcCA9IHtcbiAgLy8g54m55q6K6ZSuXG4gIGJhY2tzcGFjZTogOCxcbiAgdGFiOiA5LFxuICBjbGVhcjogMTIsXG4gIGVudGVyOiAxMyxcbiAgXCJyZXR1cm5cIjogMTMsXG4gIGVzYzogMjcsXG4gIGVzY2FwZTogMjcsXG4gIHNwYWNlOiAzMixcbiAgbGVmdDogMzcsXG4gIHVwOiAzOCxcbiAgcmlnaHQ6IDM5LFxuICBkb3duOiA0MCxcbiAgZGVsOiA0NixcbiAgXCJkZWxldGVcIjogNDYsXG4gIGluczogNDUsXG4gIGluc2VydDogNDUsXG4gIGhvbWU6IDM2LFxuICBlbmQ6IDM1LFxuICBwYWdldXA6IDMzLFxuICBwYWdlZG93bjogMzQsXG4gIGNhcHNsb2NrOiAyMCxcbiAgJ+KHqic6IDIwLFxuICAnLCc6IDE4OCxcbiAgJy4nOiAxOTAsXG4gICcvJzogMTkxLFxuICAnYCc6IDE5MixcbiAgJy0nOiBpc2ZmID8gMTczIDogMTg5LFxuICAnPSc6IGlzZmYgPyA2MSA6IDE4NyxcbiAgJzsnOiBpc2ZmID8gNTkgOiAxODYsXG4gICdcXCcnOiAyMjIsXG4gICdbJzogMjE5LFxuICAnXSc6IDIyMSxcbiAgJ1xcXFwnOiAyMjBcbn07XG52YXIgX21vZGlmaWVyID0ge1xuICAvLyDkv67ppbDplK5cbiAgLy8gc2hpZnRLZXlcbiAgJ+KHpyc6IDE2LFxuICBzaGlmdDogMTYsXG4gIC8vIGFsdEtleVxuICAn4oylJzogMTgsXG4gIGFsdDogMTgsXG4gIG9wdGlvbjogMTgsXG4gIC8vIGN0cmxLZXlcbiAgJ+KMgyc6IDE3LFxuICBjdHJsOiAxNyxcbiAgY29udHJvbDogMTcsXG4gIC8vIG1ldGFLZXlcbiAgJ+KMmCc6IGlzZmYgPyAyMjQgOiA5MSxcbiAgY21kOiBpc2ZmID8gMjI0IDogOTEsXG4gIGNvbW1hbmQ6IGlzZmYgPyAyMjQgOiA5MVxufTtcbnZhciBtb2RpZmllck1hcCA9IChfbW9kaWZpZXJNYXAgPSB7XG4gIDE2OiAnc2hpZnRLZXknLFxuICAxODogJ2FsdEtleScsXG4gIDE3OiAnY3RybEtleSdcbn0sIF9kZWZpbmVQcm9wZXJ0eShfbW9kaWZpZXJNYXAsIGlzZmYgPyAyMjQgOiA5MSwgJ21ldGFLZXknKSwgX2RlZmluZVByb3BlcnR5KF9tb2RpZmllck1hcCwgXCJzaGlmdEtleVwiLCAxNiksIF9kZWZpbmVQcm9wZXJ0eShfbW9kaWZpZXJNYXAsIFwiY3RybEtleVwiLCAxNyksIF9kZWZpbmVQcm9wZXJ0eShfbW9kaWZpZXJNYXAsIFwiYWx0S2V5XCIsIDE4KSwgX2RlZmluZVByb3BlcnR5KF9tb2RpZmllck1hcCwgXCJtZXRhS2V5XCIsIDkxKSwgX21vZGlmaWVyTWFwKTtcblxudmFyIF9tb2RzID0gX2RlZmluZVByb3BlcnR5KHtcbiAgMTY6IGZhbHNlLFxuICAxODogZmFsc2UsXG4gIDE3OiBmYWxzZVxufSwgaXNmZiA/IDIyNCA6IDkxLCBmYWxzZSk7XG5cbnZhciBfaGFuZGxlcnMgPSB7fTsgLy8gRjF+RjEyIOeJueauiumUrlxuXG5mb3IgKHZhciBrID0gMTsgayA8IDIwOyBrKyspIHtcbiAgX2tleU1hcFtcImZcIi5jb25jYXQoayldID0gMTExICsgaztcbn1cblxudmFyIF9kb3duS2V5cyA9IFtdOyAvLyDorrDlvZXmkYHkuIvnmoTnu5HlrprplK5cblxudmFyIF9zY29wZSA9ICdhbGwnOyAvLyDpu5jorqTng63plK7ojIPlm7RcblxudmFyIGVsZW1lbnRIYXNCaW5kRXZlbnQgPSBbXTsgLy8g5bey57uR5a6a5LqL5Lu255qE6IqC54K56K6w5b2VXG4vLyDov5Tlm57plK7noIFcblxudmFyIGNvZGUgPSBmdW5jdGlvbiBjb2RlKHgpIHtcbiAgcmV0dXJuIF9rZXlNYXBbeC50b0xvd2VyQ2FzZSgpXSB8fCBfbW9kaWZpZXJbeC50b0xvd2VyQ2FzZSgpXSB8fCB4LnRvVXBwZXJDYXNlKCkuY2hhckNvZGVBdCgwKTtcbn07IC8vIOiuvue9ruiOt+WPluW9k+WJjeiMg+WbtO+8iOm7mOiupOS4uifmiYDmnIkn77yJXG5cblxuZnVuY3Rpb24gc2V0U2NvcGUoc2NvcGUpIHtcbiAgX3Njb3BlID0gc2NvcGUgfHwgJ2FsbCc7XG59IC8vIOiOt+WPluW9k+WJjeiMg+WbtFxuXG5cbmZ1bmN0aW9uIGdldFNjb3BlKCkge1xuICByZXR1cm4gX3Njb3BlIHx8ICdhbGwnO1xufSAvLyDojrflj5bmkYHkuIvnu5HlrprplK7nmoTplK7lgLxcblxuXG5mdW5jdGlvbiBnZXRQcmVzc2VkS2V5Q29kZXMoKSB7XG4gIHJldHVybiBfZG93bktleXMuc2xpY2UoMCk7XG59IC8vIOihqOWNleaOp+S7tuaOp+S7tuWIpOaWrSDov5Tlm54gQm9vbGVhblxuLy8gaG90a2V5IGlzIGVmZmVjdGl2ZSBvbmx5IHdoZW4gZmlsdGVyIHJldHVybiB0cnVlXG5cblxuZnVuY3Rpb24gZmlsdGVyKGV2ZW50KSB7XG4gIHZhciB0YXJnZXQgPSBldmVudC50YXJnZXQgfHwgZXZlbnQuc3JjRWxlbWVudDtcbiAgdmFyIHRhZ05hbWUgPSB0YXJnZXQudGFnTmFtZTtcbiAgdmFyIGZsYWcgPSB0cnVlOyAvLyBpZ25vcmU6IGlzQ29udGVudEVkaXRhYmxlID09PSAndHJ1ZScsIDxpbnB1dD4gYW5kIDx0ZXh0YXJlYT4gd2hlbiByZWFkT25seSBzdGF0ZSBpcyBmYWxzZSwgPHNlbGVjdD5cblxuICBpZiAodGFyZ2V0LmlzQ29udGVudEVkaXRhYmxlIHx8IHRhZ05hbWUgPT09ICdURVhUQVJFQScgfHwgKHRhZ05hbWUgPT09ICdJTlBVVCcgfHwgdGFnTmFtZSA9PT0gJ1RFWFRBUkVBJykgJiYgIXRhcmdldC5yZWFkT25seSkge1xuICAgIGZsYWcgPSBmYWxzZTtcbiAgfVxuXG4gIHJldHVybiBmbGFnO1xufSAvLyDliKTmlq3mkYHkuIvnmoTplK7mmK/lkKbkuLrmn5DkuKrplK7vvIzov5Tlm550cnVl5oiW6ICFZmFsc2VcblxuXG5mdW5jdGlvbiBpc1ByZXNzZWQoa2V5Q29kZSkge1xuICBpZiAodHlwZW9mIGtleUNvZGUgPT09ICdzdHJpbmcnKSB7XG4gICAga2V5Q29kZSA9IGNvZGUoa2V5Q29kZSk7IC8vIOi9rOaNouaIkOmUrueggVxuICB9XG5cbiAgcmV0dXJuIF9kb3duS2V5cy5pbmRleE9mKGtleUNvZGUpICE9PSAtMTtcbn0gLy8g5b6q546v5Yig6ZmkaGFuZGxlcnPkuK3nmoTmiYDmnIkgc2NvcGUo6IyD5Zu0KVxuXG5cbmZ1bmN0aW9uIGRlbGV0ZVNjb3BlKHNjb3BlLCBuZXdTY29wZSkge1xuICB2YXIgaGFuZGxlcnM7XG4gIHZhciBpOyAvLyDmsqHmnInmjIflrppzY29wZe+8jOiOt+WPlnNjb3BlXG5cbiAgaWYgKCFzY29wZSkgc2NvcGUgPSBnZXRTY29wZSgpO1xuXG4gIGZvciAodmFyIGtleSBpbiBfaGFuZGxlcnMpIHtcbiAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKF9oYW5kbGVycywga2V5KSkge1xuICAgICAgaGFuZGxlcnMgPSBfaGFuZGxlcnNba2V5XTtcblxuICAgICAgZm9yIChpID0gMDsgaSA8IGhhbmRsZXJzLmxlbmd0aDspIHtcbiAgICAgICAgaWYgKGhhbmRsZXJzW2ldLnNjb3BlID09PSBzY29wZSkgaGFuZGxlcnMuc3BsaWNlKGksIDEpO2Vsc2UgaSsrO1xuICAgICAgfVxuICAgIH1cbiAgfSAvLyDlpoLmnpxzY29wZeiiq+WIoOmZpO+8jOWwhnNjb3Bl6YeN572u5Li6YWxsXG5cblxuICBpZiAoZ2V0U2NvcGUoKSA9PT0gc2NvcGUpIHNldFNjb3BlKG5ld1Njb3BlIHx8ICdhbGwnKTtcbn0gLy8g5riF6Zmk5L+u6aWw6ZSuXG5cblxuZnVuY3Rpb24gY2xlYXJNb2RpZmllcihldmVudCkge1xuICB2YXIga2V5ID0gZXZlbnQua2V5Q29kZSB8fCBldmVudC53aGljaCB8fCBldmVudC5jaGFyQ29kZTtcblxuICB2YXIgaSA9IF9kb3duS2V5cy5pbmRleE9mKGtleSk7IC8vIOS7juWIl+ihqOS4rea4hemZpOaMieWOi+i/h+eahOmUrlxuXG5cbiAgaWYgKGkgPj0gMCkge1xuICAgIF9kb3duS2V5cy5zcGxpY2UoaSwgMSk7XG4gIH0gLy8g54m55q6K5aSE55CGIGNtbWFuZCDplK7vvIzlnKggY21tYW5kIOe7hOWQiOW/q+aNt+mUriBrZXl1cCDlj6rmiafooYzkuIDmrKHnmoTpl67pophcblxuXG4gIGlmIChldmVudC5rZXkgJiYgZXZlbnQua2V5LnRvTG93ZXJDYXNlKCkgPT09ICdtZXRhJykge1xuICAgIF9kb3duS2V5cy5zcGxpY2UoMCwgX2Rvd25LZXlzLmxlbmd0aCk7XG4gIH0gLy8g5L+u6aWw6ZSuIHNoaWZ0S2V5IGFsdEtleSBjdHJsS2V5IChjb21tYW5kfHxtZXRhS2V5KSDmuIXpmaRcblxuXG4gIGlmIChrZXkgPT09IDkzIHx8IGtleSA9PT0gMjI0KSBrZXkgPSA5MTtcblxuICBpZiAoa2V5IGluIF9tb2RzKSB7XG4gICAgX21vZHNba2V5XSA9IGZhbHNlOyAvLyDlsIbkv67ppbDplK7ph43nva7kuLpmYWxzZVxuXG4gICAgZm9yICh2YXIgayBpbiBfbW9kaWZpZXIpIHtcbiAgICAgIGlmIChfbW9kaWZpZXJba10gPT09IGtleSkgaG90a2V5c1trXSA9IGZhbHNlO1xuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiB1bmJpbmQoa2V5c0luZm8pIHtcbiAgLy8gdW5iaW5kKCksIHVuYmluZCBhbGwga2V5c1xuICBpZiAoIWtleXNJbmZvKSB7XG4gICAgT2JqZWN0LmtleXMoX2hhbmRsZXJzKS5mb3JFYWNoKGZ1bmN0aW9uIChrZXkpIHtcbiAgICAgIHJldHVybiBkZWxldGUgX2hhbmRsZXJzW2tleV07XG4gICAgfSk7XG4gIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShrZXlzSW5mbykpIHtcbiAgICAvLyBzdXBwb3J0IGxpa2UgOiB1bmJpbmQoW3trZXk6ICdjdHJsK2EnLCBzY29wZTogJ3MxJ30sIHtrZXk6ICdjdHJsLWEnLCBzY29wZTogJ3MyJywgc3BsaXRLZXk6ICctJ31dKVxuICAgIGtleXNJbmZvLmZvckVhY2goZnVuY3Rpb24gKGluZm8pIHtcbiAgICAgIGlmIChpbmZvLmtleSkgZWFjaFVuYmluZChpbmZvKTtcbiAgICB9KTtcbiAgfSBlbHNlIGlmIChfdHlwZW9mKGtleXNJbmZvKSA9PT0gJ29iamVjdCcpIHtcbiAgICAvLyBzdXBwb3J0IGxpa2UgdW5iaW5kKHtrZXk6ICdjdHJsK2EsIGN0cmwrYicsIHNjb3BlOidhYmMnfSlcbiAgICBpZiAoa2V5c0luZm8ua2V5KSBlYWNoVW5iaW5kKGtleXNJbmZvKTtcbiAgfSBlbHNlIGlmICh0eXBlb2Yga2V5c0luZm8gPT09ICdzdHJpbmcnKSB7XG4gICAgZm9yICh2YXIgX2xlbiA9IGFyZ3VtZW50cy5sZW5ndGgsIGFyZ3MgPSBuZXcgQXJyYXkoX2xlbiA+IDEgPyBfbGVuIC0gMSA6IDApLCBfa2V5ID0gMTsgX2tleSA8IF9sZW47IF9rZXkrKykge1xuICAgICAgYXJnc1tfa2V5IC0gMV0gPSBhcmd1bWVudHNbX2tleV07XG4gICAgfVxuXG4gICAgLy8gc3VwcG9ydCBvbGQgbWV0aG9kXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbGluZVxuICAgIHZhciBzY29wZSA9IGFyZ3NbMF0sXG4gICAgICAgIG1ldGhvZCA9IGFyZ3NbMV07XG5cbiAgICBpZiAodHlwZW9mIHNjb3BlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBtZXRob2QgPSBzY29wZTtcbiAgICAgIHNjb3BlID0gJyc7XG4gICAgfVxuXG4gICAgZWFjaFVuYmluZCh7XG4gICAgICBrZXk6IGtleXNJbmZvLFxuICAgICAgc2NvcGU6IHNjb3BlLFxuICAgICAgbWV0aG9kOiBtZXRob2QsXG4gICAgICBzcGxpdEtleTogJysnXG4gICAgfSk7XG4gIH1cbn0gLy8g6Kej6Zmk57uR5a6a5p+Q5Liq6IyD5Zu055qE5b+r5o236ZSuXG5cblxudmFyIGVhY2hVbmJpbmQgPSBmdW5jdGlvbiBlYWNoVW5iaW5kKF9yZWYpIHtcbiAgdmFyIGtleSA9IF9yZWYua2V5LFxuICAgICAgc2NvcGUgPSBfcmVmLnNjb3BlLFxuICAgICAgbWV0aG9kID0gX3JlZi5tZXRob2QsXG4gICAgICBfcmVmJHNwbGl0S2V5ID0gX3JlZi5zcGxpdEtleSxcbiAgICAgIHNwbGl0S2V5ID0gX3JlZiRzcGxpdEtleSA9PT0gdm9pZCAwID8gJysnIDogX3JlZiRzcGxpdEtleTtcbiAgdmFyIG11bHRpcGxlS2V5cyA9IGdldEtleXMoa2V5KTtcbiAgbXVsdGlwbGVLZXlzLmZvckVhY2goZnVuY3Rpb24gKG9yaWdpbktleSkge1xuICAgIHZhciB1bmJpbmRLZXlzID0gb3JpZ2luS2V5LnNwbGl0KHNwbGl0S2V5KTtcbiAgICB2YXIgbGVuID0gdW5iaW5kS2V5cy5sZW5ndGg7XG4gICAgdmFyIGxhc3RLZXkgPSB1bmJpbmRLZXlzW2xlbiAtIDFdO1xuICAgIHZhciBrZXlDb2RlID0gbGFzdEtleSA9PT0gJyonID8gJyonIDogY29kZShsYXN0S2V5KTtcbiAgICBpZiAoIV9oYW5kbGVyc1trZXlDb2RlXSkgcmV0dXJuOyAvLyDliKTmlq3mmK/lkKbkvKDlhaXojIPlm7TvvIzmsqHmnInlsLHojrflj5bojIPlm7RcblxuICAgIGlmICghc2NvcGUpIHNjb3BlID0gZ2V0U2NvcGUoKTtcbiAgICB2YXIgbW9kcyA9IGxlbiA+IDEgPyBnZXRNb2RzKF9tb2RpZmllciwgdW5iaW5kS2V5cykgOiBbXTtcbiAgICBfaGFuZGxlcnNba2V5Q29kZV0gPSBfaGFuZGxlcnNba2V5Q29kZV0ubWFwKGZ1bmN0aW9uIChyZWNvcmQpIHtcbiAgICAgIC8vIOmAmui/h+WHveaVsOWIpOaWre+8jOaYr+WQpuino+mZpOe7keWumu+8jOWHveaVsOebuOetieebtOaOpei/lOWbnlxuICAgICAgdmFyIGlzTWF0Y2hpbmdNZXRob2QgPSBtZXRob2QgPyByZWNvcmQubWV0aG9kID09PSBtZXRob2QgOiB0cnVlO1xuXG4gICAgICBpZiAoaXNNYXRjaGluZ01ldGhvZCAmJiByZWNvcmQuc2NvcGUgPT09IHNjb3BlICYmIGNvbXBhcmVBcnJheShyZWNvcmQubW9kcywgbW9kcykpIHtcbiAgICAgICAgcmV0dXJuIHt9O1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gcmVjb3JkO1xuICAgIH0pO1xuICB9KTtcbn07IC8vIOWvueebkeWQrOWvueW6lOW/q+aNt+mUrueahOWbnuiwg+WHveaVsOi/m+ihjOWkhOeQhlxuXG5cbmZ1bmN0aW9uIGV2ZW50SGFuZGxlcihldmVudCwgaGFuZGxlciwgc2NvcGUpIHtcbiAgdmFyIG1vZGlmaWVyc01hdGNoOyAvLyDnnIvlroPmmK/lkKblnKjlvZPliY3ojIPlm7RcblxuICBpZiAoaGFuZGxlci5zY29wZSA9PT0gc2NvcGUgfHwgaGFuZGxlci5zY29wZSA9PT0gJ2FsbCcpIHtcbiAgICAvLyDmo4Dmn6XmmK/lkKbljLnphY3kv67ppbDnrKbvvIjlpoLmnpzmnInov5Tlm550cnVl77yJXG4gICAgbW9kaWZpZXJzTWF0Y2ggPSBoYW5kbGVyLm1vZHMubGVuZ3RoID4gMDtcblxuICAgIGZvciAodmFyIHkgaW4gX21vZHMpIHtcbiAgICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoX21vZHMsIHkpKSB7XG4gICAgICAgIGlmICghX21vZHNbeV0gJiYgaGFuZGxlci5tb2RzLmluZGV4T2YoK3kpID4gLTEgfHwgX21vZHNbeV0gJiYgaGFuZGxlci5tb2RzLmluZGV4T2YoK3kpID09PSAtMSkge1xuICAgICAgICAgIG1vZGlmaWVyc01hdGNoID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IC8vIOiwg+eUqOWkhOeQhueoi+W6j++8jOWmguaenOaYr+S/rumlsOmUruS4jeWBmuWkhOeQhlxuXG5cbiAgICBpZiAoaGFuZGxlci5tb2RzLmxlbmd0aCA9PT0gMCAmJiAhX21vZHNbMTZdICYmICFfbW9kc1sxOF0gJiYgIV9tb2RzWzE3XSAmJiAhX21vZHNbOTFdIHx8IG1vZGlmaWVyc01hdGNoIHx8IGhhbmRsZXIuc2hvcnRjdXQgPT09ICcqJykge1xuICAgICAgaWYgKGhhbmRsZXIubWV0aG9kKGV2ZW50LCBoYW5kbGVyKSA9PT0gZmFsc2UpIHtcbiAgICAgICAgaWYgKGV2ZW50LnByZXZlbnREZWZhdWx0KSBldmVudC5wcmV2ZW50RGVmYXVsdCgpO2Vsc2UgZXZlbnQucmV0dXJuVmFsdWUgPSBmYWxzZTtcbiAgICAgICAgaWYgKGV2ZW50LnN0b3BQcm9wYWdhdGlvbikgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIGlmIChldmVudC5jYW5jZWxCdWJibGUpIGV2ZW50LmNhbmNlbEJ1YmJsZSA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICB9XG59IC8vIOWkhOeQhmtleWRvd27kuovku7ZcblxuXG5mdW5jdGlvbiBkaXNwYXRjaChldmVudCkge1xuICB2YXIgYXN0ZXJpc2sgPSBfaGFuZGxlcnNbJyonXTtcbiAgdmFyIGtleSA9IGV2ZW50LmtleUNvZGUgfHwgZXZlbnQud2hpY2ggfHwgZXZlbnQuY2hhckNvZGU7IC8vIOihqOWNleaOp+S7tui/h+a7pCDpu5jorqTooajljZXmjqfku7bkuI3op6blj5Hlv6vmjbfplK5cblxuICBpZiAoIWhvdGtleXMuZmlsdGVyLmNhbGwodGhpcywgZXZlbnQpKSByZXR1cm47IC8vIEdlY2tvKEZpcmVmb3gp55qEY29tbWFuZOmUruWAvDIyNO+8jOWcqFdlYmtpdChDaHJvbWUp5Lit5L+d5oyB5LiA6Ie0XG4gIC8vIFdlYmtpdOW3puWPsyBjb21tYW5kIOmUruWAvOS4jeS4gOagt1xuXG4gIGlmIChrZXkgPT09IDkzIHx8IGtleSA9PT0gMjI0KSBrZXkgPSA5MTtcbiAgLyoqXG4gICAqIENvbGxlY3QgYm91bmQga2V5c1xuICAgKiBJZiBhbiBJbnB1dCBNZXRob2QgRWRpdG9yIGlzIHByb2Nlc3Npbmcga2V5IGlucHV0IGFuZCB0aGUgZXZlbnQgaXMga2V5ZG93biwgcmV0dXJuIDIyOS5cbiAgICogaHR0cHM6Ly9zdGFja292ZXJmbG93LmNvbS9xdWVzdGlvbnMvMjUwNDM5MzQvaXMtaXQtb2stdG8taWdub3JlLWtleWRvd24tZXZlbnRzLXdpdGgta2V5Y29kZS0yMjlcbiAgICogaHR0cDovL2xpc3RzLnczLm9yZy9BcmNoaXZlcy9QdWJsaWMvd3d3LWRvbS8yMDEwSnVsU2VwL2F0dC0wMTgyL2tleUNvZGUtc3BlYy5odG1sXG4gICAqL1xuXG4gIGlmIChfZG93bktleXMuaW5kZXhPZihrZXkpID09PSAtMSAmJiBrZXkgIT09IDIyOSkgX2Rvd25LZXlzLnB1c2goa2V5KTtcbiAgLyoqXG4gICAqIEplc3QgdGVzdCBjYXNlcyBhcmUgcmVxdWlyZWQuXG4gICAqID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICovXG5cbiAgWydjdHJsS2V5JywgJ2FsdEtleScsICdzaGlmdEtleScsICdtZXRhS2V5J10uZm9yRWFjaChmdW5jdGlvbiAoa2V5TmFtZSkge1xuICAgIHZhciBrZXlOdW0gPSBtb2RpZmllck1hcFtrZXlOYW1lXTtcblxuICAgIGlmIChldmVudFtrZXlOYW1lXSAmJiBfZG93bktleXMuaW5kZXhPZihrZXlOdW0pID09PSAtMSkge1xuICAgICAgX2Rvd25LZXlzLnB1c2goa2V5TnVtKTtcbiAgICB9IGVsc2UgaWYgKCFldmVudFtrZXlOYW1lXSAmJiBfZG93bktleXMuaW5kZXhPZihrZXlOdW0pID4gLTEpIHtcbiAgICAgIF9kb3duS2V5cy5zcGxpY2UoX2Rvd25LZXlzLmluZGV4T2Yoa2V5TnVtKSwgMSk7XG4gICAgfVxuICB9KTtcbiAgLyoqXG4gICAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICovXG5cbiAgaWYgKGtleSBpbiBfbW9kcykge1xuICAgIF9tb2RzW2tleV0gPSB0cnVlOyAvLyDlsIbnibnmrorlrZfnrKbnmoRrZXnms6jlhozliLAgaG90a2V5cyDkuIpcblxuICAgIGZvciAodmFyIGsgaW4gX21vZGlmaWVyKSB7XG4gICAgICBpZiAoX21vZGlmaWVyW2tdID09PSBrZXkpIGhvdGtleXNba10gPSB0cnVlO1xuICAgIH1cblxuICAgIGlmICghYXN0ZXJpc2spIHJldHVybjtcbiAgfSAvLyDlsIYgbW9kaWZpZXJNYXAg6YeM6Z2i55qE5L+u6aWw6ZSu57uR5a6a5YiwIGV2ZW50IOS4rVxuXG5cbiAgZm9yICh2YXIgZSBpbiBfbW9kcykge1xuICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoX21vZHMsIGUpKSB7XG4gICAgICBfbW9kc1tlXSA9IGV2ZW50W21vZGlmaWVyTWFwW2VdXTtcbiAgICB9XG4gIH0gLy8g6I635Y+W6IyD5Zu0IOm7mOiupOS4uiBgYWxsYFxuXG5cbiAgdmFyIHNjb3BlID0gZ2V0U2NvcGUoKTsgLy8g5a+55Lu75L2V5b+r5o236ZSu6YO96ZyA6KaB5YGa55qE5aSE55CGXG5cbiAgaWYgKGFzdGVyaXNrKSB7XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhc3Rlcmlzay5sZW5ndGg7IGkrKykge1xuICAgICAgaWYgKGFzdGVyaXNrW2ldLnNjb3BlID09PSBzY29wZSAmJiAoZXZlbnQudHlwZSA9PT0gJ2tleWRvd24nICYmIGFzdGVyaXNrW2ldLmtleWRvd24gfHwgZXZlbnQudHlwZSA9PT0gJ2tleXVwJyAmJiBhc3Rlcmlza1tpXS5rZXl1cCkpIHtcbiAgICAgICAgZXZlbnRIYW5kbGVyKGV2ZW50LCBhc3Rlcmlza1tpXSwgc2NvcGUpO1xuICAgICAgfVxuICAgIH1cbiAgfSAvLyBrZXkg5LiN5ZyoIF9oYW5kbGVycyDkuK3ov5Tlm55cblxuXG4gIGlmICghKGtleSBpbiBfaGFuZGxlcnMpKSByZXR1cm47XG5cbiAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IF9oYW5kbGVyc1trZXldLmxlbmd0aDsgX2krKykge1xuICAgIGlmIChldmVudC50eXBlID09PSAna2V5ZG93bicgJiYgX2hhbmRsZXJzW2tleV1bX2ldLmtleWRvd24gfHwgZXZlbnQudHlwZSA9PT0gJ2tleXVwJyAmJiBfaGFuZGxlcnNba2V5XVtfaV0ua2V5dXApIHtcbiAgICAgIGlmIChfaGFuZGxlcnNba2V5XVtfaV0ua2V5KSB7XG4gICAgICAgIHZhciByZWNvcmQgPSBfaGFuZGxlcnNba2V5XVtfaV07XG4gICAgICAgIHZhciBzcGxpdEtleSA9IHJlY29yZC5zcGxpdEtleTtcbiAgICAgICAgdmFyIGtleVNob3J0Y3V0ID0gcmVjb3JkLmtleS5zcGxpdChzcGxpdEtleSk7XG4gICAgICAgIHZhciBfZG93bktleXNDdXJyZW50ID0gW107IC8vIOiusOW9leW9k+WJjeaMiemUrumUruWAvFxuXG4gICAgICAgIGZvciAodmFyIGEgPSAwOyBhIDwga2V5U2hvcnRjdXQubGVuZ3RoOyBhKyspIHtcbiAgICAgICAgICBfZG93bktleXNDdXJyZW50LnB1c2goY29kZShrZXlTaG9ydGN1dFthXSkpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKF9kb3duS2V5c0N1cnJlbnQuc29ydCgpLmpvaW4oJycpID09PSBfZG93bktleXMuc29ydCgpLmpvaW4oJycpKSB7XG4gICAgICAgICAgLy8g5om+5Yiw5aSE55CG5YaF5a65XG4gICAgICAgICAgZXZlbnRIYW5kbGVyKGV2ZW50LCByZWNvcmQsIHNjb3BlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxufSAvLyDliKTmlq0gZWxlbWVudCDmmK/lkKblt7Lnu4/nu5Hlrprkuovku7ZcblxuXG5mdW5jdGlvbiBpc0VsZW1lbnRCaW5kKGVsZW1lbnQpIHtcbiAgcmV0dXJuIGVsZW1lbnRIYXNCaW5kRXZlbnQuaW5kZXhPZihlbGVtZW50KSA+IC0xO1xufVxuXG5mdW5jdGlvbiBob3RrZXlzKGtleSwgb3B0aW9uLCBtZXRob2QpIHtcbiAgX2Rvd25LZXlzID0gW107XG4gIHZhciBrZXlzID0gZ2V0S2V5cyhrZXkpOyAvLyDpnIDopoHlpITnkIbnmoTlv6vmjbfplK7liJfooahcblxuICB2YXIgbW9kcyA9IFtdO1xuICB2YXIgc2NvcGUgPSAnYWxsJzsgLy8gc2NvcGXpu5jorqTkuLphbGzvvIzmiYDmnInojIPlm7Tpg73mnInmlYhcblxuICB2YXIgZWxlbWVudCA9IGRvY3VtZW50OyAvLyDlv6vmjbfplK7kuovku7bnu5HlrproioLngrlcblxuICB2YXIgaSA9IDA7XG4gIHZhciBrZXl1cCA9IGZhbHNlO1xuICB2YXIga2V5ZG93biA9IHRydWU7XG4gIHZhciBzcGxpdEtleSA9ICcrJzsgLy8g5a+55Li66K6+5a6a6IyD5Zu055qE5Yik5patXG5cbiAgaWYgKG1ldGhvZCA9PT0gdW5kZWZpbmVkICYmIHR5cGVvZiBvcHRpb24gPT09ICdmdW5jdGlvbicpIHtcbiAgICBtZXRob2QgPSBvcHRpb247XG4gIH1cblxuICBpZiAoT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG9wdGlvbikgPT09ICdbb2JqZWN0IE9iamVjdF0nKSB7XG4gICAgaWYgKG9wdGlvbi5zY29wZSkgc2NvcGUgPSBvcHRpb24uc2NvcGU7IC8vIGVzbGludC1kaXNhYmxlLWxpbmVcblxuICAgIGlmIChvcHRpb24uZWxlbWVudCkgZWxlbWVudCA9IG9wdGlvbi5lbGVtZW50OyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG5cbiAgICBpZiAob3B0aW9uLmtleXVwKSBrZXl1cCA9IG9wdGlvbi5rZXl1cDsgLy8gZXNsaW50LWRpc2FibGUtbGluZVxuXG4gICAgaWYgKG9wdGlvbi5rZXlkb3duICE9PSB1bmRlZmluZWQpIGtleWRvd24gPSBvcHRpb24ua2V5ZG93bjsgLy8gZXNsaW50LWRpc2FibGUtbGluZVxuXG4gICAgaWYgKHR5cGVvZiBvcHRpb24uc3BsaXRLZXkgPT09ICdzdHJpbmcnKSBzcGxpdEtleSA9IG9wdGlvbi5zcGxpdEtleTsgLy8gZXNsaW50LWRpc2FibGUtbGluZVxuICB9XG5cbiAgaWYgKHR5cGVvZiBvcHRpb24gPT09ICdzdHJpbmcnKSBzY29wZSA9IG9wdGlvbjsgLy8g5a+55LqO5q+P5Liq5b+r5o236ZSu6L+b6KGM5aSE55CGXG5cbiAgZm9yICg7IGkgPCBrZXlzLmxlbmd0aDsgaSsrKSB7XG4gICAga2V5ID0ga2V5c1tpXS5zcGxpdChzcGxpdEtleSk7IC8vIOaMiemUruWIl+ihqFxuXG4gICAgbW9kcyA9IFtdOyAvLyDlpoLmnpzmmK/nu4TlkIjlv6vmjbfplK7lj5blvpfnu4TlkIjlv6vmjbfplK5cblxuICAgIGlmIChrZXkubGVuZ3RoID4gMSkgbW9kcyA9IGdldE1vZHMoX21vZGlmaWVyLCBrZXkpOyAvLyDlsIbpnZ7kv67ppbDplK7ovazljJbkuLrplK7noIFcblxuICAgIGtleSA9IGtleVtrZXkubGVuZ3RoIC0gMV07XG4gICAga2V5ID0ga2V5ID09PSAnKicgPyAnKicgOiBjb2RlKGtleSk7IC8vICrooajnpLrljLnphY3miYDmnInlv6vmjbfplK5cbiAgICAvLyDliKTmlq1rZXnmmK/lkKblnKhfaGFuZGxlcnPkuK3vvIzkuI3lnKjlsLHotYvkuIDkuKrnqbrmlbDnu4RcblxuICAgIGlmICghKGtleSBpbiBfaGFuZGxlcnMpKSBfaGFuZGxlcnNba2V5XSA9IFtdO1xuXG4gICAgX2hhbmRsZXJzW2tleV0ucHVzaCh7XG4gICAgICBrZXl1cDoga2V5dXAsXG4gICAgICBrZXlkb3duOiBrZXlkb3duLFxuICAgICAgc2NvcGU6IHNjb3BlLFxuICAgICAgbW9kczogbW9kcyxcbiAgICAgIHNob3J0Y3V0OiBrZXlzW2ldLFxuICAgICAgbWV0aG9kOiBtZXRob2QsXG4gICAgICBrZXk6IGtleXNbaV0sXG4gICAgICBzcGxpdEtleTogc3BsaXRLZXlcbiAgICB9KTtcbiAgfSAvLyDlnKjlhajlsYBkb2N1bWVudOS4iuiuvue9ruW/q+aNt+mUrlxuXG5cbiAgaWYgKHR5cGVvZiBlbGVtZW50ICE9PSAndW5kZWZpbmVkJyAmJiAhaXNFbGVtZW50QmluZChlbGVtZW50KSAmJiB3aW5kb3cpIHtcbiAgICBlbGVtZW50SGFzQmluZEV2ZW50LnB1c2goZWxlbWVudCk7XG4gICAgYWRkRXZlbnQoZWxlbWVudCwgJ2tleWRvd24nLCBmdW5jdGlvbiAoZSkge1xuICAgICAgZGlzcGF0Y2goZSk7XG4gICAgfSk7XG4gICAgYWRkRXZlbnQod2luZG93LCAnZm9jdXMnLCBmdW5jdGlvbiAoKSB7XG4gICAgICBfZG93bktleXMgPSBbXTtcbiAgICB9KTtcbiAgICBhZGRFdmVudChlbGVtZW50LCAna2V5dXAnLCBmdW5jdGlvbiAoZSkge1xuICAgICAgZGlzcGF0Y2goZSk7XG4gICAgICBjbGVhck1vZGlmaWVyKGUpO1xuICAgIH0pO1xuICB9XG59XG5cbnZhciBfYXBpID0ge1xuICBzZXRTY29wZTogc2V0U2NvcGUsXG4gIGdldFNjb3BlOiBnZXRTY29wZSxcbiAgZGVsZXRlU2NvcGU6IGRlbGV0ZVNjb3BlLFxuICBnZXRQcmVzc2VkS2V5Q29kZXM6IGdldFByZXNzZWRLZXlDb2RlcyxcbiAgaXNQcmVzc2VkOiBpc1ByZXNzZWQsXG4gIGZpbHRlcjogZmlsdGVyLFxuICB1bmJpbmQ6IHVuYmluZFxufTtcblxuZm9yICh2YXIgYSBpbiBfYXBpKSB7XG4gIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoX2FwaSwgYSkpIHtcbiAgICBob3RrZXlzW2FdID0gX2FwaVthXTtcbiAgfVxufVxuXG5pZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgdmFyIF9ob3RrZXlzID0gd2luZG93LmhvdGtleXM7XG5cbiAgaG90a2V5cy5ub0NvbmZsaWN0ID0gZnVuY3Rpb24gKGRlZXApIHtcbiAgICBpZiAoZGVlcCAmJiB3aW5kb3cuaG90a2V5cyA9PT0gaG90a2V5cykge1xuICAgICAgd2luZG93LmhvdGtleXMgPSBfaG90a2V5cztcbiAgICB9XG5cbiAgICByZXR1cm4gaG90a2V5cztcbiAgfTtcblxuICB3aW5kb3cuaG90a2V5cyA9IGhvdGtleXM7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGhvdGtleXM7XG4iLCIvKipcbiAqIFRoaXMgaXMgdGhlIGNvbnRlbnQgc2NyaXB0IHRoYXQgd2lsbCBydW4gaW4gYWxsIHl1Y2F0YS5kZSBwYWdlc1xuICogS2V5cyBvZiB0aGUgbWFwIGFyZSB0aGUgYnV0dG9ucyBwcmVzc2VkXG4gKiBWYWx1ZXMgb2YgdGhlIG1hcCBhcmUgb2JqZWN0cyBkZXNjcmliaW5nIHRoZSBhY3Rpb24gY29udGFpbmluZyBhIGRlc2NyaXB0aW9uIGFuZCBhIG1ldGhvZFxuICovXG5pbXBvcnQge21hY2hpS29yb0hvdGtleXNNYXAsIG1haW4gYXMgbWFjaGlfa29yb19tYWlufSBmcm9tICcuL2hvdGtleXMvbWFjaGlfa29ybyc7XG5pbXBvcnQge2dsb2JhbEhvdGtleXNNYXB9IGZyb20gJy4vaG90a2V5cy9nbG9iYWwnO1xuaW1wb3J0IHt3YWl0Rm9yQm9hcmRUb0V4aXN0QW5kVGhlbn0gZnJvbSBcIi4vZG9tXCI7XG5pbXBvcnQgaG90a2V5cyBmcm9tICdob3RrZXlzLWpzJztcblxuXG4vKipcbiAqIEFsbCBvZiB0aGUgaG90a2V5cyBjb21iaW5lZFxuICovXG5jb25zdCBob3RrZXlzTWFwID0ge1xuICAuLi5tYWNoaUtvcm9Ib3RrZXlzTWFwLFxuICAuLi5nbG9iYWxIb3RrZXlzTWFwLFxufTtcblxuc2V0dXBIb3RrZXlzKCk7XG53YWl0Rm9yQm9hcmRUb0V4aXN0QW5kVGhlbihhZGRUb29sdGlwKTtcbm1hY2hpX2tvcm9fbWFpbigpO1xuXG5cbi8qKlxuICogQWRkIGEgdG9vbHRpcCB0byB0aGUgVUkgY29udGFpbmluZyB0aGUgc2hvcnRjdXRzXG4gKi9cbmZ1bmN0aW9uIGFkZFRvb2x0aXAoKXtcbiAgICBjb25zdCBib2FyZCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYm9hcmRcIik7XG4gICAgY29uc3QgdG9vbHRpcFRyaWdnZXJFbGVtZW50ID0gT2JqZWN0LmFzc2lnbihkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpLCB7XG4gICAgICAgIGNsYXNzTmFtZTogXCJob3RrZXlUb29sdGlwVHJpZ2dlciB1aS1idG4gdWktaW5wdXQtYnRuIHVpLWJ0bi1hIHVpLWNvcm5lci1hbGwgdWktc2hhZG93IHVpLWJ0bi1pbmxpbmUgdWktbWluaSB1aS1maXJzdC1jaGlsZFwiLFxuICAgICAgICB0ZXh0Q29udGVudDogXCJMaXN0IG9mIEhvdGtleXNcIlxuICAgIH0pO1xuICAgIGNvbnN0IHRvb2x0aXBUZXh0ID0gT2JqZWN0LmFzc2lnbihkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpLCB7XG4gICAgICAgIGNsYXNzTmFtZTogXCJ0b29sdGlwVGV4dFwiLFxuICAgIH0pO1xuXG4gICAgT2JqZWN0LmtleXMoaG90a2V5c01hcCkuZm9yRWFjaChrZXkgPT4ge1xuICAgICAgIGNvbnN0IHtrZXlDb21ib3MsIGRlc2NyaXB0aW9ufSA9IGhvdGtleXNNYXBba2V5XTtcbiAgICAgICBjb25zdCByb3cgPSBPYmplY3QuYXNzaWduKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiksIHtcbiAgICAgICAgICAgY2xhc3NOYW1lOiBcInRvb2x0aXBUZXh0Um93XCJcbiAgICAgICB9KTtcbiAgICAgICBjb25zdCBsYWJlbENlbGwgPSBPYmplY3QuYXNzaWduKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiksIHtcbiAgICAgICAgICAgY2xhc3NOYW1lOiBcInRvb2x0aXBUZXh0bGFiZWxcIixcbiAgICAgICAgICAgdGV4dENvbnRlbnQ6IGtleUNvbWJvc1swXS50b0xvY2FsZVVwcGVyQ2FzZSgpICsgXCI6XCJcbiAgICAgICB9KTtcbiAgICAgICBjb25zdCB2YWx1ZUNlbGwgPSBPYmplY3QuYXNzaWduKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiksIHtcbiAgICAgICAgICAgY2xhc3NOYW1lOiBcInRvb2x0aXBUZXh0VmFsdWVcIixcbiAgICAgICAgICAgdGV4dENvbnRlbnQ6IGRlc2NyaXB0aW9uXG4gICAgICAgfSk7XG4gICAgICAgcm93LmFwcGVuZENoaWxkKGxhYmVsQ2VsbCk7XG4gICAgICAgcm93LmFwcGVuZENoaWxkKHZhbHVlQ2VsbCk7XG4gICAgICAgdG9vbHRpcFRleHQuYXBwZW5kQ2hpbGQocm93KTtcbiAgICB9KTtcblxuICAgIHRvb2x0aXBUcmlnZ2VyRWxlbWVudC5hcHBlbmRDaGlsZCh0b29sdGlwVGV4dCk7XG4gICAgYm9hcmQuYXBwZW5kQ2hpbGQodG9vbHRpcFRyaWdnZXJFbGVtZW50KTtcbiAgICBib2FyZC5hcHBlbmRDaGlsZCh0b29sdGlwVGV4dCk7XG59XG5cblxuLyoqXG4gKiBTZXQgdXAgdGhlIGtleXByZXNzIGhhbmRsZXJzIGZvciBhbGwgdGhlIGhvdGtleXNcbiAqL1xuZnVuY3Rpb24gc2V0dXBIb3RrZXlzKCl7XG4gICAgY29uc29sZS5sb2coXCJDdXN0b20gWXVjYXRhIGhvdGtleXMgYWRkZWQuXCIpO1xuICAgIC8vIEZvciBlYWNoIGtleSBkZWZpbmVkIGluIHRoZSBtYXAgKHVuaXF1ZSBhY3Rpb24gbmFtZSlcbiAgICBPYmplY3Qua2V5cyhob3RrZXlzTWFwKS5mb3JFYWNoKGFjdGlvbklkID0+IHtcbiAgICAgICAgLy8gR2V0IHRoZSBkYXRhIG9iamVjdFxuICAgICAgICBjb25zdCBkYXRhID0gaG90a2V5c01hcFthY3Rpb25JZF07XG4gICAgICAgIGlmKGRhdGEpe1xuICAgICAgICAgICAgY29uc3Qge2tleUNvbWJvcywgbWV0aG9kLCBkZXNjcmlwdGlvbn0gPSBkYXRhO1xuICAgICAgICAgICAga2V5Q29tYm9zLmZvckVhY2goa2V5ID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBrZXlNZXRob2QgPSBtZXRob2Q7XG4gICAgICAgICAgICAgICAgaG90a2V5cyhrZXksIGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBBY3Rpb246ICR7ZGVzY3JpcHRpb259YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXlNZXRob2QoKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfSk7XG59XG5cblxuXG5cblxuXG5cblxuIiwiLyoqXG4gKiBSZXR1cm4gdGhlIGRvbSBub2RlIG9mIHRoZSBidXR0b24gaW4gdGhlIHBvcHVwXG4gKiBAcmV0dXJucyB7SFRNTEVsZW1lbnR9XG4gKi9cbmV4cG9ydCBjb25zdCBnZXRQb3B1cEJ1dHRvbiA9ICgpID0+e1xuICAgIHJldHVybiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInBvcHVwQnV0dG9uXCIpO1xufTtcblxuLyoqXG4gKiBDbGljayB0aGUgZWxlbWVudCBpbiB0aGUgc2VsZWN0b3IgaWYgaXQgaXMgZm91bmRcbiAqIEBwYXJhbSB7c3RyaW5nfSBzZWxlY3RvclxuICovXG5leHBvcnQgZnVuY3Rpb24gY2xpY2tCeVNlbGVjdG9yKHNlbGVjdG9yKXtcbiAgICBjb25zdCBlbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihzZWxlY3Rvcik7XG4gICAgaWYoZWxlbWVudCl7XG4gICAgICAgIGVsZW1lbnQuY2xpY2soKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZyhgRWxlbWVudCAke3NlbGVjdG9yfSBub3QgZm91bmRgKTtcbiAgICB9XG59XG5cbi8qKlxuICogV2FpdCBmb3IgdGhlIGJvYXJkIERPTSBlbGVtZW50IHRvIGV4aXN0LCBhbmQgdGhlbiBleGVjdXRlIHRoZSBtZXRob2QgcGFzc2VkXG4gKiBAcGFyYW0ge2Z1bmN0aW9ufSBtZXRob2RcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHdhaXRGb3JCb2FyZFRvRXhpc3RBbmRUaGVuKG1ldGhvZCl7XG4gICAgY29uc3QgYm9hcmQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImJvYXJkXCIpO1xuICAgIGlmKGJvYXJkKXtcbiAgICAgICAgY29uc29sZS5sb2coXCJCb2FyZCBpcyByZWFkeS5cIik7XG4gICAgICAgIG1ldGhvZCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiTm8gYm9hcmQgeWV0LCB3YWl0aW5nLlwiKTtcbiAgICAgICAgc2V0VGltZW91dCh3YWl0Rm9yQm9hcmRUb0V4aXN0QW5kVGhlbi5iaW5kKHRoaXMsIG1ldGhvZCksIDUwMCk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHtjbGlja0J5U2VsZWN0b3J9IGZyb20gXCIuLi9kb21cIjtcblxuLyoqXG4gKiBIb3RrZXkgbWFwIGZvciBhbGwgZ2FtZXNcbiAqL1xuZXhwb3J0IGNvbnN0IGdsb2JhbEhvdGtleXNNYXAgPSB7XG4gICAgXCJnbG9iYWxfb2tcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcImdcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkhpdCAnT0snIHdoZW4gaXQncyB5b3VyIHR1cm5cIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIudWktcG9wdXAtYWN0aXZlIGlucHV0W3ZhbHVlPSdPSyddXCIpXG4gICAgfSxcbiAgICBcImdsb2JhbF91bmRvXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCJ1XCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJIaXQgJ1VuZG8nIGJ1dHRvblwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNidG5fdW5kb1wiKVxuICAgIH0sXG4gICAgXCJnbG9iYWxfcGFzc1wiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wicFwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiSGl0IHRoZSAnUGFzcycgYnV0dG9uXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2J0bl9CdG5QYXNzQnV5XCIpXG4gICAgfSxcbiAgICBcImdsb2JhbF9maW5pc2hcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcImZcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkhpdCB0aGUgJ0ZpbmlzaCBUdXJuJyBidXR0b25cIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjYnRuX2ZpbmlzaFR1cm5cIilcbiAgICB9LFxuICAgIFwiZ2xvYmFsX25leHRfZ2FtZVwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiblwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiSGl0IHRoZSAnTmV4dCBHYW1lJyBidXR0b25cIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjYnRuX25leHRHYW1lXCIpXG4gICAgfVxufTtcbiIsImltcG9ydCAnLi4vLi4vc2Nzcy9tYWNoaV9rb3JvLnNjc3MnO1xuaW1wb3J0IHtjbGlja0J5U2VsZWN0b3IsIHdhaXRGb3JCb2FyZFRvRXhpc3RBbmRUaGVufSBmcm9tIFwiLi4vZG9tXCI7XG5cbi8qKlxuICogTWFpbiBtZXRob2QgdG8gYmUgZXhlY3V0ZWQgKGJ5IGNvbnRlbnQuanMpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCl7XG4gICAgd2FpdEZvckJvYXJkVG9FeGlzdEFuZFRoZW4oKCk9PiBzZWxlY3RDYXJkQnlTZWxlY3RvcihcIiNjYXJkMVwiKSk7XG4gICAgd2FpdEZvckJvYXJkVG9FeGlzdEFuZFRoZW4oYWRkQ2FyZFRvb2x0aXBzKTtcbn1cblxuLyoqXG4gKiBIb3RrZXkgbWFwIGZvciBtYWNoaSBrb3JvIG9ubHlcbiAqL1xuZXhwb3J0IGNvbnN0IG1hY2hpS29yb0hvdGtleXNNYXAgPSB7XG4gICAgXCJtYWNoaV9rb3JvX2J1eV9zbG90XzFcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIjFcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkJ1eSBDYXJkIGluIFNsb3QgMSAoTWFjaGkgS29ybylcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjY2FyZDFcIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19idXlfc2xvdF8yXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCIyXCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJCdXkgQ2FyZCBpbiBTbG90IDIgKE1hY2hpIEtvcm8pXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2NhcmQyXCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fYnV5X3Nsb3RfM1wiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiM1wiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQnV5IENhcmQgaW4gU2xvdCAzIChNYWNoaSBLb3JvKVwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNjYXJkM1wiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX2J1eV9zbG90XzRcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIjRcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkJ1eSBDYXJkIGluIFNsb3QgNCAoTWFjaGkgS29ybylcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjY2FyZDRcIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19idXlfc2xvdF81XCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCI1XCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJCdXkgQ2FyZCBpbiBTbG90IDUgKE1hY2hpIEtvcm8pXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2NhcmQ1XCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fYnV5X3Nsb3RfNlwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiNlwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQnV5IENhcmQgaW4gU2xvdCA2IChNYWNoaSBLb3JvKVwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNjYXJkNlwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX2J1eV9zbG90XzdcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcIjdcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkJ1eSBDYXJkIGluIFNsb3QgNyAoTWFjaGkgS29ybylcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjY2FyZDdcIilcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19idXlfc2xvdF84XCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCI4XCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJCdXkgQ2FyZCBpbiBTbG90IDggKE1hY2hpIEtvcm8pXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2NhcmQ4XCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fYnV5X3Nsb3RfOVwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiOVwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQnV5IENhcmQgaW4gU2xvdCA5IChNYWNoaSBLb3JvKVwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNjYXJkOVwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX3RvZ2dsZV9kaWNlXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCJkXCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJUb2dnbGUgRGljZVwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IGNsaWNrQnlTZWxlY3RvcihcIiNkaWUyXCIpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fcm9sbF9kaWNlXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCJyXCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJIaXQgJ1JvbGwgZGljZScgYnV0dG9uXCIsXG4gICAgICAgIG1ldGhvZDogKCkgPT4gY2xpY2tCeVNlbGVjdG9yKFwiI2J0bl9Xw7xyZmVsblwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX3Jlcm9sbF9kaWNlXCI6IHtcbiAgICAgICAga2V5Q29tYm9zOiBbXCJxXCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJIaXQgJ1Jlcm9sbCBkaWNlJyBidXR0b25cIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjYnRuX0J0blJvbGxBZ2FpblwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX2RvX25vdF9yZXJvbGxfZGljZVwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wid1wiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiSGl0ICdEbyBOb3QgUmVyb2xsJyBidXR0b25cIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBjbGlja0J5U2VsZWN0b3IoXCIjYnRuX0J0blJvbGxOb3RBZ2FpblwiKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX3NlbGVjdF9jYXJkX2xlZnRcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcImxlZnRcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlNlbGVjdCBMZWZ0IENhcmRcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBzZWxlY3RDYXJkTGVmdCgpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fc2VsZWN0X2NhcmRfcmlnaHRcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcInJpZ2h0XCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJTZWxlY3QgUmlnaHQgQ2FyZFwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IHNlbGVjdENhcmRSaWdodCgpXG4gICAgfSxcbiAgICBcIm1hY2hpX2tvcm9fc2VsZWN0X2NhcmRfdXBcIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcInVwXCJdLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJTZWxlY3QgVG9wIENhcmRcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBzZWxlY3RDYXJkVXAoKVxuICAgIH0sXG4gICAgXCJtYWNoaV9rb3JvX3NlbGVjdF9jYXJkX2Rvd25cIjoge1xuICAgICAgICBrZXlDb21ib3M6IFtcImRvd25cIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlNlbGVjdCBCb3R0b20gQ2FyZFwiLFxuICAgICAgICBtZXRob2Q6ICgpID0+IHNlbGVjdENhcmREb3duKClcbiAgICB9LFxuICAgIFwibWFjaGlfa29yb19idXlfc2VsZWN0ZWRfY2FyZFwiOiB7XG4gICAgICAgIGtleUNvbWJvczogW1wiYlwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQnV5IFNlbGVjdGVkIENhcmRcIixcbiAgICAgICAgbWV0aG9kOiAoKSA9PiBidXlTZWxlY3RlZENhcmQoKVxuICAgIH1cbn07XG5cbi8qKlxuICogQWRkIHRoZSBcInNlbGVjdGVkQ2FyZFwiIGNsYXNzIHRvIHRoZSBlbGVtZW50IG1hdGNoZWQgYnkgdGhlIHNlbGVjdG9yIChpZiBhbnkpXG4gKiBAcGFyYW0ge3N0cmluZ30gc2VsZWN0b3JcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNlbGVjdENhcmRCeVNlbGVjdG9yKHNlbGVjdG9yKXtcbiAgICBjb25zdCBhY3RpdmVFbGVtZW50ID0gZ2V0U2VsZWN0ZWRDYXJkKCk7XG4gICAgY29uc3QgY2FyZEVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHNlbGVjdG9yKTtcbiAgICBpZihjYXJkRWxlbWVudCl7XG4gICAgICAgIGNhcmRFbGVtZW50LmNsYXNzTGlzdC5hZGQoXCJzZWxlY3RlZENhcmRcIik7XG4gICAgICAgIGlmKGFjdGl2ZUVsZW1lbnQpe1xuICAgICAgICAgICAgYWN0aXZlRWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCBcInNlbGVjdGVkQ2FyZFwiICk7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi8qKlxuICogQWRkcyBjYXJkIHRvb2x0aXBzIG9uIGhvdmVyICh6b29tZWQgaW4gY2FyZHMpXG4gKi9cbmZ1bmN0aW9uIGFkZENhcmRUb29sdGlwcygpIHtcbiAgICBjb25zdCBjYXJkcyA9IGdldENhcmRzRG9tKCk7XG4gICAgY2FyZHMuZm9yRWFjaChjYXJkID0+IHtcbiAgICAgICAgY29uc3QgY2xvbmUgPSBjYXJkLnF1ZXJ5U2VsZWN0b3IoXCIuY2FyZCBpbWdcIikuY2xvbmVOb2RlKCk7XG4gICAgICAgIGNsb25lLmNsYXNzTGlzdC5hZGQoXCJjYXJkWm9vbWVkXCIpO1xuICAgICAgICBjYXJkLnBhcmVudEVsZW1lbnQuaW5zZXJ0QmVmb3JlKGNsb25lLCBjYXJkLm5leHRTaWJsaW5nKTtcbiAgICB9KVxufVxuXG4vKipcbiAqXG4gKiBAcmV0dXJucyB7Tm9kZUxpc3RPZjxFbGVtZW50Pn1cbiAqL1xuZnVuY3Rpb24gZ2V0Q2FyZHNEb20oKSB7XG4gICAgcmV0dXJuIFsuLi5kb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLmNhcmRDb250YWluZXJcIildO1xufVxuXG4vKipcbiAqIFJldHVybiB0aGUgY2FyZCB0aGF0IGlzIGN1cnJlbnRseSBzZWxlY3RlZCAoaGFzIHRoZSBjbGFzcyBzZWxlY3RlZENhcmQpXG4gKiBAcmV0dXJucyB7RWxlbWVudH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFNlbGVjdGVkQ2FyZCgpe1xuICAgIHJldHVybiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCBcIi5zZWxlY3RlZENhcmRcIik7XG59XG5cbi8qKlxuICogU2VsZWN0IGEgY2FyZCBiYXNlZCBvbiB0aGUgbnVtYmVyIHByb3ZpZGVkXG4gKiBAcGFyYW0ge251bWJlcn0gY2FyZE51bWJlclxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0Q2FyZEJ5TnVtYmVyKGNhcmROdW1iZXIpe1xuICAgIGNvbnN0IG5leHRDYXJkU2VsZWN0b3IgPSBgI2NhcmQke2NhcmROdW1iZXJ9YDtcbiAgICBzZWxlY3RDYXJkQnlTZWxlY3RvcihuZXh0Q2FyZFNlbGVjdG9yKTtcbn1cblxuLyoqXG4gKiBSZXR1cm4gdGhlIGNhcmQgbnVtYmVyIGZvciB0aGUgcHJvdmlkZWQgZWxlbWVudFxuICogQHBhcmFtIHtFbGVtZW50fSBlbGVtZW50XG4gKiBAcmV0dXJucyB7bnVtYmVyfVxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q2FyZE51bWJlcihlbGVtZW50KXtcbiAgICBjb25zdCByZWdleCA9IC9cXGQrJC87XG4gICAgaWYoZWxlbWVudCl7XG4gICAgICAgIGNvbnN0IGNhcmROdW1iZXIgPSBlbGVtZW50LmlkLm1hdGNoKHJlZ2V4KVswXTtcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgcmV0dXJuIHBhcnNlSW50KGNhcmROdW1iZXIpO1xuICAgICAgICB9IGNhdGNoKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGAke2VsZW1lbnQuaWR9IGRpZCBub3QgaGF2ZSBhIG51bWJlciBhdCB0aGUgZW5kIG9mIGl0cyBJRGApO1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59XG5cbi8qKlxuICogU2VsZWN0IHRoZSBjYXJkIHRvIHRoZSBsZWZ0IG9mIHRoZSBhY3RpdmUgY2FyZFxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0Q2FyZExlZnQoKXtcbiAgICBjb25zdCBhY3RpdmVFbGVtZW50ID0gZ2V0U2VsZWN0ZWRDYXJkKCk7XG4gICAgY29uc3QgbmV4dENhcmROdW1iZXIgPSBnZXRDYXJkTnVtYmVyKGFjdGl2ZUVsZW1lbnQpIC0gMTtcblxuICAgIHNlbGVjdENhcmRCeU51bWJlcihuZXh0Q2FyZE51bWJlcik7XG59XG5cbi8qKlxuICogU2VsZWN0IHRoZSBjYXJkIHRvIHRoZSByaWdodCBvZiB0aGUgYWN0aXZlIGNhcmRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNlbGVjdENhcmRSaWdodCgpe1xuICAgIGNvbnN0IGFjdGl2ZUVsZW1lbnQgPSBnZXRTZWxlY3RlZENhcmQoKTtcbiAgICBjb25zdCBuZXh0Q2FyZE51bWJlciA9IGdldENhcmROdW1iZXIoYWN0aXZlRWxlbWVudCkgKyAxO1xuXG4gICAgc2VsZWN0Q2FyZEJ5TnVtYmVyKG5leHRDYXJkTnVtYmVyKTtcbn1cblxuLyoqXG4gKiBTZWxlY3QgdGhlIGNhcmQgdG8gdGhlIHVwIG9mIHRoZSBhY3RpdmUgY2FyZFxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0Q2FyZFVwKCl7XG4gICAgY29uc3QgYWN0aXZlRWxlbWVudCA9IGdldFNlbGVjdGVkQ2FyZCgpO1xuICAgIGNvbnN0IG5leHRDYXJkTnVtYmVyID0gZ2V0Q2FyZE51bWJlcihhY3RpdmVFbGVtZW50KSAtIDU7XG5cbiAgICBzZWxlY3RDYXJkQnlOdW1iZXIobmV4dENhcmROdW1iZXIpO1xufVxuXG4vKipcbiAqIFNlbGVjdCB0aGUgY2FyZCB0byB0aGUgZG93biBvZiB0aGUgYWN0aXZlIGNhcmRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNlbGVjdENhcmREb3duKCl7XG4gICAgY29uc3QgYWN0aXZlRWxlbWVudCA9IGdldFNlbGVjdGVkQ2FyZCgpO1xuICAgIGNvbnN0IG5leHRDYXJkTnVtYmVyID0gZ2V0Q2FyZE51bWJlcihhY3RpdmVFbGVtZW50KSArIDU7XG5cbiAgICBzZWxlY3RDYXJkQnlOdW1iZXIobmV4dENhcmROdW1iZXIpO1xufVxuXG4vKipcbiAqIEJ1eSB0aGUgY2FyZCB0aGF0IGlzIGN1cnJlbnRseSBzZWxlY3RlZFxuICovXG5leHBvcnQgZnVuY3Rpb24gYnV5U2VsZWN0ZWRDYXJkKCl7XG4gICAgY29uc3QgYWN0aXZlRWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoIFwiLnNlbGVjdGVkQ2FyZFwiKTtcbiAgICBjb25zb2xlLmxvZyhcIk9rIEkgd2FudCB0byBidXkgXCIgKyBhY3RpdmVFbGVtZW50LmlkKTtcbiAgICBpZihhY3RpdmVFbGVtZW50KXtcbiAgICAgICAgaWYgKGFjdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKFwiYWN0aXZlXCIpKVxuICAgICAgICB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkl0J3MgYWN0aXZlLCBzdXJlLCBJJ2xsIGJ1eSBpdFwiKTtcbiAgICAgICAgICAgIGFjdGl2ZUVsZW1lbnQuY2xpY2soKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2xpY2tcIik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIC8vIEFuIGRlbiBlaW5haSBhdmFpbGFibGUgYXV0aFxuICAgICAgICAgICAgLy8gQW4gZGVuIGVpbmFpIGggc2VpcmEgc291IC0tIGF1dG8gaXN3cyB0byBseW5veW1lIG1lIHRvIG5hIHRzZWthcm91bWUgc2VpcmEgYXBvIHByaW5cbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRG9lc24ndCBzZWVtIHRvIGJlIGF2YWlsYWJsZSB0aG91Z2guXCIpO1xuICAgICAgICAgICAgY29uc3QgdW5kb0J1dHRvbiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjYnRuX3VuZG9cIik7XG4gICAgICAgICAgICBpZiAodW5kb0J1dHRvbil7XG4gICAgICAgICAgICAgICAgLy8gQW4gZXhlaXMgYWdvcmFzZWkgaGRoXG4gICAgICAgICAgICAgICAgYWxlcnQoXCJZb3UndmUgYWxyZWFkeSBjaG9zZW4gYSBjYXJkLlwiKTtcbiAgICAgICAgICAgICAgICAvLyBhbiB2Z2Fsb3VtZSB0byBibGUgb3RhbiBkZW4gZWluYWkgaCBzZWlyYSBzb3UgZGUgeHJlaWF6ZXRhaSBhdXRvXG4gICAgICAgICAgICAgICAgLy8gYWxsYSBwcmVwZWkgbmEgeGFuYWdpbmV0YWkgYmxlIG90YW4gZWluYWkgaCBzZWlyYSBzb3VcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgYWxlcnQoXCJZb3UgY2FuJ3QgYnV5IHRoaXMgb25lIDooIFxcbkNob3NlIGFuIGF2YWlsYWJsZSBjYXJkLlwiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBFbGVtZW50ICR7YWN0aXZlRWxlbWVudC5pZH0gbm90IGZvdW5kYCk7XG4gICAgfVxufSIsIi8vIGV4dHJhY3RlZCBieSBtaW5pLWNzcy1leHRyYWN0LXBsdWdpbiJdLCJzb3VyY2VSb290IjoiIn0=